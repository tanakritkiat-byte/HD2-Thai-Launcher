from __future__ import annotations

import csv
import hashlib
import json
import struct
import zipfile
from pathlib import Path


ROOT = Path(__file__).resolve().parent
PROJECT = ROOT.parent
SHEET_CSV = PROJECT / "HD2_Thai_Worklist_Live_v2.csv"
GAME_STRINGS = PROJECT / "current_game_strings_20261024"
TEMPLATE_PATCH = (
    PROJECT
    / "HD2_Thai_Strings_Test_v2_build"
    / "data"
    / "9ba626afa44a3aa3.patch_3"
)
ARCHIVE_NAME = "9ba626afa44a3aa3.patch_3"
RESOURCE_TYPE = 0x0D972BAB10B40FD3
STRINGS_MAGIC = 0x3E85F3AE
LANGUAGE_HASH = 0x03F97B57
HEADER = struct.Struct("<III20sQQ24s")
ENTRY = struct.Struct("<7Q6I")
MASK32 = (1 << 32) - 1


def read_sheet() -> dict[int, dict[int, dict[str, str]]]:
    with SHEET_CSV.open("r", encoding="utf-8-sig", newline="") as stream:
        reader = csv.DictReader(stream)
        expected = [
            "Asset ID",
            "String ID",
            "English source",
            "Thai translation",
            "Approved",
            "Approved",
            "Old Thai reference (raw; may contain PUA)",
            "Debug ID (base36)",
        ]
        if reader.fieldnames != expected:
            raise ValueError(f"Unexpected CSV columns: {reader.fieldnames!r}")
        rows: dict[int, dict[int, dict[str, str]]] = {}
        for line_number, row in enumerate(reader, start=2):
            asset_id = int(row["Asset ID"], 16)
            string_id = int(row["String ID"])
            if not 0 <= string_id <= MASK32:
                raise ValueError(f"String ID outside uint32 on row {line_number}")
            asset_rows = rows.setdefault(asset_id, {})
            if string_id in asset_rows:
                raise ValueError(f"Duplicate asset/string ID on row {line_number}")
            thai = row["Thai translation"]
            debug_id = row["Debug ID (base36)"].strip()
            if not debug_id:
                raise ValueError(f"Missing debug ID on row {line_number}")
            if "\x00" in thai:
                raise ValueError(f"NUL character in translation on row {line_number}")
            asset_rows[string_id] = {
                "english": row["English source"],
                "thai": thai,
                "debug": debug_id,
            }
    return rows


def make_strings_payload(items: dict[int, str]) -> bytes:
    keys = sorted(items)
    if len(keys) > MASK32:
        raise ValueError("Too many strings in one resource")
    first_value_offset = 16 + 8 * len(keys)
    offsets: list[int] = []
    values = bytearray()
    for key in keys:
        encoded = items[key].encode("utf-8") + b"\0"
        offsets.append(first_value_offset + len(values))
        values.extend(encoded)
    if any(offset > MASK32 for offset in offsets):
        raise ValueError("String resource exceeds 32-bit offsets")
    header = struct.pack("<4I", STRINGS_MAGIC, 1, len(keys), LANGUAGE_HASH)
    id_table = struct.pack(f"<{len(keys)}I", *keys) if keys else b""
    offset_table = struct.pack(f"<{len(offsets)}I", *offsets) if offsets else b""
    return header + id_table + offset_table + values


def make_archive(template: bytes, payloads: dict[int, bytes]) -> bytes:
    magic, type_count, entry_count, reserved0, main_size, gpu_size, reserved1 = HEADER.unpack_from(template)
    if magic != 0xF0000011 or type_count != 1:
        raise ValueError("Unexpected template archive header")
    table_size = HEADER.size + type_count * 32 + entry_count * ENTRY.size
    type_table = template[HEADER.size : HEADER.size + type_count * 32]
    entry_start = HEADER.size + type_count * 32
    entries = [ENTRY.unpack_from(template, entry_start + i * ENTRY.size) for i in range(entry_count)]
    if {entry[1] for entry in entries} != {RESOURCE_TYPE}:
        raise ValueError("Template contains an unexpected resource type")
    if {entry[0] for entry in entries} != set(payloads):
        raise ValueError("Translation assets do not match the tested package assets")

    position = table_size
    rebuilt_entries: list[tuple[int, ...]] = []
    chunks: list[tuple[int, bytes]] = []
    for index, old in enumerate(entries):
        name_id = old[0]
        payload = payloads[name_id]
        alignment = old[10] or 16
        position += (alignment - position % alignment) % alignment
        rebuilt = list(old)
        rebuilt[2] = position
        rebuilt[3] = 0
        rebuilt[4] = 0
        rebuilt[5] = 0
        rebuilt[6] = 0
        rebuilt[7] = len(payload)
        rebuilt[8] = 0
        rebuilt[9] = 0
        rebuilt[12] = index
        rebuilt_entries.append(tuple(rebuilt))
        chunks.append((position, payload))
        position += len(payload)

    final_size = position + (16 - position % 16) % 16
    output = bytearray(final_size)
    output[: HEADER.size] = HEADER.pack(
        magic,
        type_count,
        entry_count,
        reserved0,
        main_size,
        gpu_size,
        reserved1,
    )
    output[HEADER.size : HEADER.size + len(type_table)] = type_table
    for i, entry in enumerate(rebuilt_entries):
        start = entry_start + i * ENTRY.size
        output[start : start + ENTRY.size] = ENTRY.pack(*entry)
    for offset, payload in chunks:
        output[offset : offset + len(payload)] = payload
    return bytes(output)


def build_profile(sheet: dict[int, dict[int, dict[str, str]]], debug: bool) -> tuple[bytes, dict[str, int]]:
    template = TEMPLATE_PATCH.read_bytes()
    _, type_count, entry_count, *_ = HEADER.unpack_from(template)
    entry_start = HEADER.size + type_count * 32
    template_entries = [
        ENTRY.unpack_from(template, entry_start + i * ENTRY.size)
        for i in range(entry_count)
    ]
    payloads: dict[int, bytes] = {}
    used_rows = 0
    translated_rows = 0
    english_fallbacks = 0
    for entry in template_entries:
        asset_id = entry[0]
        path = GAME_STRINGS / f"0x{asset_id:016x}.strings.json"
        if not path.exists():
            raise FileNotFoundError(path)
        game = json.loads(path.read_text(encoding="utf-8"))
        if int(game["Language"]["Hash"], 16) != LANGUAGE_HASH:
            raise ValueError(f"Unexpected language hash in {path.name}")
        sheet_rows = sheet.get(asset_id, {})
        source: dict[int, str] = {}
        for item in game["Items"]:
            key = int(item["Key"])
            if key in source:
                raise ValueError(f"Duplicate key {key} in {path.name}")
            row = sheet_rows.get(key)
            if row:
                used_rows += 1
                value = row["thai"]
                if value.strip():
                    translated_rows += 1
                else:
                    english_fallbacks += 1
                    value = item["Value"]
                if debug:
                    value = f"{value} [{row['debug']}]"
            else:
                value = item["Value"]
            if "\x00" in value:
                raise ValueError(f"NUL character in value for {asset_id:#x}/{key}")
            source[key] = value
        unknown_keys = set(sheet_rows) - set(source)
        if unknown_keys:
            raise ValueError(f"{path.name} is missing sheet IDs: {sorted(unknown_keys)[:5]}")
        payloads[asset_id] = make_strings_payload(source)

    if used_rows != sum(map(len, sheet.values())):
        raise ValueError(f"Only matched {used_rows} of {sum(map(len, sheet.values()))} sheet rows")
    return make_archive(template, payloads), {
        "assets": len(payloads),
        "sheet_rows": used_rows,
        "translated_rows": translated_rows,
        "english_fallback_rows": english_fallbacks,
        "bytes": 0,
    }


def write_package(patch: bytes, filename: str, readme_name: str) -> dict[str, object]:
    output = PROJECT / filename
    if output.exists():
        raise FileExistsError(f"Refusing to overwrite existing version: {output}")
    readme = ROOT / readme_name
    with zipfile.ZipFile(output, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        archive.writestr(f"data/{ARCHIVE_NAME}", patch)
        archive.write(readme, readme_name)
    return {
        "file": str(output),
        "zip_bytes": output.stat().st_size,
        "sha256": hashlib.sha256(output.read_bytes()).hexdigest(),
    }


def main() -> None:
    sheet = read_sheet()
    outputs = []
    for debug, filename, readme in (
        (False, "HD2_Thai_Translation_v1.zip", "README_TH.txt"),
        (True, "HD2_Thai_Translation_Debug_v1.zip", "README_DEBUG_TH.txt"),
    ):
        patch, stats = build_profile(sheet, debug)
        stats["bytes"] = len(patch)
        result = write_package(patch, filename, readme)
        outputs.append({**stats, **result})
    print(json.dumps(outputs, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
