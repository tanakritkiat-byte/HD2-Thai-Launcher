-- HD2 Thai Language Hotkeys v7: Page Up / Page Down, bounded private modes.
-- Same native setter as v6; no automatic Apply or language-menu changes.
local game=getfenv(0)
local engine=game.stingray or game.s3d
local modes={{code='us',name='THAI'},
             {code='hd2thai_debug',name='THAI_ID'},
             {code='hd2thai_english',name='ENGLISH_US'}}
local current=1 -- The normal US table is Thai at game startup.
local bindings={{key='page up',delta=1},{key='page down',delta=-1}}
local clock,last=0,-1
local logfile=(os.getenv('APPDATA') or '')..'\\Arrowhead\\Helldivers2\\hd2thai_language_hotkeys_v7.log'
local function log(s)
    local f=io.open(logfile,'a')
    if f then f:write(os.date('%H:%M:%S'),' ',s,'\n');f:close() end
end
local ready=false
function init()
    current=1;clock=0;last=-1
    ready=type(engine)=='table' and type(engine.Localizer)=='table'
        and type(engine.Localizer.set_language)=='function' and type(engine.Keyboard)=='table'
        and type(engine.Keyboard.button_index)=='function' and type(engine.Keyboard.pressed)=='function'
    if ready then
        for _,binding in ipairs(bindings) do
            local ok,index=pcall(engine.Keyboard.button_index,binding.key)
            if ok and type(index)=='number' and index>=0 then
                binding.index=index;log('BIND '..binding.key..' index='..index)
            else ready=false;log('BIND_FAILED '..binding.key..' '..tostring(index)) end
        end
    end
    log('INIT ready='..tostring(ready)..'; Page Up: Thai -> Thai+ID -> English; Page Down: reverse; no wrap; Esc may be needed')
end
function update(dt)
    clock=clock+(tonumber(dt) or 0)
    if not ready or clock-last<0.18 then return end
    local delta,key=0,nil
    for _,binding in ipairs(bindings) do
        local ok,pressed=pcall(engine.Keyboard.pressed,binding.index)
        if ok and (pressed==true or pressed==1) then
            delta=delta+binding.delta;key=binding.key
        end
    end
    if delta==0 then return end -- Simultaneous Up/Down cancel out.
    last=clock
    local target=math.max(1,math.min(#modes,current+delta))
    if target==current then return end -- Stop at either end; do not reload.
    local mode=modes[target]
    log('REQUEST '..key..' code='..mode.code..' target='..mode.name)
    local success,result=pcall(engine.Localizer.set_language,mode.code)
    if success and result~=false then current=target end
    log('RETURN ok='..tostring(success)..' result='..tostring(result)..'; mode='..current)
end
function render() end
function shutdown() log('SHUTDOWN') end
init()
