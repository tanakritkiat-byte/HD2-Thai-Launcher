"""Portable review build; uses existing reviewed runtime modules and pinned data."""
import argparse,ast,hashlib,json,shutil,ssl,subprocess,sys,zipfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
APP=ROOT/'Player_Launcher_v1'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
 parser=argparse.ArgumentParser()
 parser.add_argument('--assets-dir',type=Path,required=True)
 parser.add_argument('--check-only',action='store_true')
 args=parser.parse_args()
 provenance=json.loads((ROOT/'SOURCE_PROVENANCE.json').read_text())
 asset=args.assets_dir/'language_assets.zip'
 manifest=args.assets_dir/'language_asset_manifest.json'
 if sha(asset)!=provenance['runtime_assets_sha256']:raise ValueError('Wrong runtime asset archive')
 meta=json.loads(manifest.read_text(encoding='utf-8'))
 if meta['sha256']!=sha(asset) or meta['bytes']!=asset.stat().st_size:raise ValueError('Invalid asset manifest')
 with zipfile.ZipFile(asset) as z:
  data=json.loads(z.read('manifest.json'))
  builder=data['baseline_lock']['builder']
  if z.read(builder)!=(ROOT/builder).read_bytes():raise ValueError('Custom package-builder source mismatch')
 if args.check_only:print('Runtime asset and package-builder checks passed');return
 version=next(ast.literal_eval(n.value) for n in ast.parse((APP/'launcher.py').read_text(encoding='utf-8')).body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='VERSION' for t in n.targets))
 output=ROOT/'Builds'/f'HD2_Thai_Launcher_v{version}_build'
 if output.exists():raise FileExistsError('Use a clean checkout/output directory; refusing overwrite: '+str(output))
 for path in [output,ROOT/'Releases/Launcher']:path.mkdir(parents=True,exist_ok=True)
 hidden=['update_translation','ui_review','three_languages','hot_swap_tables','project_paths','api_linebreaks','thai_linebreaks','context_markup','sheet_markup_rules','standalone_hotkeys','public_release']
 cmd=[sys.executable,'-m','PyInstaller','--noconfirm','--clean','--onedir','--windowed','--name','HD2ThaiLauncher',
  '--icon',str(APP/'launcher.ico'),'--version-file',str(APP/'windows_version_info.txt'),'--manifest',str(APP/'app.manifest'),
  '--distpath',str(output),'--workpath',str(APP/'build'),'--specpath',str(APP),
  '--collect-all','mitmproxy','--collect-all','mitmproxy_rs','--collect-all','certifi','--paths',str(ROOT/'Translation_Updater')]
 for name in hidden:cmd+=['--hidden-import',name]
 for path in [APP/'launcher.ico',APP/'seed_rules.json',APP/'bundle_manifest.json',asset,manifest]:cmd+=['--add-data',str(path.resolve())+';.']
 # The original Python distribution had this extra trust-policy data. Standard
 # Python installations may not have it; do not invent or disable TLS policy.
 policy=Path(ssl.__file__).with_name('codex-rejected-cas.pem')
 if policy.is_file():cmd+=['--add-data',str(policy)+';.']
 cmd.append(str(APP/'launcher.py'))
 subprocess.run(cmd,cwd=APP,check=True)
 dist=output/'HD2ThaiLauncher';removed=[]
 for package in ['mitmproxy_windows','pydivert']:
  base=(dist/'_internal'/package).resolve()
  for file in base.rglob('*'):
   if file.is_file() and file.name.lower() in {'windivert.dll','windivert64.sys','windivert32.sys','windows-redirector.exe'}:
    file.resolve().relative_to(dist.resolve());removed.append(str(file.relative_to(dist)));file.unlink()
 shutil.copytree(ROOT/'ThirdPartyNotices',dist/'ThirdPartyNotices')
 (dist/'branding').mkdir();shutil.copyfile(APP/'launcher.ico',dist/'branding'/f'launcher_v{version}.ico')
 with zipfile.ZipFile(asset) as z:
  for name in z.namelist():
   if name.startswith('seed/LICENSES/') and not name.endswith('/'):
    target=dist/name.removeprefix('seed/');target.resolve().relative_to(dist.resolve())
    target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(z.read(name))
 (output/'optional_components_omitted.json').write_text(json.dumps({'regular_proxy_only':True,'omitted':removed},indent=2))
 print('Built executable only; no installer run or game launch:',dist/'HD2ThaiLauncher.exe')
if __name__=='__main__':main()

