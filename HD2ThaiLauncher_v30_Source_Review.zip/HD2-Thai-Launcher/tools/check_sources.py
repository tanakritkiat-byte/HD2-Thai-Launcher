"""Offline file-integrity check; no game, networking or certificate operations."""
import hashlib,json
from pathlib import Path
root=Path(__file__).resolve().parents[1]
manifest=json.loads((root/'SOURCE_FILES.json').read_text())
errors=[]
for name,digest in manifest.items():
 p=root/name
 if not p.is_file() or hashlib.sha256(p.read_bytes()).hexdigest()!=digest:errors.append(name)
for p in root.rglob('*.py'):compile(p.read_bytes(),str(p),'exec',dont_inherit=True)
if errors:raise SystemExit('Integrity differences: '+', '.join(errors))
print(f'{len(manifest)} source/support files passed integrity and Python syntax checks')

