"""Derive small runtime inputs only after the unmodified baseline lock passes."""
import hashlib,json,zipfile
from pathlib import Path

def build(project,seed,output):
    project=Path(project);seed=Path(seed);output=Path(output)
    lock=json.loads((project/'Translation_Updater/baseline_lock.json').read_text(encoding='utf8'))
    from project_paths import locked_input
    sha=lambda b:hashlib.sha256(b).hexdigest()
    for rel,digest in lock['files'].items():
        if sha(locked_input(project,rel).read_bytes())!=digest:raise ValueError('Locked input changed: '+rel)
    files={}
    for rel in [lock['builder'],lock['baseline_csv']]:files[rel]=locked_input(project,rel).read_bytes()
    for rel in lock['files']:
        if rel.startswith(lock['game_strings']+'/'):files[rel]=locked_input(project,rel).read_bytes()
    with zipfile.ZipFile(locked_input(project,lock['font_package'])) as z:
        files['translation_template.patch']=z.read('data/9ba626afa44a3aa3.patch_3')
    ui=json.loads((project/'Translation_Updater/ui_review_lock.json').read_text(encoding='utf8'))
    active=project/'Translation_Updater/active_font_profile.json'
    font_profile=json.loads(active.read_text(encoding='utf8')) if active.exists() else ui
    from ui_review import load_fonts
    expected_fonts,_=load_fonts(project)
    snapshot=project/ui['game_snapshot']
    for name,digest in ui['source_files'].items():
        rel=ui['game_snapshot']+'/xaml/'+name+'.bin';raw=(project/rel).read_bytes()
        if sha(raw)!=digest:raise ValueError('UI source changed')
        files[rel]=raw
    for name,digest in ui['archive_indexes'].items():
        rel=ui['game_snapshot']+'/archive_indexes/'+name+'.bin';raw=(project/rel).read_bytes()
        if sha(raw)!=digest:raise ValueError('UI index changed')
        files[rel]=raw
    files[ui['game_snapshot']+'/inventory.json']=(snapshot/'inventory.json').read_bytes()
    for n in ['ui_review_lock.json','ui_debug_ids.json','baseline_lock.json']:
        files['Translation_Updater/'+n]=(project/'Translation_Updater'/n).read_bytes()
    if active.exists():files['Translation_Updater/active_font_profile.json']=active.read_bytes()
    # Fonts and native F6-F8 boot script are fixed seed members; no baseline ZIP
    # (347 MB) is redistributed. The entire original lock was verified above.
    with zipfile.ZipFile(seed) as z:
        for name,digest in font_profile['font_members'].items():
            raw=z.read(name)
            if sha(raw)!=digest:raise ValueError('Font differs from locked profile')
            if raw!=expected_fonts[name]:raise ValueError('Font differs from approved profile')
        seed_members={n:z.read(n) for n in z.namelist() if '.patch_' in n or n.startswith('LICENSES/')}
    with zipfile.ZipFile(output,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        for rel,raw in files.items():z.writestr(rel,raw)
        for rel,raw in seed_members.items():z.writestr('seed/'+rel,raw)
        z.writestr('manifest.json',json.dumps({'schema':1,'baseline_lock':lock,
            'files':{n:sha(b) for n,b in files.items()},'seed':{n:sha(b) for n,b in seed_members.items()}},sort_keys=True))
    return {'bytes':output.stat().st_size,'sha256':sha(output.read_bytes()),'baseline_verified':True}
