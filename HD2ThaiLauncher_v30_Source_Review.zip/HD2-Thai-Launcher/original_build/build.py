import ast,hashlib,importlib.util,inspect,json,shutil,subprocess,sys,ssl
from pathlib import Path
root=Path(__file__).resolve().parent;project=root.parent
release=Path(sys.argv[1]).resolve() if len(sys.argv)>1 else root/'dist'
if release.exists():raise FileExistsError('Use a new versioned output directory: '+str(release))
texts=json.loads((root/'installer_text_th.json').read_text(encoding='utf-8'))
version=next(ast.literal_eval(n.value) for n in ast.parse((root/'launcher.py').read_text(encoding='utf-8')).body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='VERSION' for t in n.targets))
version_tuple=tuple(int(x) for x in version.split('.'))
version_tuple=(version_tuple+(0,0,0,0))[:4]
version_string='.'.join(map(str,version_tuple[:3]))
if texts.get('text_approved') is not True:raise ValueError('Installer text requires review')
icon=root/'launcher.ico'
if not icon.is_file():raise FileNotFoundError('Approved launcher icon is missing')
version_file=root/'windows_version_info.txt'
version_file.write_text("VSVersionInfo(ffi=FixedFileInfo(filevers="+repr(version_tuple)+",prodvers="+repr(version_tuple)+",mask=0x3f,flags=0,OS=0x40004,fileType=1,subtype=0,date=(0,0)),kids=[StringFileInfo([StringTable('040904B0',["+
    ','.join('StringStruct('+repr(key)+','+repr(value)+')' for key,value in {
        'CompanyName':texts['publisher'],'FileDescription':texts.get('exe_display_name',texts['app_name']),
        'FileVersion':version_string,'ProductName':texts['app_name'],'ProductVersion':version_string,
        'OriginalFilename':'HD2ThaiLauncher.exe'}.items())+
    "]) ]),VarFileInfo([VarStruct('Translation',[1033,1200])])])",encoding='utf-8')
sys.path.insert(0,str(project/'Translation_Updater'))
import update_translation
from build_language_assets import build as build_assets
asset_dir=root/f'runtime_assets_v{version}'
asset_dir.mkdir(exist_ok=True)
asset_report=build_assets(project,project/'Releases/Translations/HD2_Thai_Translation_v94_PrivateStandalone.zip',asset_dir/'language_assets.zip')
(asset_dir/'language_asset_manifest.json').write_text(json.dumps(asset_report,indent=2),encoding='utf8')
spec=importlib.util.spec_from_file_location('api_runtime',project/'Server_Translation_Research_v1/ProxyProbe_v1/public_text_translation_v7.py')
runtime=importlib.util.module_from_spec(spec);spec.loader.exec_module(runtime)
# Bundle only the pure transform, not research paths, tracing or certificate files.
codec='UPPER='+repr(update_translation.UPPER)+'\nTONE='+repr(update_translation.TONE)+'\nAM='+repr(update_translation.AM)+'\nTALL_MARKS='+repr(update_translation.TALL_MARKS)+'\nTALL_SHIFT='+repr(update_translation.TALL_SHIFT)+'\nCHULA_SHIFT='+repr(update_translation.CHULA_SHIFT)+'\n'+inspect.getsource(update_translation.encode)+'\ndef progress(*args,**kwargs):pass\n'
(root/'thai_codec.py').write_text(codec,encoding='utf-8')
motd_wrapper='''
def candidates(path,body):
    if urlsplit(path).path=='/api/Pes/GetMotd':
        for obj,key,location in motd_fields(body):yield obj,key,('motd',)+location
    else:yield from base_candidates(path,body)
'''
(root/'translation.py').write_text('import copy,hashlib,re\nfrom urllib.parse import urlsplit\nfrom motd_capture import fields as motd_fields\n'+inspect.getsource(runtime.candidates).replace('def candidates(', 'def base_candidates(')+motd_wrapper+'\n'+inspect.getsource(runtime.transform),encoding='utf-8')
source=(project/'Translation_Updater/update_api_translation.py').read_text(encoding='utf-8').replace('from update_translation import encode,progress','from thai_codec import encode,progress')
(root/'api_rules.py').write_text(source,encoding='utf-8')
pointer=json.loads((project/'Translation_Updater/API_Updates/active.json').read_text())
seed=(project/pointer['path']).read_bytes();assert hashlib.sha256(seed).hexdigest()==pointer['sha256']
(root/'seed_rules.json').write_bytes(seed)
(root/'bundle_manifest.json').write_text(json.dumps({'version':1,'seed_sha256':hashlib.sha256(seed).hexdigest(),'seed_rules':len(json.loads(seed))},indent=2))
args=[sys.executable,'-m','PyInstaller','--noconfirm','--clean','--onedir','--windowed','--name','HD2ThaiLauncher',
 '--icon',str(icon),'--version-file',str(version_file),
 '--manifest',str(root/'app.manifest'),'--add-data',str(icon)+';.',
 '--distpath',str(release),'--workpath',str(root/'build'),'--specpath',str(root),
 '--collect-all','mitmproxy','--collect-all','mitmproxy_rs','--collect-all','certifi',
 '--paths',str(project/'Translation_Updater'),
 '--hidden-import','update_translation','--hidden-import','ui_review','--hidden-import','three_languages',
 '--hidden-import','hot_swap_tables','--hidden-import','project_paths',
 '--hidden-import','api_linebreaks','--hidden-import','thai_linebreaks','--hidden-import','context_markup','--hidden-import','sheet_markup_rules',
 '--add-data',str(asset_dir/'language_assets.zip')+';.',
 '--add-data',str(asset_dir/'language_asset_manifest.json')+';.',
 '--add-data',str(root/'seed_rules.json')+';.', '--add-data',str(root/'bundle_manifest.json')+';.',str(root/'launcher.py')]
# This Python distribution's SSLContext requires this bundled trust-policy file.
# Preserve that policy in the frozen executable as well as normal Python runs.
ssl_policy=Path(ssl.__file__).with_name('codex-rejected-cas.pem')
if ssl_policy.is_file():args[-1:-1]=['--add-data',str(ssl_policy)+';.']
result=subprocess.call(args,cwd=root)
if result:raise SystemExit(result)
# Keep importable modules required at startup, but omit optional local/transparent
# interception executables and drivers. This launcher only uses regular HTTP proxy.
removed=[]
dist=release/'HD2ThaiLauncher'
for package in ['mitmproxy_windows','pydivert']:
    base=(dist/'_internal'/package).resolve()
    for file in base.rglob('*'):
        if file.is_file() and file.name.lower() in {'windivert.dll','windivert64.sys','windivert32.sys','windows-redirector.exe'}:
            file.resolve().relative_to(dist.resolve())
            removed.append(str(file.relative_to(dist)));file.unlink()
(release/'optional_components_omitted.json').write_text(json.dumps({'regular_proxy_only':True,'omitted':removed},indent=2),encoding='utf-8')
shutil.copytree(project/'Releases/Launcher/HD2_Thai_Launcher_v8/ThirdPartyNotices',dist/'ThirdPartyNotices')
branding=dist/'branding';branding.mkdir()
shutil.copyfile(icon,branding/f'launcher_v{version}.ico')
import zipfile
with zipfile.ZipFile(asset_dir/'language_assets.zip') as archive:
    for name in archive.namelist():
        if name.startswith('seed/LICENSES/') and not name.endswith('/'):
            target=dist/name.removeprefix('seed/');target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(archive.read(name))
