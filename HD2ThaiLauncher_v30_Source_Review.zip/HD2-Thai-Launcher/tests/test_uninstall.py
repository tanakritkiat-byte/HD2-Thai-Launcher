import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'Player_Launcher_v1'))
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import Mock,patch
import launcher

class UninstallTests(unittest.TestCase):
    def test_game_running_blocks_cleanup(self):
        with patch.object(launcher,'game_pids',return_value=[123]),patch.object(launcher,'command') as command:
            with self.assertRaises(ValueError):launcher.prepare_uninstall(Path('unused'))
            command.assert_not_called()

    def test_absent_certificate_does_not_delete_anything(self):
        with patch('mod_session.cleanup'),patch.object(launcher,'game_pids',return_value=[]),patch.object(launcher,'certificate_installed',return_value=False),patch.object(launcher,'command') as command:
            launcher.prepare_uninstall(Path('unused'))
            command.assert_not_called()

    def certificate_case(self,fingerprint=b'\x11'*20,name='HD2 Thai Translation - Local example',cancel=False):
        with patch('mod_session.cleanup'),patch.object(Path,'read_text',return_value=json.dumps({'thumbprint':'11'*20})),patch.object(Path,'read_bytes',return_value=b'test'),patch.object(Path,'unlink') as unlink:
            state=Path('mock-state')
            ca=Mock();ca.fingerprint.return_value=fingerprint
            cn=Mock();cn.value=name;ca.subject.get_attributes_for_oid.return_value=[cn]
            with patch.object(launcher,'game_pids',return_value=[]),patch.object(launcher,'certificate_installed',return_value=True),patch('cryptography.x509.load_der_x509_certificate',return_value=ca),patch.object(launcher,'trusted',return_value=False),patch.object(launcher,'command',return_value=Mock(returncode=int(cancel))) as command:
                if fingerprint!=b'\x11'*20 or not name.startswith('HD2 Thai Translation - Local '):
                    with self.assertRaises(ValueError):launcher.prepare_uninstall(state)
                    command.assert_not_called()
                elif cancel:
                    with self.assertRaises(ValueError):launcher.prepare_uninstall(state)
                else:
                    launcher.prepare_uninstall(state)
                    command.assert_called_once_with(['certutil.exe','-user','-delstore','Root','11'*20],timeout=240)
                    unlink.assert_not_called()

    def test_identity_mismatch_never_deletes(self):self.certificate_case(fingerprint=b'\x22'*20)
    def test_foreign_name_never_deletes(self):self.certificate_case(name='Other root certificate')
    def test_exact_local_identity_only(self):self.certificate_case()
    def test_cancelled_removal_reports_failure(self):self.certificate_case(cancel=True)

if __name__=='__main__':unittest.main()
