import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'Player_Launcher_v1'))
"""File-lifetime and Steam discovery tests; only disposable workspace folders."""
import json,tempfile,unittest
from pathlib import Path
import game_discovery as discovery
import mod_session as session
from unittest.mock import patch

class AllInOne(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory(dir=Path(__file__).parent/'testdata')
        self.root=Path(self.temp.name);self.state=self.root/'state';self.state.mkdir()
        self.game=self.root/'game';(self.game/'data').mkdir(parents=True)
        (self.game/'start_protected_game.exe').touch()
        self.stage=self.root/'patches';self.stage.mkdir()
        for n,body in [('a'*16+'.patch_3',b'text'),('a'*16+'.patch_4',b'boot'),('b'*16+'.patch_0',b'font'),('b'*16+'.patch_0.stream',b'')]:
            (self.stage/n).write_bytes(body)
    def tearDown(self):self.temp.cleanup()
    def test_lifetime_and_existing_files(self):
        old=self.game/'data'/('a'*16+'.patch_0');old.write_bytes(b'other mod')
        report=session.deploy(self.state,self.game,self.stage,lambda:False)
        self.assertEqual(len(report['files']),4)
        self.assertEqual((self.game/'data'/('a'*16+'.patch_1')).read_bytes(),b'text')
        self.assertFalse(session.cleanup(self.state,lambda:True))
        self.assertEqual(old.read_bytes(),b'other mod')
        self.assertTrue(session.cleanup(self.state,lambda:False))
        self.assertEqual(list((self.game/'data').iterdir()),[old])
    def test_conflict_retained(self):
        info=session.deploy(self.state,self.game,self.stage,lambda:False)
        target=self.game/'data'/info['files'][0]['name'];target.write_bytes(b'changed')
        with self.assertRaises(ValueError):session.cleanup(self.state,lambda:False)
        self.assertEqual(target.read_bytes(),b'changed')
        self.assertTrue((self.state/'mod_session.json').exists())
    def test_gap_refused_without_writes(self):
        (self.game/'data'/('a'*16+'.patch_2')).write_bytes(b'old')
        with self.assertRaises(ValueError):session.deploy(self.state,self.game,self.stage,lambda:False)
        self.assertFalse((self.state/'mod_session.json').exists())
        self.assertEqual(len(list((self.game/'data').iterdir())),1)
    def test_manifest_and_library(self):
        steam=self.root/'steam';(steam/'steamapps').mkdir(parents=True)
        library=self.root/'custom library';apps=library/'steamapps';apps.mkdir(parents=True)
        installed=apps/'common'/'renamed game';self.game.rename(installed.parent.mkdir(parents=True) or installed)
        (steam/'steamapps/libraryfolders.vdf').write_text('"libraryfolders" { "0" { "path" '+json.dumps(str(library))+' } }')
        (apps/'appmanifest_553850.acf').write_text('"AppState" { "appid" "553850" "installdir" "renamed game" }')
        self.assertEqual(discovery.discover(self.state,roots=[steam],drives=[]),installed.resolve())
        discovery.remember(self.state,installed)
        self.assertEqual(discovery.discover(self.state,roots=[],drives=[]),installed.resolve())
    def test_traversal_refused(self):
        steam=self.root/'steam';apps=steam/'steamapps';apps.mkdir(parents=True)
        (apps/'appmanifest_553850.acf').write_text('"appid" "553850" "installdir" "../../game"')
        self.assertIsNone(discovery.discover(self.state,roots=[steam],drives=[]))
    def test_active_game_refused(self):
        with self.assertRaises(ValueError):session.deploy(self.state,self.game,self.stage,lambda:True)
        self.assertEqual(list((self.game/'data').iterdir()),[])
    def test_old_watcher_cannot_clean_new_session(self):
        info=session.deploy(self.state,self.game,self.stage,lambda:False)
        self.assertTrue(session.cleanup(self.state,lambda:False,expected='old-session'))
        self.assertTrue((self.state/'mod_session.json').exists())
        session.watch(self.state,lambda:False,lambda:False,'old-session')
        self.assertTrue((self.game/'data'/info['files'][0]['name']).exists())
    def test_watcher_cleans_after_game_exit(self):
        info=session.deploy(self.state,self.game,self.stage,lambda:False)
        with patch.object(session.time,'sleep'),patch.object(session,'cleanup',wraps=session.cleanup) as clean:
            states=iter([True,False,False,False])
            session.watch(self.state,lambda:False,lambda:next(states),info['session_id'])
            clean.assert_called_once()
        self.assertEqual(list((self.game/'data').iterdir()),[])
    def test_run_game_installs_before_start_and_cleans(self):
        import launcher
        def start(*args):
            self.assertTrue((self.game/'data'/('a'*16+'.patch_0')).exists())
            self.assertTrue((self.state/'mod_session.json').exists())
        with patch.object(launcher,'game_pids',return_value=[]),patch('language_runtime.compile_latest',return_value=(self.stage,{'test':True})),patch.object(launcher.subprocess,'Popen') as watcher,patch.object(launcher,'_run_game_api',side_effect=start):
            launcher.run_game(self.state,self.game,lambda text:None)
            self.assertIn('--watch-session',watcher.call_args.args[0])
        self.assertEqual(list((self.game/'data').iterdir()),[])

if __name__=='__main__':unittest.main()
