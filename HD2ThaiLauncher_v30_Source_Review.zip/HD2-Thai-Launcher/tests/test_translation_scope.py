import sys,unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'Player_Launcher_v1'))
from translation import transform
import hashlib
class Scope(unittest.TestCase):
 def test_exact_source_only_changes_display_field(self):
  source='Review test message';digest=hashlib.sha256(source.encode()).hexdigest()
  rules={digest:{'api_id':'API-'+digest[:8].upper(),'english':source,'thai':'ข้อความทดสอบ','encoded_thai':'ข้อความทดสอบ'}}
  body=[{'message':source,'progress':123,'accountId':'untouched'}]
  result,applied=transform('/api/NewsFeed/801',body,rules)
  self.assertEqual(result[0]['message'],'ข้อความทดสอบ')
  self.assertEqual(result[0]['progress'],123)
  self.assertEqual(result[0]['accountId'],'untouched')
  self.assertEqual(body[0]['message'],source)
  self.assertEqual(len(applied),1)
 def test_unknown_path_is_unchanged(self):
  body={'message':'untouched'}
  self.assertEqual(transform('/unknown',body,{})[0],body)
 def test_motd_private_fields_are_not_candidates(self):
  from motd_capture import fields
  found=[obj[key] for obj,key,path in fields({'title':'public','accessToken':'private','account':{'title':'private'}})]
  self.assertEqual(found,['public'])
if __name__=='__main__':unittest.main()
