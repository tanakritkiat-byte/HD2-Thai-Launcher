import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'Player_Launcher_v1'))
import json
from pathlib import Path
import unittest
from unittest.mock import patch
import launcher

class QuickLaunchTests(unittest.TestCase):
    def scenario(self,confirmed=False,onboarded=False,trusted=False,accepted=True,cancel_certificate=False):
        state=Path('mock-state');folder=Path('mock-game');writes=[];order=[]
        def progress(bundle,work):
            order.append('progress');work(lambda text:None)
        def trust(*args):
            order.append('certificate')
            if cancel_certificate:raise ValueError('cancelled')
        with patch('mod_session.cleanup'),patch('game_discovery.remember',return_value=folder),patch('game_discovery.valid_game',return_value=True),patch('game_discovery.location_confirmed',return_value=confirmed),patch('launch_flow_ui.confirm_game_folder',return_value=folder if accepted else None) as folder_ui,patch('launch_flow_ui.launch_with_progress',side_effect=progress),patch.object(launcher,'game_pids',return_value=[]),patch.object(Path,'read_text',return_value=json.dumps({'version':2 if onboarded else 0})),patch.object(launcher,'certificate_installed',return_value=trusted),patch.object(launcher,'certificate',return_value=('thumb',Path('cert'))),patch.object(launcher,'ensure_trusted',side_effect=trust),patch.object(launcher,'confirm_first_run',return_value=accepted) as intro,patch.object(launcher,'game_folder',return_value=folder),patch.object(launcher,'run_game') as start,patch.object(launcher,'atomic',side_effect=lambda p,v:writes.append((p,v))):
            if cancel_certificate:
                with self.assertRaises(ValueError):launcher.quick_launch(state)
            else:launcher.quick_launch(state)
            return folder_ui.call_count,intro.call_count,start.call_count,writes,order

    def test_first_launch_confirms_folder_before_certificate_and_progress(self):
        folder,intro,starts,writes,order=self.scenario()
        self.assertEqual((folder,intro,starts),(1,0,1))
        self.assertEqual(order,['certificate','progress'])
        self.assertIn((Path('mock-state/onboarding.json'),{'version':2}),writes)
    def test_cancel_folder_does_not_start(self):
        folder,intro,starts,writes,order=self.scenario(accepted=False)
        self.assertEqual((folder,starts),(1,0));self.assertFalse(writes);self.assertFalse(order)
    def test_repeat_launch_only_shows_progress(self):
        folder,intro,starts,_,order=self.scenario(confirmed=True,onboarded=True,trusted=True)
        self.assertEqual((folder,intro,starts),(0,0,1));self.assertEqual(order,['progress'])
    def test_removed_certificate_explains_again(self):
        _,intro,starts,_,order=self.scenario(confirmed=True,onboarded=True,trusted=False)
        self.assertEqual((intro,starts),(1,1));self.assertEqual(order,['certificate','progress'])
    def test_cancel_certificate_does_not_start_or_mark_setup_complete(self):
        _,_,starts,writes,order=self.scenario(cancel_certificate=True)
        self.assertEqual(starts,0);self.assertFalse(writes);self.assertEqual(order,['certificate'])
    def test_v16_users_also_get_folder_confirmation_once(self):
        folder,intro,starts,_,order=self.scenario(confirmed=False,onboarded=True,trusted=True)
        self.assertEqual((folder,intro,starts),(1,0,1));self.assertEqual(order,['progress'])
    def test_existing_game_does_not_start_another(self):
        with patch.object(launcher,'game_pids',return_value=[1]),patch.object(launcher,'run_game') as start:
            with self.assertRaises(ValueError):launcher.quick_launch(Path('unused'))
            start.assert_not_called()

if __name__=='__main__':unittest.main()
