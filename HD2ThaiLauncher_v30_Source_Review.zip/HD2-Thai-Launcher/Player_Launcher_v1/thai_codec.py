UPPER={'ํ', '็', 'ี', 'ิ', 'ื', 'ั', 'ึ'}
TONE={'่': '\ue004', '้': '\ue001', '๊': '\ue002', '๋': '\ue003'}
AM={'่': '\ue006', '้': '\ue007', '๊': '\ue008', '๋': '\ue009'}
TALL_MARKS='ัิีึื็่้๊๋์ํ๎\ue001\ue002\ue003\ue004\ue005\ue006\ue007\ue008\ue009'
TALL_SHIFT={'ั': '\ue100', 'ิ': '\ue101', 'ี': '\ue102', 'ึ': '\ue103', 'ื': '\ue104', '็': '\ue105', '่': '\ue106', '้': '\ue107', '๊': '\ue108', '๋': '\ue109', '์': '\ue10a', 'ํ': '\ue10b', '๎': '\ue10c', '\ue001': '\ue10d', '\ue002': '\ue10e', '\ue003': '\ue10f', '\ue004': '\ue110', '\ue005': '\ue111', '\ue006': '\ue112', '\ue007': '\ue113', '\ue008': '\ue114', '\ue009': '\ue115'}
CHULA_SHIFT={'ั': '\ue140', 'ิ': '\ue141', 'ี': '\ue142', 'ึ': '\ue143', 'ื': '\ue144', '็': '\ue145', '่': '\ue146', '้': '\ue147', '๊': '\ue148', '๋': '\ue149', '์': '\ue14a', 'ํ': '\ue14b', '๎': '\ue14c', '\ue001': '\ue14d', '\ue002': '\ue14e', '\ue003': '\ue14f', '\ue004': '\ue150', '\ue005': '\ue151', '\ue006': '\ue152', '\ue007': '\ue153', '\ue008': '\ue154', '\ue009': '\ue155'}
def encode(text):
    out = []
    base = ''
    for i, char in enumerate(text):
        previous = text[i - 1] if i else ''
        following = text[i + 1:i + 2]
        if char in TONE and previous in UPPER:
            char = TONE[char]
        elif char in AM and following == 'ำ':
            char = AM[char]
        elif char == '์' and previous in UPPER:
            char = '\ue005'
        if base in ('ป','ฝ','ฟ') and char in TALL_SHIFT:
            char=TALL_SHIFT[char]
        elif base == 'ฬ' and char in CHULA_SHIFT:
            char=CHULA_SHIFT[char]
        out.append(char)
        raw=text[i]
        if '\u0e01'<=raw<='\u0e2e':base=raw
        elif raw not in TALL_MARKS and raw not in '\u0e38\u0e39\u0e3a':base=''
    return ''.join(out)

def progress(*args,**kwargs):pass
