"""Own patch lifetime: exclusive creation, durable journal, hash-checked cleanup."""
import contextlib,hashlib,json,os,re,time,uuid,struct
from pathlib import Path

PATTERN=re.compile(r'^([0-9a-f]{16})\.patch_(\d+)(\.gpu_resources|\.stream)?$')

def digest(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def boot_payload(path):
    """Recognize the exact boot Lua resource, without reading unrelated payloads."""
    with Path(path).open('rb') as stream:
        header=stream.read(72)
        if len(header)!=72:return None
        types,entries=struct.unpack_from('<II',header,4)
        if types>1024 or entries>100000:return None
        stream.seek(72+32*types)
        for _ in range(entries):
            raw=stream.read(80)
            if len(raw)!=80:return None
            e=struct.unpack('<7Q6I',raw)
            if e[0]==0xf476df93691895fa and e[1]==0xa14e8dfa2cd117e2:
                if e[7]>16000000:raise ValueError('Boot script exceeds expected size')
                stream.seek(e[2]);return stream.read(e[7])
    return None

def save(path,value):
    tmp=path.with_suffix('.tmp');tmp.write_text(json.dumps(value,ensure_ascii=False,indent=2),encoding='utf8');os.replace(tmp,path)

@contextlib.contextmanager
def lock(state):
    import msvcrt
    state=Path(state);state.mkdir(parents=True,exist_ok=True)
    with (state/'session.lock').open('a+b') as stream:
        if stream.tell()==0:stream.write(b'0');stream.flush()
        stream.seek(0);msvcrt.locking(stream.fileno(),msvcrt.LK_LOCK,1)
        try:yield
        finally:stream.seek(0);msvcrt.locking(stream.fileno(),msvcrt.LK_UNLCK,1)

def cleanup(state,game_running,expected=None):
    state=Path(state)
    with lock(state):
        journal=state/'mod_session.json'
        if not journal.exists():return True
        if game_running():return False
        info=json.loads(journal.read_text(encoding='utf8'))
        if expected and info.get('session_id')!=expected:return True
        if info.get('owner')!='HD2ThaiLauncher' or info.get('schema')!=1:raise ValueError('Invalid mod session journal')
        data=Path(info['data']).resolve()
        if data.name.lower()!='data' or not (data.parent/'start_protected_game.exe').is_file():raise ValueError('Invalid cleanup folder')
        conflicts=[]
        for item in info['files']:
            name=item['name']
            if not PATTERN.fullmatch(name):raise ValueError('Invalid cleanup filename')
            target=data/name
            if target.resolve().parent!=data:raise ValueError('Unsafe cleanup path')
            if target.exists():
                if digest(target)!=item['sha256']:conflicts.append(name)
                else:target.unlink()
            # Only a private, per-session temporary name can contain a partial
            # copy after power loss. The actual game patch is published whole.
            token=info.get('session_id','')
            if re.fullmatch('[0-9a-f]{32}',token):
                temporary=data/f'.hd2thai-{token}-{name}.tmp'
                if temporary.resolve().parent!=data:raise ValueError('Unsafe temporary path')
                temporary.unlink(missing_ok=True)
        if conflicts:
            info['conflicts']=conflicts;save(journal,info)
            raise ValueError('ไฟล์คำแปลถูกเปลี่ยนโดยโปรแกรมอื่น จึงยังไม่ลบ: '+', '.join(conflicts))
        journal.unlink();return True

def deploy(state,folder,staging,game_running):
    state=Path(state);folder=Path(folder).resolve();data=(folder/'data').resolve()
    if not (folder/'start_protected_game.exe').is_file() or not data.is_dir():raise ValueError('ไม่พบโฟลเดอร์เกม')
    with lock(state):
        if game_running():raise ValueError('กรุณาปิดเกมก่อนติดตั้งคำแปล')
        journal=state/'mod_session.json'
        if journal.exists():raise ValueError('ยังมีไฟล์จากรอบก่อน กรุณาเปิด Launcher ใหม่เพื่อเก็บกวาดก่อน')
        sources={p.name:p for p in Path(staging).iterdir() if p.is_file()}
        groups={}
        for name,p in sources.items():
            match=PATTERN.fullmatch(name)
            if not match:raise ValueError('Invalid staged patch: '+name)
            groups.setdefault((match[1],int(match[2])),[]).append((match[3] or '',p))
        if not groups:raise ValueError('ไม่มีไฟล์คำแปลสำหรับติดตั้ง')
        boot_sources=[boot_payload(p) for name,p in sources.items() if (m:=PATTERN.fullmatch(name)) and not m[3] and m[1]=='9ba626afa44a3aa3']
        own_boot=next((b for b in boot_sources if b is not None),None)
        if own_boot is not None:
            for existing in data.iterdir():
                m=PATTERN.fullmatch(existing.name)
                if m and m[1]=='9ba626afa44a3aa3' and not m[3]:
                    boot=boot_payload(existing)
                    if boot is not None and boot!=own_boot:
                        raise ValueError('พบม็อดตัวโหลดสคริปต์ที่ใช้ไฟล์เดียวกับระบบสลับภาษา กรุณาปิดม็อดตัวโหลดสคริปต์นั้นใน Arsenal ก่อน')
        next_index={};plan=[]
        for (archive,index),members in sorted(groups.items()):
            if not any(not suffix for suffix,p in members):raise ValueError('Patch sidecar without main archive')
            if archive not in next_index:
                occupied={int(m[2]) for p in data.iterdir() if (m:=PATTERN.fullmatch(p.name)) and m[1]==archive}
                # A missing patch number may stop the engine scanning later ones.
                if occupied and occupied!=set(range(max(occupied)+1)):
                    raise ValueError('ลำดับม็อดเดิมมีช่องว่าง กรุณาจัดเรียงม็อดใน Arsenal ก่อน: '+archive)
                next_index[archive]=max(occupied,default=-1)+1
            number=next_index[archive];next_index[archive]+=1
            for suffix,p in members:
                name=f'{archive}.patch_{number}{suffix}'
                if (data/name).exists():raise FileExistsError(name)
                plan.append({'name':name,'sha256':digest(p),'source':str(p)})
        info={'schema':1,'owner':'HD2ThaiLauncher','session_id':uuid.uuid4().hex,'data':str(data),'parent_pid':os.getpid(),
              'files':[{k:v for k,v in item.items() if k!='source'} for item in plan]}
        save(journal,info)
        for item in plan:
            target=data/item['name']
            if target.resolve().parent!=data:raise ValueError('Unsafe deployment path')
            temporary=data/f'.hd2thai-{info["session_id"]}-{item["name"]}.tmp'
            with temporary.open('xb') as stream:
                stream.write(Path(item['source']).read_bytes());stream.flush();os.fsync(stream.fileno())
            # os.rename on Windows fails when the destination already exists;
            # unlike replace(), it cannot overwrite an Arsenal-owned file.
            os.rename(temporary,target)
        return info

def watch(state,parent_alive,game_running,expected):
    seen=False;orphan_since=None
    while (Path(state)/'mod_session.json').exists():
        try:
            if json.loads((Path(state)/'mod_session.json').read_text(encoding='utf8')).get('session_id')!=expected:return
        except FileNotFoundError:return
        if game_running():seen=True;orphan_since=None
        elif seen:
            time.sleep(3)
            if not game_running():
                cleanup(state,game_running,expected);return
        elif not parent_alive():
            orphan_since=orphan_since or time.monotonic()
            if time.monotonic()-orphan_since>125:cleanup(state,game_running,expected);return
        time.sleep(2)
