"""Launcher presentation only. No downloads, game start or certificate changes."""
import ctypes
import os
from types import SimpleNamespace


def enable_high_dpi():
    try:
        ctypes.windll.user32.SetProcessDpiAwarenessContext(ctypes.c_void_p(-4))
    except (AttributeError,OSError):
        try:ctypes.windll.shcore.SetProcessDpiAwareness(1)
        except (AttributeError,OSError):pass


def create_window(version,bundle,frozen,preview=False,scale_override=None):
    enable_high_dpi()
    import tkinter as tk
    from tkinter import ttk
    root=tk.Tk();root.withdraw()
    root.title('HELLDIVERS 2 ม็อดภาษาไทย · Pa-Kai'+(' · ตัวอย่าง' if preview else ''))
    try:dpi=ctypes.windll.user32.GetDpiForWindow(root.winfo_id()) or 96
    except (AttributeError,OSError):dpi=96
    scale=scale_override if scale_override is not None else dpi/96
    d=lambda n:max(1,round(n*scale)) if n else 0
    # Negative font sizes are native device pixels: Windows never stretches a
    # low-resolution screenshot of this UI, and Tk does not double-scale text.
    font=lambda size,bold=False:('Leelawadee UI',-d(size*96/72),'bold' if bold else 'normal')
    bg,card,fg,muted,yellow='#0d1117','#151c25','#f3f5f7','#a4afbd','#f4d54b'
    border='#29323e'
    root.configure(bg=bg)
    width=min(d(860),root.winfo_screenwidth()-d(40))
    height=min(d(780),root.winfo_screenheight()-d(80))
    root.geometry(f'{width}x{height}')
    root.minsize(min(d(760),width),min(d(700),height))
    icon=bundle/'launcher.ico'
    if icon.is_file():root.iconbitmap(str(icon))
    style=ttk.Style(root);style.theme_use('clam')
    style.configure('HD.Horizontal.TProgressbar',troughcolor=border,background=yellow,
                    borderwidth=0,lightcolor=yellow,darkcolor=yellow,thickness=d(3))
    outer=tk.Frame(root,bg=bg,padx=d(28),pady=d(24));outer.pack(fill='both',expand=True)
    def label(parent,text,size=11,color=fg,bold=False,**kw):
        return tk.Label(parent,text=text,font=font(size,bold),fg=color,bg=parent.cget('bg'),
                        anchor='w',justify='left',borderwidth=0,**kw)
    header=tk.Frame(outer,bg=bg);header.pack(fill='x',pady=(0,d(22)))
    tk.Frame(header,bg=yellow,width=d(4)).pack(side='left',fill='y',padx=(0,d(14)))
    brand=tk.Frame(header,bg=bg);brand.pack(side='left')
    label(brand,'HELLDIVERS 2 ม็อดภาษาไทย',23,bold=True).pack(anchor='w')
    label(brand,'โดย Pa-Kai',10,muted).pack(anchor='w',pady=(d(3),0))

    # Sticky actions are reserved before content; Play stays visible on short
    # screens, even if the user reduces the window height.
    footer=tk.Frame(outer,bg=bg);footer.pack(side='bottom',fill='x',pady=(d(15),0))
    launch=tk.Frame(outer,bg=bg);launch.pack(side='bottom',fill='x',pady=(d(18),0))
    button=tk.Button(launch,text='เปิดเกม',font=font(17,True),bg=yellow,fg='#10151b',
                     activebackground='#ffe470',activeforeground='#10151b',disabledforeground='#68634b',
                     relief='flat',borderwidth=0,pady=d(12),cursor='hand2',takefocus=True,
                     highlightthickness=d(1),highlightbackground=yellow,highlightcolor='#ffffff')
    button.pack(fill='x')
    content=tk.Frame(outer,bg=bg);content.pack(fill='both',expand=True)
    hero_border=tk.Frame(content,bg=border,padx=d(1),pady=d(1));hero_border.pack(fill='x')
    hero=tk.Frame(hero_border,bg=card,padx=d(22),pady=d(20));hero.pack(fill='x')
    label(hero,'ส่วนเสริมคำแปล',11,yellow,True).pack(anchor='w',pady=(0,d(7)))
    label(hero,'Major Order & Control Center',21,bold=True).pack(anchor='w')
    description=label(hero,'ดาวน์โหลดคำแปลล่าสุดทุกครั้งที่เปิดเกม ทั้งข่าว ประกาศ และแคมเปญ\nม็อดภาษาไทยแบบปกติไม่สามารถแปลข้อความส่วนนี้ได้',11,muted,wraplength=d(700))
    description.pack(anchor='w',pady=(d(12),0))

    help_box=tk.Frame(content,bg=bg);help_box.pack(fill='x',pady=(d(22),d(18)))
    help_box.columnconfigure(0,weight=1,uniform='help');help_box.columnconfigure(1,weight=1,uniform='help')
    help_labels=[]
    for column,title,body in [
        (0,'01  ก่อนเริ่มใช้งาน','ติดตั้งม็อดภาษาไทยผ่าน Arsenal และเปิด Steam พร้อมเข้าสู่ระบบไว้ก่อน'),
        (1,'02  การเปิดครั้งแรก','Windows จะถามยืนยันใบรับรอง ทำครั้งเดียวสำหรับเครื่องนี้\nตรวจชื่อ HD2 Thai Translation - Local แล้วกด Yes ได้เลย')]:
        pane=tk.Frame(help_box,bg=bg);pane.grid(row=0,column=column,sticky='nsew',padx=(0,d(20)) if column==0 else (d(20),0))
        label(pane,title,10,muted,True).pack(anchor='w',pady=(0,d(8)))
        text=label(pane,body,10,muted,wraplength=d(340));text.pack(anchor='w',fill='x');help_labels.append((pane,text))

    tk.Frame(content,bg=border,height=d(1)).pack(fill='x')
    status=tk.StringVar(value='พร้อมเปิดเกม' if not preview else 'พร้อมเปิดเกม · ตัวอย่างหน้าตา')
    translation_status=tk.StringVar(value='พร้อมอัปเดตเมื่อกดเปิดเกม')
    status_box=tk.Frame(content,bg=bg,pady=d(16));status_box.pack(fill='x');status_box.columnconfigure(1,weight=1)
    label(status_box,'คำแปล',10,muted).grid(row=0,column=0,sticky='nw',padx=(0,d(24)),pady=d(4))
    translation_label=label(status_box,'',11,wraplength=d(650),textvariable=translation_status)
    translation_label.grid(row=0,column=1,sticky='w',pady=d(4))
    label(status_box,'เกม',10,muted).grid(row=1,column=0,sticky='nw',padx=(0,d(24)),pady=d(4))
    status_label=label(status_box,'',11,wraplength=d(650),textvariable=status)
    status_label.grid(row=1,column=1,sticky='w',pady=d(4))
    progress=ttk.Progressbar(content,mode='indeterminate',style='HD.Horizontal.TProgressbar');progress.pack(fill='x')

    certificate_actions=tk.Frame(footer,bg=bg)
    remove=tk.Button(certificate_actions,text='ถอนใบรับรอง…',relief='flat',borderwidth=0,
                     bg='#943445',fg='#ffffff',activebackground='#b44054',activeforeground='#ffffff',
                     disabledforeground='#c899a2',font=font(10,True),padx=d(12),pady=d(7),cursor='hand2')
    remove.pack(side='left')
    label(certificate_actions,'ที่คุณอนุญาตตอนเปิดใช้งานครั้งแรก',8,muted,wraplength=d(190)).pack(side='left',padx=(d(10),0))
    label(footer,'v'+version,9,muted).pack(side='right')
    notices=bundle.parent/'ThirdPartyNotices' if frozen else bundle/'ThirdPartyNotices'
    if notices.is_dir():
        tk.Button(footer,text='ใบอนุญาตส่วนประกอบ',command=lambda:os.startfile(notices),relief='flat',borderwidth=0,
                  bg=bg,fg=muted,activebackground=bg,activeforeground=fg,font=font(9),cursor='hand2').pack(side='right',padx=(d(8),d(14)))
    def reflow(_=None):
        description.configure(wraplength=max(d(200),hero.winfo_width()-d(44)))
        for pane,text in help_labels:text.configure(wraplength=max(d(150),pane.winfo_width()))
        for text in (translation_label,status_label):text.configure(wraplength=max(d(180),status_box.winfo_width()-d(90)))
    content.bind('<Configure>',reflow)
    root.update_idletasks();reflow();root.deiconify()
    try:
        dark=ctypes.c_int(1);hwnd=ctypes.windll.user32.GetParent(root.winfo_id())
        ctypes.windll.dwmapi.DwmSetWindowAttribute(hwnd,20,ctypes.byref(dark),ctypes.sizeof(dark))
    except (AttributeError,OSError):pass
    return SimpleNamespace(root=root,status=status,translation_status=translation_status,translation_label=translation_label,
                           progress=progress,button=button,remove=remove,certificate_actions=certificate_actions,
                           fg=fg,scale=scale,dpi=dpi)
