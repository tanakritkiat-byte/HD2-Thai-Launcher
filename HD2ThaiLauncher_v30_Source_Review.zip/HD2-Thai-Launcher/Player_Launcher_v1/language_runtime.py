"""Compile fresh Sheet text using the exact existing validators and builders."""
import csv,hashlib,importlib.util,json,os,shutil,urllib.request,zipfile
from pathlib import Path

def sha(raw):return hashlib.sha256(raw).hexdigest()

def assets(bundle,state):
    manifest=json.loads((bundle/'language_asset_manifest.json').read_text(encoding='utf8'))
    archive=bundle/'language_assets.zip'
    if sha(archive.read_bytes())!=manifest['sha256']:raise ValueError('Language asset checksum mismatch')
    root=state/('language_inputs_'+manifest['sha256'][:16]);root.mkdir(exist_ok=True)
    with zipfile.ZipFile(archive) as z:
        info=json.loads(z.read('manifest.json'))
        for name,digest in {**info['files'],**{'seed/'+k:v for k,v in info['seed'].items()}}.items():
            target=root/name;target.resolve().relative_to(root.resolve())
            if not target.is_file() or sha(target.read_bytes())!=digest:
                raw=z.read(name)
                if sha(raw)!=digest:raise ValueError('Bundled input checksum: '+name)
                target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(raw)
    return root,info,manifest

def compile_latest(bundle,state,notify=lambda text:None):
    import update_translation as updater
    import ui_review
    import three_languages
    notify('กำลังตรวจไฟล์ฟอนต์…')
    root,info,manifest=assets(bundle,state)
    updater.progress=lambda *args,**kwargs:None
    # A fresh fetch on every run. A download/validation failure stops launch;
    # never silently substitute an older main translation.
    urllib.request.install_opener(urllib.request.build_opener(urllib.request.ProxyHandler({})))
    import argparse,time
    build=state/'language_builds'/str(time.time_ns());build.mkdir(parents=True)
    notify('กำลังดึงคำแปลหลักล่าสุด…')
    original,_=updater.get_input(argparse.Namespace(csv=None,export_url_file=None),build)
    rows=updater.read_csv(original)
    lock=info['baseline_lock']
    notify('กำลังตรวจคำแปลและวรรณยุกต์…')
    from sheet_markup_rules import load_review_rules,commit_review_rules
    notify('กำลังตรวจเงื่อนไขคำแปลล่าสุด…')
    markup_rules=load_review_rules(build,state)
    encoded,count,_=updater.validate(rows,updater.read_csv(root/lock['baseline_csv']),build,markup_rules=markup_rules)
    commit_review_rules(build,state)
    spec=importlib.util.spec_from_file_location('hd2_locked_builder',root/lock['builder'])
    builder=importlib.util.module_from_spec(spec);spec.loader.exec_module(builder)
    builder.SHEET_CSV=encoded;builder.GAME_STRINGS=root/lock['game_strings'];builder.TEMPLATE_PATCH=root/'translation_template.patch'
    sheet=builder.read_sheet();patch,_=builder.build_profile(sheet,False)
    patch,modes=three_languages.build(builder,patch,sheet,builder.GAME_STRINGS,hot_swap_tables=True,private_modes=True)
    ui_review.HERE=root/'Translation_Updater'
    notify('กำลังดึงและตรวจคำแปลส่วนเมนู…')
    extras,ui_report=ui_review.build(root,build,rows,updater.encode,False,clean_labels=True)
    files={Path(n).name:(root/'seed'/n).read_bytes() for n in info['seed'] if '.patch_' in n}
    files['9ba626afa44a3aa3.patch_3']=patch
    for n,b in extras.items():
        if '.patch_' in n:files[Path(n).name]=b
    active=root/'Translation_Updater/active_font_profile.json'
    fonts=json.loads((active if active.exists() else root/'Translation_Updater/ui_review_lock.json').read_text(encoding='utf8'))
    for n,digest in fonts['font_members'].items():
        if sha(files[Path(n).name])!=digest:raise ValueError('Runtime font changed')
    staging=build/'patches';staging.mkdir()
    for n,b in files.items():(staging/n).write_bytes(b)
    report={'rows':count,'main_sha256':sha(original.read_bytes()),'ui_sha256':ui_report['sheet_csv_sha256'],
            'files':{n:sha(b) for n,b in files.items()},'asset_sha256':manifest['sha256'],
            'private_modes':modes['private_modes'],'in_game_verified':False}
    (build/'runtime_report.json').write_text(json.dumps(report,indent=2),encoding='utf8')
    # Keep diagnostics for the two latest builds, rather than accumulating a
    # full copy of the fonts on every launch. Never follow a link outside state.
    base=build.parent.resolve()
    previous=sorted((p for p in base.iterdir() if p.name.isdecimal() and p.is_dir()),key=lambda p:p.name)
    for old in previous[:-2]:
        if old.resolve().parent==base and not old.is_symlink() and (old/'runtime_report.json').is_file():
            shutil.rmtree(old)
    return staging,report
