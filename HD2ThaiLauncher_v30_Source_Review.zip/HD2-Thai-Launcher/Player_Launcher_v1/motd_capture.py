"""Keep only allowlisted display strings from a MOTD response, never credentials."""
import hashlib,json,re
from datetime import datetime,timezone

DISPLAY={'title','titletext','header','headertext','headline','body','bodytext','text','message','description','descriptiontext','subtitle','content','contenttext','motdtitle','motdtext'}
PRIVATE=re.compile(r'auth|token|password|secret|cookie|account|player|userid|email|session',re.I)

class LinkedField:
    def __init__(self,obj,flush):self.obj,self.flush=obj,flush
    def __getitem__(self,key):return self.obj[key]
    def __setitem__(self,key,value):self.obj[key]=value;self.flush()

def fields(body):
    count=0
    def walk(value,path=(),depth=0,context=False,flush=None):
        nonlocal count
        if depth>12 or count>=200:return
        if isinstance(value,dict):
            for key,item in value.items():
                if PRIVATE.search(str(key)):continue
                name=re.sub(r'[-_]','',str(key)).lower()
                display=name in DISPLAY or (context and name in {'value','en','enus','english','us'})
                if isinstance(item,(dict,list)):yield from walk(item,path+(key,),depth+1,display,flush)
                elif isinstance(item,str) and len(item)<=100000 and item.lstrip().startswith(('{','[')):
                    try:decoded=json.loads(item)
                    except ValueError:continue
                    def save(obj=value,k=key,data=decoded,outer=flush):
                        obj[k]=json.dumps(data,ensure_ascii=False,separators=(',',':'))
                        if outer:outer()
                    yield from walk(decoded,path+(key,'<json>'),depth+1,display,save)
                elif display and isinstance(item,str) and item.strip() and len(item)<=20000:
                    if item.lstrip().startswith(('https://','http://','data:')):continue
                    count+=1;yield LinkedField(value,flush) if flush else value,key,path+(key,)
        elif isinstance(value,list):
            for i,item in enumerate(value):yield from walk(item,path+(i,),depth+1,context,flush)
    yield from walk(body)

def structure(body):
    """Field names/types/counts only, never arbitrary response values."""
    result=[]
    def walk(value,path='$',depth=0):
        if depth>9 or len(result)>=180:return
        result.append({'path':path,'type':type(value).__name__,'count':len(value) if isinstance(value,(list,dict)) else None})
        if isinstance(value,dict):
            for key,item in list(value.items())[:40]:
                if PRIVATE.search(str(key)):continue
                safe=str(key) if re.fullmatch(r'[A-Za-z_][A-Za-z0-9_]{0,49}',str(key)) else '<dynamic-key>'
                walk(item,path+'.'+safe,depth+1)
        elif isinstance(value,list):
            for i,item in enumerate(value[:3]):walk(item,path+f'[{i}]',depth+1)
        elif isinstance(value,str) and len(value)<=100000 and value.lstrip().startswith(('{','[')):
            try:walk(json.loads(value),path+'.<json>',depth+1)
            except ValueError:pass
    walk(body)
    return result

def collect(state,body,atomic):
    path=state/'motd_capture.json'
    try:previous=json.loads(path.read_text(encoding='utf-8')).get('items',[])
    except (OSError,ValueError,AttributeError):previous=[]
    entries={x['sha256']:x for x in previous if isinstance(x,dict) and 'sha256' in x}
    now=datetime.now(timezone.utc).isoformat();found=0
    for obj,key,location in fields(body):
        source=obj[key];digest=hashlib.sha256(source.encode()).hexdigest();found+=1
        entries[digest]={'english':source,'sha256':digest,'field_path':'.'.join(map(str,location)),'last_seen_utc':now}
    # No response dump, request body, headers, URLs, account IDs or auth tokens.
    schema=sorted(str(k) for k in body)[:60] if isinstance(body,dict) else [type(body).__name__]
    atomic(path,{'endpoint':'/api/Pes/GetMotd','last_seen_utc':now,'display_fields_seen':found,'top_level_keys':schema,'response_item_count':len(body['items']) if isinstance(body,dict) and isinstance(body.get('items'),list) else None,'structure':structure(body),'items':list(entries.values())})
    return found
