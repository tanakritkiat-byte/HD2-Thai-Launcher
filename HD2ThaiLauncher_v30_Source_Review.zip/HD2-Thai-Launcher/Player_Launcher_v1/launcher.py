"""Portable player launcher. Only the original protected launcher starts the game."""
import argparse,asyncio,collections,csv,ctypes,hashlib,http.server,io,json,os,queue,re,socket,subprocess,sys,threading,time,winreg
from datetime import datetime,timezone,timedelta
from pathlib import Path

BUNDLE=Path(getattr(sys,'_MEIPASS',Path(__file__).resolve().parent))
HOST='api.live.prod.thehelldiversgame.com'
SHEET='1uRHGSv9OWwT8HGY71HmlSMSNekRNSisXliXFUavDb7k'
NO_WINDOW=getattr(subprocess,'CREATE_NO_WINDOW',0)
VERSION='30'

def canonical(value):return json.dumps(value,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()
def atomic(path,value):
    temp=path.with_suffix('.tmp');temp.write_bytes(canonical(value));os.replace(temp,path)
def bundled_rules():
    raw=(BUNDLE/'seed_rules.json').read_bytes()
    manifest=json.loads((BUNDLE/'bundle_manifest.json').read_text())
    if hashlib.sha256(raw).hexdigest()!=manifest['seed_sha256']:raise ValueError('Bundled translation checksum mismatch')
    return json.loads(raw)
def cached_rules(state):
    try:
        data=json.loads((state/'cache.json').read_text(encoding='utf-8'))
        if hashlib.sha256(canonical(data['rules'])).hexdigest()!=data['sha256']:raise ValueError('cache checksum')
        return data['rules']
    except (OSError,ValueError,KeyError):return bundled_rules()

def refresh(state,budget=9):
    """Daemon fetches cannot change the active cache after the overall deadline."""
    import urllib.request
    from api_rules import merge
    inbox=queue.Queue()
    tabs=[('campaigns',1701027004,2),('current',1701027002,3)]
    def fetch(tab):
        name,gid,priority=tab
        try:
            url=f'https://docs.google.com/spreadsheets/d/{SHEET}/export?format=csv&gid={gid}&cachebust={time.time_ns()}'
            req=urllib.request.Request(url,headers={'Cache-Control':'no-cache','User-Agent':'HD2-Thai-Player-Launcher/1.0'})
            # Launcher downloads never inherit an unrelated desktop proxy.
            opener=urllib.request.build_opener(urllib.request.ProxyHandler({}))
            with opener.open(req,timeout=4) as r:raw=r.read(16000001)
            if len(raw)>16000000:raise ValueError('Sheet size limit')
            inbox.put((name,gid,priority,list(csv.reader(io.StringIO(raw.decode('utf-8-sig'),newline='')))))
        except Exception as exc:
            import traceback
            inbox.put({'tab':name,'error':type(exc).__name__+': '+str(exc),'traceback':traceback.format_exc()})
    for tab in tabs:threading.Thread(target=fetch,args=(tab,),daemon=True).start()
    sheets=[];deadline=time.monotonic()+budget
    for _ in tabs:
        try:result=inbox.get(timeout=max(.01,deadline-time.monotonic()))
        except queue.Empty:
            atomic(state/'last_refresh.json',{'ok':False,'reason':'timeout','checked_utc':datetime.now(timezone.utc).isoformat()})
            return False,'timeout'
        if isinstance(result,dict):
            atomic(state/'last_refresh.json',dict(result,ok=False,checked_utc=datetime.now(timezone.utc).isoformat()))
            return False,'download_failed'
        sheets.append(result)
    sheets.sort(key=lambda x:x[2])
    rules,report=merge(sheets)
    if report['errors'] or not rules:
        atomic(state/'last_refresh.json',{'ok':False,'reason':'validation_failed','errors':report['errors'],'checked_utc':datetime.now(timezone.utc).isoformat()})
        return False,'validation_failed'
    atomic(state/'cache.json',{'rules':rules,'sha256':hashlib.sha256(canonical(rules)).hexdigest(),
                              'updated_utc':datetime.now(timezone.utc).isoformat()})
    atomic(state/'last_refresh.json',{'ok':True,'rules':len(rules),'checked_utc':datetime.now(timezone.utc).isoformat()})
    return True,len(rules)

def command(args,timeout=25):
    return subprocess.run(args,capture_output=True,text=True,encoding='utf-8',errors='replace',
                          timeout=timeout,creationflags=NO_WINDOW)
def game_pids():
    r=command(['tasklist.exe','/FI','IMAGENAME eq helldivers2.exe','/FO','CSV','/NH'])
    if r.returncode:raise ValueError('ตรวจสถานะเกมไม่สำเร็จ จึงยังไม่เปลี่ยนไฟล์คำแปล')
    result=[]
    for row in csv.reader(io.StringIO(r.stdout)):
        if len(row)>1 and row[0].lower()=='helldivers2.exe':result.append(int(row[1]))
    return result
def game_folder(state=None):
    from game_discovery import discover
    return discover(state)

def certificate(state,crl_port):
    from cryptography import x509
    from cryptography.hazmat.primitives import hashes,serialization
    from cryptography.hazmat.primitives.asymmetric import rsa
    from cryptography.x509.oid import NameOID,ExtendedKeyUsageOID
    folder=state/'certificate';folder.mkdir(exist_ok=True)
    # Restrict CA private-key directory to this Windows user and SYSTEM.
    sidrows=list(csv.reader(io.StringIO(command(['whoami.exe','/user','/fo','csv','/nh']).stdout)))
    sid=sidrows[0][-1] if sidrows else ''
    if not re.fullmatch(r'S-1-[\d-]+',sid):raise ValueError('Cannot determine Windows user SID')
    acl=command(['icacls.exe',str(folder),'/inheritance:r','/grant:r',f'*{sid}:(OI)(CI)F','*S-1-5-18:(OI)(CI)F'])
    if acl.returncode:raise ValueError('Cannot protect local private-key folder')
    now=datetime.now(timezone.utc);keyfile=folder/'ca.key';cafile=folder/'ca.cer'
    if keyfile.exists()!=cafile.exists():raise ValueError('Incomplete local certificate; use Remove helper before setup')
    if keyfile.exists():
        ca=x509.load_der_x509_certificate(cafile.read_bytes())
        key=serialization.load_pem_private_key(keyfile.read_bytes(),None)
        if ca.public_key().public_numbers()!=key.public_key().public_numbers():raise ValueError('Local CA/key mismatch')
    else:
        key=rsa.generate_private_key(public_exponent=65537,key_size=2048)
        subject=x509.Name([x509.NameAttribute(NameOID.COMMON_NAME,'HD2 Thai Translation - Local '+sid[-8:])])
        ca=(x509.CertificateBuilder().subject_name(subject).issuer_name(subject).public_key(key.public_key())
            .serial_number(x509.random_serial_number()).not_valid_before(now-timedelta(minutes=5))
            .not_valid_after(now+timedelta(days=3650)).add_extension(x509.BasicConstraints(ca=True,path_length=0),True)
            .add_extension(x509.KeyUsage(True,False,False,False,False,True,True,False,False),True)
            .add_extension(x509.SubjectKeyIdentifier.from_public_key(key.public_key()),False).sign(key,hashes.SHA256()))
        keyfile.write_bytes(key.private_bytes(serialization.Encoding.PEM,serialization.PrivateFormat.PKCS8,serialization.NoEncryption()))
        cafile.write_bytes(ca.public_bytes(serialization.Encoding.DER))
    thumb=ca.fingerprint(hashes.SHA1()).hex().upper()
    atomic(state/'certificate_identity.json',{'thumbprint':thumb,'certificate':str(cafile)})
    leafkey=rsa.generate_private_key(public_exponent=65537,key_size=2048)
    leaf=(x509.CertificateBuilder().subject_name(x509.Name([x509.NameAttribute(NameOID.COMMON_NAME,HOST)]))
        .issuer_name(ca.subject).public_key(leafkey.public_key()).serial_number(x509.random_serial_number())
        .not_valid_before(now-timedelta(minutes=5)).not_valid_after(now+timedelta(days=2))
        .add_extension(x509.BasicConstraints(ca=False,path_length=None),True)
        .add_extension(x509.SubjectAlternativeName([x509.DNSName(HOST)]),False)
        .add_extension(x509.ExtendedKeyUsage([ExtendedKeyUsageOID.SERVER_AUTH]),False)
        .add_extension(x509.KeyUsage(True,False,True,False,False,False,False,False,False),True)
        .add_extension(x509.AuthorityKeyIdentifier.from_issuer_public_key(key.public_key()),False)
        .add_extension(x509.CRLDistributionPoints([x509.DistributionPoint(
            [x509.UniformResourceIdentifier(f'http://127.0.0.1:{crl_port}/ca.crl')],None,None,None)]),False)
        .sign(key,hashes.SHA256()))
    crl=(x509.CertificateRevocationListBuilder().issuer_name(ca.subject).last_update(now-timedelta(minutes=5))
        .next_update(now+timedelta(days=1)).add_extension(x509.AuthorityKeyIdentifier.from_issuer_public_key(key.public_key()),False)
        .add_extension(x509.CRLNumber(int(time.time())),False).sign(key,hashes.SHA256()))
    (folder/'host.pem').write_bytes(leafkey.private_bytes(serialization.Encoding.PEM,serialization.PrivateFormat.PKCS8,
        serialization.NoEncryption())+leaf.public_bytes(serialization.Encoding.PEM)+ca.public_bytes(serialization.Encoding.PEM))
    (folder/'ca.crl').write_bytes(crl.public_bytes(serialization.Encoding.DER))
    return thumb,cafile

def trusted(thumb):return command(['certutil.exe','-user','-store','Root',thumb]).returncode==0

def certificate_installed(state):
    try:
        thumb=json.loads((state/'certificate_identity.json').read_text())['thumbprint']
        return bool(re.fullmatch('[A-F0-9]{40}',thumb)) and trusted(thumb)
    except (OSError,ValueError,KeyError,TypeError):return False

def prepare_uninstall(state):
    """Only remove this user's matching launcher CA; retain all local data."""
    if game_pids():
        raise ValueError('กรุณาปิด HELLDIVERS 2 ก่อนถอนการติดตั้ง แล้วลองอีกครั้ง')
    from mod_session import cleanup
    cleanup(state,game_pids)
    if not certificate_installed(state):return
    from cryptography import x509
    from cryptography.hazmat.primitives import hashes
    identity=json.loads((state/'certificate_identity.json').read_text())
    thumb=identity['thumbprint']
    ca=x509.load_der_x509_certificate((state/'certificate/ca.cer').read_bytes())
    common_names=ca.subject.get_attributes_for_oid(x509.NameOID.COMMON_NAME)
    if (ca.fingerprint(hashes.SHA1()).hex().upper()!=thumb or len(common_names)!=1
            or not common_names[0].value.startswith('HD2 Thai Translation - Local ')):
        raise ValueError('Invalid certificate identity')
    result=command(['certutil.exe','-user','-delstore','Root',thumb],timeout=240)
    if result.returncode or trusted(thumb):
        raise ValueError('ใบรับรองยังอยู่ กรุณายืนยันลบใน Windows')
def ensure_trusted(thumb,cafile):
    if not trusted(thumb):
        # Windows owns the confirmation dialog; never suppress or automate it.
        r=command(['certutil.exe','-user','-addstore','Root',str(cafile)],timeout=240)
        if r.returncode or not trusted(thumb):raise ValueError('ยังไม่ได้ยืนยันใบรับรอง จึงยังเปิดการแปลออนไลน์ไม่ได้')

def process_alive(pid):
    kernel=ctypes.WinDLL('kernel32',use_last_error=True)
    kernel.OpenProcess.restype=ctypes.c_void_p
    kernel.CloseHandle.argtypes=[ctypes.c_void_p]
    kernel.GetExitCodeProcess.argtypes=[ctypes.c_void_p,ctypes.POINTER(ctypes.c_ulong)]
    handle=kernel.OpenProcess(0x1000,False,pid)
    if not handle:return ctypes.get_last_error()==5
    try:
        code=ctypes.c_ulong()
        return bool(kernel.GetExitCodeProcess(handle,ctypes.byref(code))) and code.value==259
    finally:kernel.CloseHandle(handle)

async def proxy_main(state,port,crl_port,parent_pid=None):
    from mitmproxy import options
    from mitmproxy.tools.dump import DumpMaster
    from translation import transform
    from motd_capture import collect
    cert=state/'certificate'
    class CrlHandler(http.server.BaseHTTPRequestHandler):
        def do_GET(self):
            if self.path!='/ca.crl':self.send_error(404);return
            raw=(cert/'ca.crl').read_bytes();self.send_response(200)
            self.send_header('Content-Type','application/pkix-crl');self.send_header('Content-Length',str(len(raw)))
            self.end_headers();self.wfile.write(raw)
        def log_message(self,*args):pass
    server=http.server.ThreadingHTTPServer(('127.0.0.1',crl_port),CrlHandler)
    threading.Thread(target=server.serve_forever,daemon=True).start()
    class Translator:
        def response(self,flow):
            if flow.request.pretty_host!=HOST or flow.response.status_code!=200:return
            path=flow.request.path
            motd=path.split('?',1)[0]=='/api/Pes/GetMotd' and flow.request.method=='POST'
            if not motd and (flow.request.method!='GET' or not re.fullmatch(r'/api/(?:v2/Assignment/War/\d+|WarSeason/\d+/Status|NewsFeed/\d+|Episode/\d+|SpaceStation/\d+/\d+)(?:\?.*)?',path)):return
            try:
                body=flow.response.json()
                if motd:collect(state,body,atomic)
                result,applied=transform(path,body,cached_rules(state))
                if applied:
                    flow.response.text=json.dumps(result,ensure_ascii=False,separators=(',',':'))
                    flow.response.headers.pop('etag',None);flow.response.headers.pop('content-md5',None)
                    # No headers, bodies, account traffic or credentials are recorded.
                    atomic(state/'last_translation.json',{'changed_strings':len(applied),'time':time.time()})
            except (ValueError,OSError,KeyError,TypeError):return
    opts=options.Options(listen_host='127.0.0.1',listen_port=port,confdir=str(state/'proxy_config'),
                          allow_hosts=[r'^api\.live\.prod\.thehelldiversgame\.com:443$'])
    master=DumpMaster(opts,with_termlog=False,with_dumper=False)
    master.options.update(certs=[HOST+'='+str(cert/'host.pem')])
    master.addons.add(Translator())
    async def stop_watch():
        while not (state/'stop').exists():
            if parent_pid and not process_alive(parent_pid) and not game_pids():break
            await asyncio.sleep(.5)
        master.shutdown()
    watcher=asyncio.create_task(stop_watch())
    atomic(state/'proxy_ready.json',{'port':port,'pid':os.getpid()})
    try:await master.run()
    finally:watcher.cancel();server.shutdown();server.server_close()

def free_port():
    with socket.socket() as sock:sock.bind(('127.0.0.1',0));return sock.getsockname()[1]
def self_command():return [sys.executable] if getattr(sys,'frozen',False) else [sys.executable,str(Path(__file__).resolve())]

def run_game(state,folder,notify,translation_notify=None,on_trusted=None):
    from language_runtime import compile_latest
    from mod_session import cleanup,deploy
    if game_pids():raise ValueError('เกมเปิดอยู่แล้ว กรุณาปิดเกมก่อนกดเล่นจากตัวช่วย')
    cleanup(state,game_pids)
    staging,report=compile_latest(BUNDLE,state,notify)
    atomic(state/'last_language_build.json',report)
    try:
        notify('กำลังติดตั้งคำแปล…')
        session=deploy(state,folder,staging,game_pids)
        # Independent child keeps the cleanup journal usable even if the parent
        # launcher is closed. It never removes patches while the game is alive.
        subprocess.Popen(self_command()+['--watch-session','--session-id',session['session_id'],'--parent-pid',str(os.getpid()),'--data-dir',str(state)],creationflags=NO_WINDOW)
        _run_game_api(state,folder,notify,translation_notify,on_trusted)
    finally:
        cleanup(state,game_pids)

def _run_game_api(state,folder,notify,translation_notify=None,on_trusted=None):
    translation_notify=translation_notify or (lambda event:notify(event['text']))
    if game_pids():raise ValueError('เกมเปิดอยู่แล้ว กรุณาปิดเกมก่อนกดเล่นจากตัวช่วย')
    notify('กำลังดาวน์โหลดคำแปล Major Order & Control Center…')
    translation_notify({'state':'loading','text':'กำลังดาวน์โหลดคำแปลล่าสุด…'})
    ok,info=refresh(state)
    rules=cached_rules(state)
    if not rules:raise ValueError('ไม่มีคำแปลสำรอง')
    translation_notify({'state':'online' if ok else 'fallback','text':f'อัปเดตแล้ว · {info} ข้อความ' if ok else f'ใช้ชุดที่เก็บไว้ · {len(rules)} ข้อความ · ดาวน์โหลดล่าสุดไม่สำเร็จ'})
    notify('กำลังเตรียมระบบคำแปลออนไลน์…')
    port,crl_port=free_port(),free_port()
    while crl_port==port:crl_port=free_port()
    thumb,cafile=certificate(state,crl_port)
    notify('รอยืนยันครั้งแรกใน Windows · ตรวจชื่อ HD2 Thai Translation - Local แล้วกด Yes' if not trusted(thumb) else 'กำลังเตรียมเปิดเกม…')
    ensure_trusted(thumb,cafile)
    if on_trusted:on_trusted()
    for name in ['stop','proxy_ready.json']:(state/name).unlink(missing_ok=True)
    with (state/'helper.log').open('w',encoding='utf-8') as log:
        proxy=subprocess.Popen(self_command()+['--proxy','--parent-pid',str(os.getpid()),'--data-dir',str(state),'--port',str(port),'--crl-port',str(crl_port)],
                               stdout=log,stderr=log,creationflags=NO_WINDOW)
        try:
            deadline=time.monotonic()+30
            while time.monotonic()<deadline:
                if proxy.poll() is not None:raise ValueError('ตัวกลางเปิดไม่สำเร็จ ดู helper.log ในโฟลเดอร์ข้อมูลตัวช่วย')
                if (state/'proxy_ready.json').exists():
                    try:
                        with socket.create_connection(('127.0.0.1',port),timeout=.2):break
                    except OSError:pass
                time.sleep(.2)
            else:raise ValueError('ตัวกลางเปิดไม่ทันเวลา')
            env=os.environ.copy();url=f'http://127.0.0.1:{port}'
            env.update(HTTPS_PROXY=url,HTTP_PROXY=url,ALL_PROXY=url,
                       NO_PROXY='localhost,127.0.0.1,::1,epicgames.com,easyanticheat.net,easyanticheat.com,easy.ac',
                       SteamAppId='553850',SteamGameId='553850')
            subprocess.Popen([str(folder/'start_protected_game.exe'),'--bundle-dir','data','--release'],cwd=folder,env=env)
            notify('กำลังเปิดเกม…')
            deadline=time.monotonic()+120
            while time.monotonic()<deadline:
                pids=game_pids()
                if pids:break
                if proxy.poll() is not None:raise ValueError('ตัวกลางหยุดก่อนเกมเปิด')
                time.sleep(1)
            else:raise ValueError('ยังไม่พบเกมเปิด กรุณาตรวจว่า Steam เปิดและเข้าสู่ระบบแล้ว')
            notify('กำลังทำงาน · ย่อหน้าต่างนี้ได้')
            while game_pids():
                if proxy.poll() is not None:raise ValueError('ตัวกลางหยุด กรุณาปิดเกมแล้วเปิดใหม่ผ่านตัวช่วย')
                time.sleep(2)
        finally:
            (state/'stop').touch()
            try:proxy.wait(timeout=8)
            except subprocess.TimeoutExpired:proxy.terminate();proxy.wait(timeout=5)

def gui(state,preview=False):
    import tkinter as tk
    from tkinter import ttk,messagebox,filedialog
    from launcher_ui import create_window
    ui=create_window(VERSION,BUNDLE,bool(getattr(sys,'frozen',False)),preview)
    root,status,translation_status=ui.root,ui.status,ui.translation_status
    translation_label,progress=ui.translation_label,ui.progress
    button,remove,certificate_actions=ui.button,ui.remove,ui.certificate_actions
    fg=ui.fg;events=queue.Queue();busy=False
    def worker(folder):
        try:
            run_game(state,folder,lambda text:events.put(('status',text)),lambda event:events.put(('translation',event)))
            events.put(('done','ปิดเกมแล้ว · พร้อมเปิดครั้งถัดไป'))
        except Exception as e:events.put(('error',str(e)))
    def play():
        nonlocal busy
        if busy:return
        folder=game_folder()
        if folder is None:
            chosen=filedialog.askdirectory(title='เลือกโฟลเดอร์ Helldivers 2 ที่มี start_protected_game.exe')
            if not chosen:return
            folder=Path(chosen)
        if not (folder/'start_protected_game.exe').is_file():messagebox.showerror('ไม่พบเกม','เลือกโฟลเดอร์เกมที่มี start_protected_game.exe');return
        busy=True;button.configure(state='disabled');remove.configure(state='disabled');progress.start(12)
        threading.Thread(target=worker,args=(folder,),daemon=True).start()
    button.configure(command=play)
    def uninstall():
        if busy:return
        if not certificate_installed(state):
            set_certificate_visibility(False);status.set('ยังไม่ได้ติดตั้งใบรับรอง');return
        if not messagebox.askyesno('ถอนใบรับรอง','ลบใบรับรองที่คุณอนุญาตตอนเปิดใช้งานครั้งแรกใช่ไหม?\n\nหากกลับมาใช้อีกครั้ง Windows จะขอให้ยืนยันใหม่'):return
        try:
            identity=json.loads((state/'certificate_identity.json').read_text());thumb=identity['thumbprint']
            if not re.fullmatch('[A-F0-9]{40}',thumb):raise ValueError('Invalid certificate identity')
            command(['certutil.exe','-user','-delstore','Root',thumb],timeout=240)
            if trusted(thumb):raise ValueError('ใบรับรองยังอยู่ กรุณายืนยันลบใน Windows')
            set_certificate_visibility(False)
            status.set('ถอนใบรับรองแล้ว หากกดเล่นอีกครั้ง Windows จะถามยืนยันใหม่')
        except FileNotFoundError:status.set('ยังไม่ได้ติดตั้งใบรับรอง')
        except Exception as e:messagebox.showerror('ถอนยังไม่สำเร็จ',str(e))
    remove.configure(command=uninstall)
    def set_certificate_visibility(present):
        if present:certificate_actions.pack(side='left')
        else:certificate_actions.pack_forget()
        remove.configure(state='disabled' if busy or preview else 'normal')
    def check_certificate():
        def work():
            try:present=certificate_installed(state)
            except Exception:present=False
            events.put(('certificate',present))
        threading.Thread(target=work,daemon=True).start()
    def poll():
        nonlocal busy
        try:
            while True:
                kind,text=events.get_nowait()
                if kind=='certificate':
                    set_certificate_visibility(text)
                    root.after(5000,check_certificate)
                    continue
                if kind=='translation':
                    translation_status.set(text['text'])
                    translation_label.configure(fg={'online':'#8cdfb0','fallback':'#f6d84a','loading':fg}[text['state']])
                    continue
                status.set(text)
                if kind in ('done','error'):
                    busy=False;progress.stop();button.configure(state='normal');remove.configure(state='normal')
                    if kind=='error':messagebox.showerror('เปิดยังไม่สำเร็จ',text)
        except queue.Empty:pass
        root.after(150,poll)
    def close():
        if busy:messagebox.showinfo('ตัวช่วยกำลังทำงาน','ย่อหน้าต่างนี้ได้ กรุณาปิดเกมก่อนปิดตัวช่วย');return
        root.destroy()
    root.protocol('WM_DELETE_WINDOW',close);root.after(150,poll)
    root.after(0,check_certificate)
    if preview:button.configure(state='disabled');remove.configure(state='disabled')
    if os.environ.get('HD2_LAUNCHER_UI_SMOKE')=='1':root.after(250,root.destroy)
    root.mainloop()

FIRST_RUN_TEXT=(
    'โปรแกรมนี้จะดาวน์โหลดคำแปลล่าสุดของม็อดภาษาไทยและเปิด HELLDIVERS 2\n'
    'รวมถึงคำแปล Major Order & Control Center\n\n'
    'ตั้งค่าภาษาข้อความในเกม ให้เป็น English (United States)\n'
    'ต้องเปิดเกมผ่านโปรแกรมนี้เพื่อใช้คำแปล\n\n'
    'ในการใช้งานครั้งแรก\n'
    'หลังจากกด “ยืนยันและดำเนินการต่อ”\n'
    'จะมีหน้าต่างจาก Windows ให้ยืนยันใบรับรองสำหรับคำแปลออนไลน์\n\n'
    'กรุณากด Yes เพื่อเปิดใช้งานคำแปลออนไลน์')

def confirm_first_run():
    from launch_flow_ui import confirm_notice
    return confirm_notice(BUNDLE,FIRST_RUN_TEXT)

def choose_game_folder():
    from launcher_ui import enable_high_dpi
    enable_high_dpi()
    import tkinter as tk
    from tkinter import filedialog
    root=tk.Tk();root.withdraw()
    try:
        chosen=filedialog.askdirectory(parent=root,title='เลือกโฟลเดอร์ Helldivers 2 ที่มี start_protected_game.exe')
        return Path(chosen) if chosen else None
    finally:root.destroy()

def quick_launch(state):
    """No permanent window. Keep the proxy parent alive until the game closes."""
    if game_pids():raise ValueError('เกมเปิดอยู่แล้ว กรุณาปิดเกมก่อนกดเล่นจากตัวช่วย')
    from game_discovery import remember,valid_game,location_confirmed
    from launch_flow_ui import confirm_game_folder,launch_with_progress
    from mod_session import cleanup
    cleanup(state,game_pids)
    folder=game_folder(state)
    try:onboarded=json.loads((state/'onboarding.json').read_text()).get('version')==2
    except (OSError,ValueError,AttributeError):onboarded=False
    needs_notice=not onboarded or not certificate_installed(state)
    if not location_confirmed(state,folder):
        folder=confirm_game_folder(BUNDLE,folder,notice=FIRST_RUN_TEXT if needs_notice else None)
        if folder is None:return
    elif needs_notice and not confirm_first_run():return
    if not valid_game(folder):raise ValueError('เลือกโฟลเดอร์เกมที่มี start_protected_game.exe และ data')
    folder=remember(state,folder,confirmed=True)
    # Windows trust approval precedes the download progress window. Repeating
    # this check cannot suppress or click Windows' own confirmation dialog.
    if not certificate_installed(state):
        thumb,cafile=certificate(state,free_port())
        ensure_trusted(thumb,cafile)
    atomic(state/'onboarding.json',{'version':2})
    def status(text):atomic(state/'last_run.json',{'message':text,'updated_utc':datetime.now(timezone.utc).isoformat()})
    def work(notify):
        def progress(text):status(text);notify(text)
        run_game(state,folder,progress)
    launch_with_progress(BUNDLE,work)
    status('ปิดเกมแล้ว')

def single_launch(state):
    """Ignore repeat double-clicks while this user's launcher is still active."""
    kernel=ctypes.WinDLL('kernel32',use_last_error=True)
    kernel.CreateMutexW.argtypes=[ctypes.c_void_p,ctypes.c_int,ctypes.c_wchar_p]
    kernel.CreateMutexW.restype=ctypes.c_void_p
    kernel.CloseHandle.argtypes=[ctypes.c_void_p]
    name='Local\\HD2ThaiLauncher_'+hashlib.sha256(str(state.resolve()).casefold().encode()).hexdigest()[:24]
    handle=kernel.CreateMutexW(None,False,name)
    error=ctypes.get_last_error()
    if not handle:raise ctypes.WinError()
    try:
        if error!=183:quick_launch(state)
    finally:kernel.CloseHandle(handle)

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--proxy',action='store_true');parser.add_argument('--data-dir')
    parser.add_argument('--port',type=int);parser.add_argument('--crl-port',type=int);parser.add_argument('--selftest',action='store_true')
    parser.add_argument('--check-update',action='store_true')
    parser.add_argument('--preview',action='store_true')
    parser.add_argument('--prepare-uninstall',action='store_true')
    parser.add_argument('--watch-session',action='store_true');parser.add_argument('--parent-pid',type=int)
    parser.add_argument('--session-id')
    parser.add_argument('--language-selftest',action='store_true')
    parser.add_argument('--preview-folder',action='store_true');parser.add_argument('--preview-progress',action='store_true')
    args=parser.parse_args()
    state=Path(args.data_dir or os.environ.get('HD2_THAI_DATA_DIR') or str(Path(os.environ['LOCALAPPDATA'])/'HD2ThaiLauncher'))
    if args.prepare_uninstall:
        prepare_uninstall(state)
        return
    state.mkdir(parents=True,exist_ok=True)
    if args.watch_session:
        from mod_session import watch
        def parent_alive():
            return process_alive(args.parent_pid)
        watch(state,parent_alive,game_pids,args.session_id)
    elif args.language_selftest:
        from language_runtime import compile_latest
        staging,report=compile_latest(BUNDLE,state)
        atomic(state/'language_selftest.json',report)
    elif args.proxy:asyncio.run(proxy_main(state,args.port,args.crl_port,args.parent_pid))
    elif args.check_update:
        refresh(state)
    elif args.selftest:
        atomic(state/'selftest.json',{'bundled_rules':len(bundled_rules()),'cached_rules':len(cached_rules(state)),
                                     'frozen':bool(getattr(sys,'frozen',False)),'certificate_installed':False})
    elif args.preview_folder:
        from launch_flow_ui import confirm_game_folder
        confirm_game_folder(BUNDLE,game_folder(state),preview=True,notice=FIRST_RUN_TEXT)
    elif args.preview_progress:
        from launch_flow_ui import launch_with_progress,STAGES
        def demo(notify):
            for prefix,_ in STAGES:notify(prefix+'…');time.sleep(4)
        launch_with_progress(BUNDLE,demo)
    elif args.preview:gui(state,preview=True)
    else:single_launch(state)

if __name__=='__main__':
    try:main()
    except Exception as exc:
        if '--proxy' in sys.argv:raise
        import traceback
        error_state=Path(os.environ.get('HD2_THAI_DATA_DIR') or str(Path(os.environ['LOCALAPPDATA'])/'HD2ThaiLauncher'))
        try:
            error_state.mkdir(parents=True,exist_ok=True)
            (error_state/'last_error.log').write_text(traceback.format_exc(),encoding='utf8')
        except OSError:pass
        ctypes.windll.user32.MessageBoxW(None,str(exc),'HD2 Thai',0x10)
        sys.exit(1)
