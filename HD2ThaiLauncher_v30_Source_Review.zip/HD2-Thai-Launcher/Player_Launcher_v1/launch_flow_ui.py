"""First-run game confirmation and a small, responsive launch progress window."""
import queue
import threading
from pathlib import Path


STAGES = (
    ('กำลังตรวจไฟล์ฟอนต์', 'ตรวจไฟล์ฟอนต์'),
    ('กำลังดึงคำแปลหลัก', 'ดาวน์โหลดคำแปลหลัก'),
    ('กำลังตรวจคำแปลและวรรณยุกต์', 'ตรวจคำแปลและวรรณยุกต์'),
    ('กำลังดึงและตรวจคำแปลส่วนเมนู', 'เตรียมคำแปลเมนู'),
    ('กำลังติดตั้งคำแปล', 'เตรียมไฟล์คำแปลสำหรับเกม'),
    ('กำลังดาวน์โหลดคำแปล Major Order', 'ดาวน์โหลดคำแปล Major Order & Control Center'),
    ('กำลังเตรียมระบบคำแปลออนไลน์', 'เตรียมระบบคำแปลออนไลน์'),
    ('กำลังเปิดเกม', 'พร้อมเปิดเกม'),
)


def stage_for(text):
    return next((i for i, (prefix, _) in enumerate(STAGES, 1) if text.startswith(prefix)), None)


def window(bundle, title, width=580):
    from launcher_ui import enable_high_dpi
    enable_high_dpi()
    import ctypes
    import tkinter as tk
    from tkinter import ttk
    root = tk.Tk(); root.withdraw()
    root.title('HELLDIVERS 2 ม็อดภาษาไทย · Pa-Kai')
    try: scale = (ctypes.windll.user32.GetDpiForWindow(root.winfo_id()) or 96) / 96
    except (AttributeError, OSError): scale = 1
    d = lambda n: round(n * scale)
    font = lambda size, bold=False: ('Leelawadee UI', -d(size * 96 / 72), 'bold' if bold else 'normal')
    bg, card, fg, muted, yellow = '#10161e', '#1a2430', '#f4f6f8', '#a8b5c4', '#f4d54b'
    root.configure(bg=bg); root.resizable(False, False)
    icon = Path(bundle) / 'launcher.ico'
    if icon.is_file(): root.iconbitmap(str(icon))
    outer = tk.Frame(root, bg=bg, padx=d(26), pady=d(23)); outer.pack(fill='both', expand=True)
    def label(parent, text='', size=11, color=fg, bold=False, **kw):
        return tk.Label(parent, text=text, bg=parent.cget('bg'), fg=color, font=font(size, bold),
                        anchor='w', justify='left', bd=0, **kw)
    label(outer, 'HELLDIVERS 2 ม็อดภาษาไทย', 10, yellow, True).pack(anchor='w')
    label(outer, title, 19, bold=True).pack(anchor='w', pady=(d(7), d(5)))
    def reveal():
        root.update_idletasks()
        w = min(d(width), root.winfo_screenwidth() - d(32))
        h = root.winfo_reqheight()
        root.geometry(f'{w}x{h}+{max(0,(root.winfo_screenwidth()-w)//2)}+{max(0,(root.winfo_screenheight()-h)//2)}')
        root.deiconify(); root.lift()
    return root, outer, label, font, d, reveal, (bg, card, fg, muted, yellow)


def certificate_notice(parent, notice, label, d):
    before,marker,after=notice.partition('ในการใช้งานครั้งแรก')
    if before.strip():label(parent,before.strip(),10,'#a8b5c4',wraplength=d(520)).pack(fill='x',pady=(d(14),0))
    if marker:label(parent,marker+after,11,'#ff7777',True,wraplength=d(520)).pack(fill='x',pady=(d(15),0))

def confirm_notice(bundle, notice):
    import tkinter as tk
    root,outer,label,font,d,reveal,colors=window(bundle,'ก่อนเปิดเกมครั้งแรก')
    certificate_notice(outer,notice,label,d)
    accepted=[]
    def proceed():accepted.append(True);root.destroy()
    actions=tk.Frame(outer,bg=colors[0]);actions.pack(fill='x',pady=(d(20),0))
    tk.Button(actions,text='ยกเลิก',command=root.destroy,font=font(11),bg=colors[1],fg=colors[2],relief='flat',padx=d(15),pady=d(9)).pack(side='left')
    tk.Button(actions,text='ยืนยันและดำเนินการต่อ',command=proceed,font=font(11,True),bg=colors[4],fg='#11161c',relief='flat',padx=d(17),pady=d(9)).pack(side='right')
    reveal();root.mainloop()
    return bool(accepted)

def confirm_game_folder(bundle, initial=None, preview=False, notice=None):
    import tkinter as tk
    from tkinter import filedialog
    from game_discovery import valid_game
    root, outer, label, font, d, reveal, colors = window(bundle, 'ยืนยันตำแหน่งเกม')
    bg, card, fg, muted, yellow = colors
    label(outer, 'ตรวจสอบโฟลเดอร์ก่อนเริ่มใช้งานครั้งแรก', 10, muted).pack(anchor='w')
    box = tk.Frame(outer, bg=card, padx=d(17), pady=d(15)); box.pack(fill='x', pady=(d(19), d(12)))
    status = label(box, size=12, bold=True); status.pack(anchor='w')
    location = tk.StringVar(value=str(initial) if initial else '')
    label(box, textvariable=location, size=10, wraplength=d(490)).pack(fill='x', pady=(d(8), 0))
    hint = label(outer, '', 10, muted, wraplength=d(520)); hint.pack(anchor='w', fill='x')
    if notice: certificate_notice(outer,notice,label,d)
    result = []
    def validate(*_):
        try: good = bool(location.get()) and valid_game(location.get())
        except (OSError, ValueError): good = False
        status.configure(text='✓ พบเกมแล้ว' if good else 'ยังไม่พบโฟลเดอร์เกมที่ถูกต้อง', fg='#74dfaa' if good else '#ff9d94')
        hint.configure(text='ตำแหน่งนี้พร้อมใช้งาน' if good else 'เลือกโฟลเดอร์ที่มีไฟล์ start_protected_game.exe และโฟลเดอร์ data')
        confirm.configure(state='normal' if good else 'disabled')
        return good
    def choose():
        selected = filedialog.askdirectory(parent=root, title='เลือกโฟลเดอร์ HELLDIVERS 2',
                                          initialdir=location.get() if location.get() and Path(location.get()).is_dir() else None)
        if selected: location.set(selected); validate(); reveal()
    def accept():
        if validate(): result.append(Path(location.get()).resolve()); root.destroy()
    actions = tk.Frame(outer, bg=bg); actions.pack(fill='x', pady=(d(20), 0))
    tk.Button(actions, text='เปลี่ยนตำแหน่ง', command=choose, font=font(11), bg=card, fg=fg,
              activebackground='#2a394b', activeforeground=fg, relief='flat', padx=d(15), pady=d(9), cursor='hand2').pack(side='left')
    confirm = tk.Button(actions, text='ยืนยันและดำเนินการต่อ', command=accept, font=font(11, True), bg=yellow,
                        fg='#11161c', activebackground='#ffe777', relief='flat', padx=d(17), pady=d(9), cursor='hand2')
    confirm.pack(side='right')
    validate(); reveal()
    if preview: root.after(180000, root.destroy)
    root.mainloop()
    return result[0] if result else None


def launch_with_progress(bundle, work):
    """Tk stays on the main thread; work continues after the game splash opens."""
    import tkinter as tk
    from tkinter import ttk
    root, outer, label, font, d, reveal, colors = window(bundle, 'กำลังเตรียมเปิดเกม', 580)
    bg, card, fg, muted, yellow = colors
    detail = label(outer, 'กำลังเริ่มต้น…', 11, wraplength=d(520)); detail.pack(fill='x', pady=(d(12), d(15)))
    style = ttk.Style(root); style.theme_use('clam')
    style.configure('Launch.Horizontal.TProgressbar', background=yellow, troughcolor=card,
                    borderwidth=0, lightcolor=yellow, darkcolor=yellow, thickness=d(6))
    bar = ttk.Progressbar(outer, style='Launch.Horizontal.TProgressbar', maximum=len(STAGES)); bar.pack(fill='x')
    footer = tk.Frame(outer, bg=bg); footer.pack(fill='x', pady=(d(12), 0))
    label(footer, 'โปรแกรมจะเปิดเกมให้อัตโนมัติ', 10, muted).pack(side='left')
    count = label(footer, f'0 / {len(STAGES)} ขั้นตอน', 10, muted); count.pack(side='right')
    events = queue.Queue(); errors = []; progress = 0
    def worker():
        try: work(lambda text: events.put(('status', text)))
        except BaseException as exc: errors.append(exc)
        finally: events.put(('done', None))
    thread = threading.Thread(target=worker, name='HD2-launch', daemon=False)
    def poll():
        nonlocal progress
        while True:
            try: kind, text = events.get_nowait()
            except queue.Empty: break
            if kind == 'done': root.destroy(); return
            step = stage_for(text)
            if step:
                progress = max(progress, step); bar['value'] = progress
                count.configure(text=f'{progress} / {len(STAGES)} ขั้นตอน')
                detail.configure(text=STAGES[step-1][1])
            if step == len(STAGES):
                root.after(300, root.destroy); return
        root.after(60, poll)
    # Closing this small status window minimizes it; it must not interrupt a
    # file copy or stop the API helper while the game is starting.
    root.protocol('WM_DELETE_WINDOW', root.iconify)
    reveal(); thread.start(); root.after(60, poll); root.mainloop()
    thread.join()
    if errors: raise errors[0]
