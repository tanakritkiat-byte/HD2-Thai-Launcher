"""Build a per-user Setup from a new validated launcher; does not install it."""
import ast
import os
import shutil
import hashlib
import json
from pathlib import Path
import subprocess
import sys

ROOT=Path(__file__).resolve().parent
PROJECT=ROOT.parent
texts=json.loads((ROOT/'installer_text_th.json').read_text(encoding='utf-8'))
if texts.get('text_approved') is not True:raise ValueError('Installer text is not approved')
version=next(ast.literal_eval(n.value) for n in ast.parse((ROOT/'launcher.py').read_text(encoding='utf-8')).body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='VERSION' for t in n.targets))
build=PROJECT/'Builds'/f'HD2_Thai_Launcher_v{version}_build'
app=build/'HD2ThaiLauncher'
compiler=Path(os.environ.get('INNO_ISCC') or shutil.which('ISCC.exe') or r'C:\Program Files (x86)\Inno Setup 6\ISCC.exe')
revision=sys.argv[1] if len(sys.argv)>1 else ''
if revision and (not revision.startswith('r') or not revision[1:].isdigit()):raise ValueError('Installer revision must look like r2')
output=PROJECT/'Releases/Launcher'/f'HD2ThaiLauncher_v{version}{revision}_Setup.exe'
if output.exists():raise FileExistsError(output)
if not (app/'HD2ThaiLauncher.exe').is_file():raise FileNotFoundError(app)
notices=list((app/'ThirdPartyNotices').rglob('*'))
if len([p for p in notices if p.is_file()])!=75:raise ValueError('Third-party notices are incomplete')
for p in app.rglob('*'):
    if p.is_file() and (p.name.lower() in {'ca.key','host.pem','cache.json','readme_th.txt','windivert.dll','windivert64.sys','windows-redirector.exe'}
                       or p.suffix.lower() in {'.key','.pfx'}):
        raise ValueError('Unexpected public payload: '+str(p))
template=r"""
[Setup]
AppId={{3D796B16-09D1-4FA1-ABE7-32F33562C8CA}
AppName=@app_name@
AppVersion=@version_numeric@
AppPublisher=@publisher@
AppVerName=@app_name@
VersionInfoCompany=@publisher@
VersionInfoDescription=@app_name@
DefaultDirName={localappdata}\Programs\HD2ThaiLauncher
DefaultGroupName=@shortcut@
UsePreviousAppDir=yes
UsePreviousTasks=yes
DisableProgramGroupPage=yes
DisableWelcomePage=no
DisableDirPage=no
PrivilegesRequired=lowest
ArchitecturesAllowed=x64compatible
ArchitecturesInstallIn64BitMode=x64compatible
OutputDir=@output_dir@
OutputBaseFilename=@output_basename@
SetupIconFile=@icon@
WizardSmallImageFile=@wizard_icon@
WizardImageFile=@sidebar@
WizardImageBackColor=$181818
UninstallDisplayIcon={app}\branding\launcher_v@version@.ico
UninstallDisplayName=@app_name@
Compression=lzma2
SolidCompression=yes
WizardStyle=modern
WizardSizePercent=125
WizardResizable=yes
CloseApplications=no
RestartApplications=no
AllowNoIcons=yes

[Languages]
Name: "thai"; MessagesFile: "compiler:Languages\Thai.isl"

[Messages]
WelcomeLabel1=@welcome@
WelcomeLabel2=@description@
FinishedHeadingLabel=@finished@
FinishedLabel=@finished@
FinishedLabelNoIcons=@finished@
UninstallAppFullTitle=@uninstall@
UninstalledAll=@uninstall_success@

[Tasks]
Name: "desktopicon"; Description: "@desktop_option@"

[Files]
Source: "@app@\*"; DestDir: "{app}"; Flags: ignoreversion recursesubdirs createallsubdirs

[Icons]
Name: "{userprograms}\@shortcut@"; Filename: "{app}\HD2ThaiLauncher.exe"; WorkingDir: "{app}"; IconFilename: "{app}\branding\launcher_v@version@.ico"
Name: "{userdesktop}\@shortcut@"; Filename: "{app}\HD2ThaiLauncher.exe"; WorkingDir: "{app}"; IconFilename: "{app}\branding\launcher_v@version@.ico"; Tasks: desktopicon

[Run]
Filename: "{userprograms}\@shortcut@.lnk"; WorkingDir: "{app}"; Description: "@launch_option@"; Flags: shellexec runasoriginaluser nowait postinstall skipifsilent unchecked

[Code]
var WelcomeNotice, FinishedNotice: TNewStaticText;
    PreviousDirectory, PreviousVersion: String;
    IsExistingInstall: Boolean;
    KeepFiles: TStringList;
    CleanupIncomplete: Boolean;

function SetWindowPos(Wnd, AfterWnd: HWND; X, Y, CX, CY: Integer; Flags: Cardinal): Boolean;
  external 'SetWindowPos@user32.dll stdcall';
function GetFileAttributesW(Name: String): LongWord;
  external 'GetFileAttributesW@kernel32.dll stdcall';

function SafeProgramTree(const Directory: String): Boolean;
var Rec: TFindRec; Attributes: LongWord;
begin
  Result := True;
  if not DirExists(Directory) then Exit;
  Attributes := GetFileAttributesW(Directory);
  if (Attributes = $FFFFFFFF) or ((Attributes and $400) <> 0) then begin
    Result := False;
    Exit;
  end;
  if FindFirst(AddBackslash(Directory) + '*', Rec) then begin
    try
      repeat
        if (Rec.Name <> '.') and (Rec.Name <> '..') then begin
          if (Rec.Attributes and $400) <> 0 then Result := False
          else if (Rec.Attributes and FILE_ATTRIBUTE_DIRECTORY) <> 0 then
            if not SafeProgramTree(AddBackslash(Directory) + Rec.Name) then Result := False;
        end;
      until not FindNext(Rec);
    finally FindClose(Rec); end;
  end;
end;

function PruneProgramDirectory(const Directory, Relative: String): Boolean;
var Rec: TFindRec; Child, Rel: String;
begin
  Result := True;
  if not DirExists(Directory) then Exit;
  if not SafeProgramTree(Directory) then begin Result := False; Exit; end;
  if FindFirst(AddBackslash(Directory) + '*', Rec) then begin
    try
      repeat
        if (Rec.Name <> '.') and (Rec.Name <> '..') then begin
          Child := AddBackslash(Directory) + Rec.Name;
          Rel := AddBackslash(Relative) + Rec.Name;
          if (Rec.Attributes and $400) <> 0 then Result := False
          else if (Rec.Attributes and FILE_ATTRIBUTE_DIRECTORY) <> 0 then begin
            if not PruneProgramDirectory(Child, Rel) then Result := False;
            RemoveDir(Child); { Only succeeds for an empty directory. }
          end else if KeepFiles.IndexOf(Lowercase(Rel)) < 0 then begin
            if DeleteFile(Child) then Log('Removed obsolete program file: ' + Rel)
            else begin Log('Could not remove obsolete program file: ' + Rel); Result := False; end;
          end;
        end;
      until not FindNext(Rec);
    finally FindClose(Rec); end;
  end;
end;

function InitializeSetup: Boolean;
var Key: String; OldVersion, NewVersion: Int64;
begin
  Result := True;
  Key := 'Software\Microsoft\Windows\CurrentVersion\Uninstall\{3D796B16-09D1-4FA1-ABE7-32F33562C8CA}_is1';
  IsExistingInstall := RegQueryStringValue(HKCU64, Key, 'InstallLocation', PreviousDirectory);
  if IsExistingInstall then
    RegQueryStringValue(HKCU64, Key, 'DisplayVersion', PreviousVersion)
  else begin
    IsExistingInstall := RegQueryStringValue(HKCU32, Key, 'InstallLocation', PreviousDirectory);
    if IsExistingInstall then
      RegQueryStringValue(HKCU32, Key, 'DisplayVersion', PreviousVersion);
  end;
  IsExistingInstall := IsExistingInstall and (PreviousDirectory <> '');
  if IsExistingInstall and StrToVersion(PreviousVersion, OldVersion) and
    StrToVersion('@version_numeric@', NewVersion) then begin
    if ComparePackedVersion(OldVersion, NewVersion) > 0 then begin
      SuppressibleMsgBox('เครื่องนี้มี HELLDIVERS 2 ม็อดภาษาไทย รุ่น ' + PreviousVersion +
        ' ซึ่งใหม่กว่าตัวติดตั้งนี้ กรุณาใช้ตัวติดตั้งรุ่นล่าสุด', mbError, MB_OK, IDOK);
      Result := False;
    end;
  end;
end;

function ShouldSkipPage(PageID: Integer): Boolean;
begin
  Result := IsExistingInstall and (PageID = wpSelectDir);
end;

function PrepareToInstall(var NeedsRestart: Boolean): String;
var Locator, Service, Processes: Variant;
begin
  Result := '';
  if IsExistingInstall and
    (CompareText(RemoveBackslashUnlessRoot(WizardDirValue),
      RemoveBackslashUnlessRoot(PreviousDirectory)) <> 0) then begin
    Result := 'กรุณาติดตั้งทับในโฟลเดอร์เดิม: ' + PreviousDirectory;
    Exit;
  end;
  if IsExistingInstall and not SafeProgramTree(PreviousDirectory) then begin
    Result := 'พบลิงก์โฟลเดอร์หรือเส้นทางที่ตรวจสอบไม่ได้ จึงยังไม่อัปเดต กรุณาตรวจโฟลเดอร์โปรแกรม';
    Exit;
  end;
  try
    Locator := CreateOleObject('WbemScripting.SWbemLocator');
    Service := Locator.ConnectServer('', 'root\CIMV2');
    Processes := Service.ExecQuery('SELECT Name FROM Win32_Process WHERE ' +
      'Name = ''helldivers2.exe'' OR Name = ''HD2ThaiLauncher.exe'' OR ' +
      'Name = ''start_protected_game.exe''');
    if Processes.Count > 0 then
      Result := 'กรุณาปิด HELLDIVERS 2 และ Launcher ก่อน แล้วกด ลองอีกครั้ง เพื่อติดตั้งต่อ';
  except
    Result := 'ตรวจสถานะเกมและ Launcher ไม่สำเร็จ จึงยังไม่ติดตั้ง กรุณาลองอีกครั้ง';
  end;
end;

procedure InitializeWizard;
begin
  KeepFiles := TStringList.Create;
  KeepFiles.Sorted := True;
  @keep_files@
  if IsExistingInstall then begin
    WizardForm.DirEdit.Text := PreviousDirectory;
    WizardForm.Caption := 'อัปเดตม็อด - @app_name@';
    WizardForm.WelcomeLabel1.Caption := 'พบม็อดภาษาไทยที่ติดตั้งไว้แล้ว';
    WizardForm.WelcomeLabel2.Caption := 'รุ่นที่ติดตั้งไว้: ' + PreviousVersion + #13#10 +
      'รุ่นที่จะอัปเดต: @version_numeric@' + #13#10 +
      'อัปเดตไฟล์ม็อดในโฟลเดอร์เดิม และเก็บการตั้งค่ากับใบรับรองเดิมไว้' + #13#10 +
      'ไม่ต้องถอนการติดตั้งก่อน';
    if PreviousVersion = '@version_numeric@' then
      WizardForm.WelcomeLabel2.Caption := WizardForm.WelcomeLabel2.Caption + #13#10 +
        'เป็นรุ่นเดียวกัน สามารถอัปเดตไฟล์โปรแกรมซ้ำได้';
  end;
  WizardForm.WelcomeLabel2.Height := ScaleY(140);
  WelcomeNotice := TNewStaticText.Create(WizardForm);
  WelcomeNotice.Parent := WizardForm.WelcomePage;
  WelcomeNotice.SetBounds(WizardForm.WelcomeLabel2.Left,
    WizardForm.WelcomeLabel2.Top + ScaleY(150), WizardForm.WelcomeLabel2.Width, ScaleY(110));
  WelcomeNotice.AutoSize := False;
  WelcomeNotice.WordWrap := True;
  WelcomeNotice.Font.Color := $2020D0;
  WelcomeNotice.Font.Style := [fsBold];
  WelcomeNotice.Font.Size := 11;
  WelcomeNotice.Caption := '@launcher_required_line1@' + #13#10 + '@launcher_required_line2@';
  WizardForm.FinishedLabel.Height := ScaleY(65);
  FinishedNotice := TNewStaticText.Create(WizardForm);
  FinishedNotice.Parent := WizardForm.FinishedPage;
  FinishedNotice.SetBounds(WizardForm.FinishedLabel.Left,
    WizardForm.FinishedLabel.Top + ScaleY(75), WizardForm.FinishedLabel.Width, ScaleY(100));
  FinishedNotice.AutoSize := False;
  FinishedNotice.WordWrap := True;
  FinishedNotice.Font.Color := $2020D0;
  FinishedNotice.Font.Style := [fsBold];
  FinishedNotice.Font.Size := 11;
  FinishedNotice.Caption := WelcomeNotice.Caption;
  WizardForm.RunList.Top := FinishedNotice.Top + FinishedNotice.Height + ScaleY(8);
  WizardForm.RunList.Height := ScaleY(60);
end;

procedure CurPageChanged(PageID: Integer);
begin
  if not IsExistingInstall then Exit;
  if PageID = wpWelcome then WizardForm.NextButton.Caption := 'ถัดไป >';
  if PageID = wpSelectTasks then begin
    WizardForm.PageNameLabel.Caption := 'ตัวเลือกการอัปเดตม็อด';
    WizardForm.PageDescriptionLabel.Caption := 'เลือกทางลัดที่ต้องการใช้หลังอัปเดต';
  end;
  if PageID = wpReady then begin
    WizardForm.PageNameLabel.Caption := 'พร้อมอัปเดตม็อด';
    WizardForm.PageDescriptionLabel.Caption := 'กด อัปเดตม็อด เพื่อเริ่มดำเนินการ';
    WizardForm.ReadyLabel.Caption := 'อัปเดตเป็นรุ่น @version_numeric@ โดยเก็บการตั้งค่าและใบรับรองเดิมไว้';
    WizardForm.NextButton.Caption := 'อัปเดตม็อด';
  end;
  if PageID = wpPreparing then begin
    WizardForm.PageNameLabel.Caption := 'กำลังเตรียมอัปเดตม็อด';
    WizardForm.PageDescriptionLabel.Caption := 'กำลังตรวจสอบความพร้อมก่อนอัปเดต';
  end;
  if PageID = wpInstalling then begin
    WizardForm.PageNameLabel.Caption := 'กำลังอัปเดตม็อด';
    WizardForm.PageDescriptionLabel.Caption := 'โปรดรอระหว่างอัปเดตไฟล์โปรแกรม';
  end;
  if PageID = wpFinished then begin
    WizardForm.FinishedHeadingLabel.Caption := 'อัปเดตม็อดเรียบร้อยแล้ว';
    WizardForm.FinishedLabel.Caption := 'อัปเดตเป็นรุ่น @version_numeric@ แล้ว สามารถเปิดเกมผ่านทางลัดเดิมได้';
    if CleanupIncomplete then begin
      WizardForm.FinishedHeadingLabel.Caption := 'อัปเดตแล้ว แต่เก็บไฟล์เก่าออกไม่ครบ';
      WizardForm.FinishedLabel.Caption := 'ไฟล์รุ่นใหม่ติดตั้งแล้ว แต่มีไฟล์เก่าที่ลบไม่ได้ กรุณาปิดโปรแกรมแล้วรันตัวติดตั้งนี้อีกครั้ง';
    end;
  end;
end;

function UpdateReadyMemo(Space, NewLine, MemoUserInfoInfo, MemoDirInfo,
  MemoTypeInfo, MemoComponentsInfo, MemoGroupInfo, MemoTasksInfo: String): String;
begin
  if IsExistingInstall then
    Result := 'อัปเดต HELLDIVERS 2 ม็อดภาษาไทย' + NewLine +
      'รุ่นเดิม: ' + PreviousVersion + '  →  รุ่นใหม่: @version_numeric@' + NewLine +
      'โฟลเดอร์โปรแกรม: ' + PreviousDirectory + NewLine + NewLine +
      'เก็บตำแหน่งเกม การตั้งค่า และใบรับรองเดิมไว้' + NewLine +
      'ลบไฟล์ที่เลิกใช้แล้วเฉพาะโฟลเดอร์ระบบของโปรแกรม' + NewLine + MemoTasksInfo
  else Result := MemoDirInfo + NewLine + MemoGroupInfo + NewLine + MemoTasksInfo;
end;

procedure CurStepChanged(CurStep: TSetupStep);
begin
  { Prune only after the new payload was successfully extracted. Never run the
    uninstaller and never enumerate player state or game installation folders. }
  if (CurStep = ssPostInstall) and IsExistingInstall then begin
    if (CompareText(RemoveBackslashUnlessRoot(ExpandConstant('{app}')),
      RemoveBackslashUnlessRoot(PreviousDirectory)) <> 0) then
      RaiseException('โฟลเดอร์อัปเดตไม่ตรงกับโปรแกรมเดิม');
    if not SafeProgramTree(ExpandConstant('{app}')) then begin
      CleanupIncomplete := True;
      Exit;
    end;
    WizardForm.StatusLabel.Caption := 'กำลังเก็บไฟล์โปรแกรมรุ่นเก่าออก...';
    if not PruneProgramDirectory(ExpandConstant('{app}\_internal'), '_internal') then CleanupIncomplete := True;
    if not PruneProgramDirectory(ExpandConstant('{app}\branding'), 'branding') then CleanupIncomplete := True;
    if not PruneProgramDirectory(ExpandConstant('{app}\LICENSES'), 'LICENSES') then CleanupIncomplete := True;
    if not PruneProgramDirectory(ExpandConstant('{app}\ThirdPartyNotices'), 'ThirdPartyNotices') then CleanupIncomplete := True;
  end;
end;

procedure InitializeUninstallProgressForm;
var ResultCode: Integer;
begin
  { This event runs after the normal uninstall confirmation. Keep the visible
    progress form as the owner before and after the certificate helper. }
  UninstallProgressForm.Show;
  UninstallProgressForm.BringToFront;
  if not Exec(ExpandConstant('{app}\HD2ThaiLauncher.exe'),
    '--prepare-uninstall', ExpandConstant('{app}'), SW_HIDE,
    ewWaitUntilTerminated, ResultCode) then RaiseException('ไม่สามารถเตรียมถอนการติดตั้งได้');
  if ResultCode <> 0 then RaiseException('การถอนใบรับรองยังไม่เสร็จ กรุณาลองถอนการติดตั้งใหม่');
  { Momentary topmost activation, then restore normal window behavior. }
  SetWindowPos(UninstallProgressForm.Handle, -1, 0, 0, 0, 0, $0043);
  SetWindowPos(UninstallProgressForm.Handle, -2, 0, 0, 0, 0, $0043);
  UninstallProgressForm.BringToFront;
end;
"""
values=dict(texts,app=str(app),output_dir=str(output.parent),output_basename=output.stem,icon=str(ROOT/'launcher.ico'),wizard_icon=str(ROOT/'launcher_icon.png'),sidebar=str(ROOT/'installer_graphic_v21.png'),version=version,version_numeric='.'.join((version.split('.')+['0','0'])[:3]))
values['keep_files']='\n  '.join("KeepFiles.Add('"+str(p.relative_to(app)).lower().replace("'","''")+"');" for p in sorted(app.rglob('*')) if p.is_file())
for key,value in values.items():
    if isinstance(value,str):template=template.replace('@'+key+'@',value)
script=build/'launcher_setup.iss'
script.write_text(template,encoding='utf-8-sig')
subprocess.run([str(compiler),str(script)],check=True)
report={'output':str(output),'sha256':hashlib.sha256(output.read_bytes()).hexdigest(),
        'bytes':output.stat().st_size,'install_scope':'current Windows user',
        'default_directory':r'%LOCALAPPDATA%\Programs\HD2ThaiLauncher',
        'source_files':len([p for p in app.rglob('*') if p.is_file()]),
        'third_party_notices':75,'readme_included':False,
        'code_signed':False,'game_opened':False,'installer_run':False,
        'postinstall_launch':'shell open installed Start-menu shortcut as original user',
        'upgrade_policy':'fixed AppId; same folder; preserve state and certificate; refuse downgrade; block active game or launcher',
        'installer_revision':revision}
(build/'installer_report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(report,ensure_ascii=True))
