"""Fresh public Sheets -> validated, versioned API rules -> atomic active pointer."""
import collections,csv,hashlib,io,json,os,re,time
from datetime import datetime,timezone
from pathlib import Path
import urllib.request
from thai_codec import encode,progress
from api_linebreaks import apply_api_breaks

ROOT=Path(__file__).resolve().parent
PROJECT=ROOT.parent
OUTPUT=ROOT/'API_Updates'
TABS=[('campaigns',1701027004,2),('current',1701027002,3)]
SHEET='1uRHGSv9OWwT8HGY71HmlSMSNekRNSisXliXFUavDb7k'
TOKEN=re.compile(r'<[^>]+>|#[A-Za-z][A-Za-z0-9_]*')

def download(gid):
    url=f'https://docs.google.com/spreadsheets/d/{SHEET}/export?format=csv&gid={gid}&cachebust={time.time_ns()}'
    req=urllib.request.Request(url,headers={'Cache-Control':'no-cache','Pragma':'no-cache','User-Agent':'HD2-Thai-API-Updater/1.0'})
    with urllib.request.urlopen(req,timeout=35) as response:data=response.read(16000001)
    if len(data)>16000000:raise ValueError('Sheet exceeds size limit')
    return data

def merge(sheets):
    rules={};owners={};skipped=[];conflicts=[];counts={};errors=[];linebreak_warnings=[]
    for name,gid,priority,rows in sheets:
        if len(rows[0])<10 or rows[0][0]!='รหัส API' or 'คำแปลไทย' not in rows[0][4]:
            raise ValueError(f'{name}: Sheet headers changed')
        count=0
        for number,row in enumerate(rows[1:],2):
            if not any(row):continue
            if len(row)<10:errors.append(f'{name}!{number}: missing columns');continue
            api_id,source,thai,digest=row[0],row[2],row[4],row[9]
            if hashlib.sha256(source.encode()).hexdigest()!=digest or api_id!='API-'+digest[:8].upper():
                errors.append(f'{name}!{number}: source/hash/ID mismatch');continue
            if not thai.strip():skipped.append({'tab':name,'row':number,'id':api_id});continue
            if collections.Counter(TOKEN.findall(source))!=collections.Counter(TOKEN.findall(thai)):
                errors.append(f'{name}!{number}: markup/placeholder mismatch');continue
            if '\0' in thai or '\ufffd' in thai or re.search('[\ue000-\uf8ff]',thai):
                errors.append(f'{name}!{number}: invalid raw Thai');continue
            count+=1
            if digest in rules and rules[digest]['thai']!=thai:
                prev=owners[digest]
                if prev['priority']==priority:
                    errors.append(f'{name}!{number}: duplicate source has conflicting translations');continue
                conflicts.append({'id':api_id,'previous':prev,'selected':{'tab':name,'row':number},
                                  'reason':'current > campaigns'})
            if digest not in rules or priority>=owners[digest]['priority']:
                try:prepared=apply_api_breaks(api_id,thai)
                except Exception as exc:
                    prepared=thai
                    linebreak_warnings.append({'id':api_id,'reason':str(exc),'fallback':'original readable Thai'})
                rules[digest]={'api_id':api_id,'english':source,'thai':thai,'encoded_thai':encode(prepared)}
                owners[digest]={'tab':name,'row':number,'priority':priority}
        counts[name]=count
    return rules,{'counts':counts,'untranslated':skipped,'precedence_conflicts':conflicts,'errors':errors,'linebreak_warnings':linebreak_warnings}

def main():
    OUTPUT.mkdir(exist_ok=True)
    number=max([int(x.name[1:]) for x in OUTPUT.iterdir() if x.is_dir() and re.fullmatch(r'v\d+',x.name)]+[0])+1
    folder=OUTPUT/f'v{number:03d}';folder.mkdir(exist_ok=False)
    sheets=[];progress(0,'download','API: current + campaigns')
    for i,(name,gid,priority) in enumerate(TABS):
        raw=download(gid);(folder/(name+'.csv')).write_bytes(raw)
        sheets.append((name,gid,priority,list(csv.reader(io.StringIO(raw.decode('utf-8-sig'),newline='')))))
        progress(15+i*20,'download',f'API: {name}')
    rules,report=merge(sheets)
    report.update(version=number,built_utc=datetime.now(timezone.utc).isoformat(),rules=len(rules),
                  source='fresh public Sheet exports',in_game_verified=False)
    (folder/'report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    if report['errors']:raise ValueError(f"API STOPPED: {len(report['errors'])} issues; {folder/'report.json'}; active rules unchanged")
    if not rules:raise ValueError('No translated rules; active rules unchanged')
    progress(80,'validate',f'{len(rules)} API rules; {len(report["untranslated"])} empty rows retained as English')
    target=folder/'rules.json';target.write_text(json.dumps(rules,ensure_ascii=False,indent=2),encoding='utf-8')
    assert json.loads(target.read_text(encoding='utf-8'))==rules
    pointer={'path':str(target.relative_to(PROJECT)),'sha256':hashlib.sha256(target.read_bytes()).hexdigest(),'version':number}
    temp=OUTPUT/'active.tmp.json';temp.write_text(json.dumps(pointer,indent=2),encoding='utf-8')
    os.replace(temp,OUTPUT/'active.json')
    progress(100,'done',str(target))
    print(json.dumps({'api_version':number,'rules':len(rules),'untranslated_rows':len(report['untranslated']),
                      'precedence_conflicts':len(report['precedence_conflicts'])}))

if __name__=='__main__':
    try:main()
    except Exception as e:print(str(e));raise SystemExit(1)
