import copy,hashlib,re
from urllib.parse import urlsplit
from motd_capture import fields as motd_fields
def base_candidates(path, body):
    path=urlsplit(path).path
    if re.fullmatch(r'/api/v2/Assignment/War/\d+',path) and isinstance(body,list):
        for i,item in enumerate(body):
            if isinstance(item,dict) and isinstance(item.get('setting'),dict):
                for field in ('overrideTitle','overrideBrief','taskDescription'):
                    yield item['setting'],field,('assignment',i,'setting',field)
    elif re.fullmatch(r'/api/WarSeason/\d+/Status',path) and isinstance(body,dict):
        for i,item in enumerate(body.get('globalEvents',[])):
            if isinstance(item,dict):
                for field in ('title','message'):yield item,field,('event',i,field)
    elif re.fullmatch(r'/api/NewsFeed/\d+',path) and isinstance(body,list):
        for i,item in enumerate(body):
            if isinstance(item,dict):
                for field in ('message','Message'):
                    if field in item:yield item,field,('news',i,field)
    elif re.fullmatch(r'/api/Episode/\d+',path) and isinstance(body,dict):
        for i,item in enumerate(body.get('episodes',[])):
            if not isinstance(item,dict):continue
            for field in ('title','description','introMessage','outroMessage'):
                yield item,field,('episode',i,field)
            for j,phase in enumerate(item.get('phases',[])):
                if not isinstance(phase,dict):continue
                for field in ('introTitle','introMessage','outroTitle','outroMessage'):
                    yield phase,field,('episode',i,'phase',j,field)
    elif re.fullmatch(r'/api/SpaceStation/\d+/\d+',path) and isinstance(body,dict):
        for i,item in enumerate(body.get('tacticalActions',[])):
            if isinstance(item,dict):
                for field in ('name','description','strategicDescription'):yield item,field,('station',i,field)

def candidates(path,body):
    if urlsplit(path).path=='/api/Pes/GetMotd':
        for obj,key,location in motd_fields(body):yield obj,key,('motd',)+location
    else:yield from base_candidates(path,body)

def transform(path,body,rules):
    result=copy.deepcopy(body);applied=[]
    for obj,field,location in candidates(path,result):
        source=obj.get(field)
        if not isinstance(source,str) or not source:continue
        digest=hashlib.sha256(source.encode()).hexdigest()
        rule=rules.get(digest)
        if rule and rule['english']==source and rule['encoded_thai']:
            obj[field]=rule['thai'] if location[0]=='episode' and field in ('title','introTitle','outroTitle') else rule['encoded_thai']
            applied.append({'api_id':rule['api_id'],'field':field,'location':location,'source_sha256':digest})
    return result,applied
