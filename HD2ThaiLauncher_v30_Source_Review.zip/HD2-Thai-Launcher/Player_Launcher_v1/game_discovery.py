"""Read Steam's own library/manifests, then bounded conventional paths."""
import json, os, re
from pathlib import Path

APP_ID='553850'

def valid_game(folder):
    folder=Path(folder)
    return (folder/'start_protected_game.exe').is_file() and (folder/'data').is_dir()

def registry_roots():
    import winreg
    roots=[]
    for hive,key,value in [(winreg.HKEY_CURRENT_USER,r'Software\Valve\Steam','SteamPath'),
                           (winreg.HKEY_LOCAL_MACHINE,r'SOFTWARE\Valve\Steam','InstallPath'),
                           (winreg.HKEY_LOCAL_MACHINE,r'SOFTWARE\WOW6432Node\Valve\Steam','InstallPath')]:
        try:
            with winreg.OpenKey(hive,key) as handle:roots.append(Path(winreg.QueryValueEx(handle,value)[0]))
        except OSError:pass
    return roots

def quoted_values(text,key):
    return [s.replace('\\\\','\\').replace('\\"','"') for s in re.findall(r'"'+re.escape(key)+r'"\s*"((?:\\.|[^"\\])*)"',text,re.I)]

def discover(state=None,roots=None,drives=None):
    if state:
        try:
            folder=Path(json.loads((Path(state)/'game_location.json').read_text(encoding='utf8'))['folder'])
            if valid_game(folder):return folder.resolve()
        except (OSError,ValueError,KeyError,TypeError):pass
    auto_roots=roots is None
    roots=list(registry_roots() if auto_roots else roots)
    if drives is None:
        import ctypes
        bits=ctypes.windll.kernel32.GetLogicalDrives()
        drives=[Path(chr(65+i)+':/') for i in range(26) if bits & (1<<i) and ctypes.windll.kernel32.GetDriveTypeW(chr(65+i)+':\\')==3]
    for key in ('ProgramFiles(x86)','ProgramFiles'):
        if auto_roots and os.environ.get(key):roots.append(Path(os.environ[key])/'Steam')
    for drive in drives:
        roots.extend(Path(drive)/p for p in ['Steam','SteamLibrary','Games/Steam','Games/SteamLibrary','Program Files (x86)/Steam','Program Files/Steam'])
    seen=set();libraries=[]
    for root in roots:
        root=Path(root)
        ident=str(root).casefold()
        if ident in seen:continue
        seen.add(ident);libraries.append(root)
        for relative in ('steamapps/libraryfolders.vdf','config/libraryfolders.vdf'):
            try:
                text=(root/relative).read_text(encoding='utf-8-sig')
                libraries.extend(Path(s) for s in quoted_values(text,'path'))
                # Steam's pre-2017 flat library format.
                libraries.extend(Path(s.replace('\\\\','\\')) for s in re.findall(r'"\d+"\s*"([^"\n]+)"',text))
            except OSError:pass
    for library in dict.fromkeys(libraries):
        apps=library/'steamapps'
        try:
            text=(apps/f'appmanifest_{APP_ID}.acf').read_text(encoding='utf-8-sig')
            ids=quoted_values(text,'appid');dirs=quoted_values(text,'installdir')
            if ids and ids[0]==APP_ID and dirs:
                candidate=(apps/'common'/dirs[0]).resolve()
                candidate.relative_to((apps/'common').resolve())
                if valid_game(candidate):return candidate
        except (OSError,ValueError):pass
        candidate=apps/'common/Helldivers 2'
        if valid_game(candidate):return candidate.resolve()
    return None

def location_confirmed(state,folder):
    if folder is None:return False
    try:
        saved=json.loads((Path(state)/'game_location.json').read_text(encoding='utf8'))
        return saved.get('confirmed') is True and Path(saved['folder']).resolve()==Path(folder).resolve() and valid_game(folder)
    except (OSError,ValueError,KeyError,TypeError):return False

def remember(state,folder,confirmed=False):
    folder=Path(folder).resolve()
    if not valid_game(folder):raise ValueError('เลือกโฟลเดอร์ที่มี start_protected_game.exe และ data')
    target=Path(state)/'game_location.json';temp=target.with_suffix('.tmp')
    temp.write_text(json.dumps({'folder':str(folder),'confirmed':confirmed},ensure_ascii=False),encoding='utf8');os.replace(temp,target)
    return folder
