"""Multilingual strings tables: magic, L, N, sorted languages, IDs, L*N offsets.

Unlike a language change through the game menu, Localizer.set_language alone
does not register another set of tables. Keep all three languages in each table
the game already registers. This changes data only, not native code.
"""
import struct

HASHES={'us':0x03f97b57,'gb':0x6f4515cb,'bp':0x6ef58def}
PRIVATE_CODES={'us':'us','gb':'hd2thai_debug','bp':'hd2thai_english'}
PRIVATE_HASHES={'us':0x03f97b57,'gb':0x742f1e75,'bp':0x3ed9b335}

def serialize(entries):
    languages=sorted(entries)
    ids=sorted(set().union(*(set(v) for v in entries.values())))
    header=struct.pack('<III',0x3e85f3ae,len(languages),len(ids))
    header+=struct.pack(f'<{len(languages)}I',*languages)
    header+=struct.pack(f'<{len(ids)}I',*ids)
    base=len(header)+4*len(languages)*len(ids)
    offsets=[];blob=bytearray();seen={}
    for language in languages:
        for sid in ids:
            data=entries[language][sid].encode('utf8')+b'\0'
            if b'\0' in data[:-1]:raise ValueError('Embedded NUL in text')
            if data not in seen:
                seen[data]=base+len(blob);blob.extend(data)
            offsets.append(seen[data])
    return header+struct.pack(f'<{len(offsets)}I',*offsets)+blob

def parse(data,hashes=HASHES):
    magic,nl,n=struct.unpack_from('<III',data)
    if magic!=0x3e85f3ae or nl!=3:raise ValueError('Invalid multilingual header')
    languages=struct.unpack_from(f'<{nl}I',data,12)
    ids=struct.unpack_from(f'<{n}I',data,12+4*nl)
    offsets=struct.unpack_from(f'<{nl*n}I',data,12+4*nl+4*n)
    if list(languages)!=sorted(hashes.values()):raise ValueError('Invalid languages')
    if list(ids)!=sorted(set(ids)):raise ValueError('Unsorted or duplicate IDs')
    base=12+4*nl+4*n+4*nl*n
    out={}
    for li,language in enumerate(languages):
        values=out[language]={}
        for i,sid in enumerate(ids):
            offset=offsets[li*n+i]
            if not base<=offset<len(data):raise ValueError('Invalid text offset')
            values[sid]=data[offset:data.index(b'\0',offset)].decode('utf8')
    return out

def convert_and_verify(payloads,expected,read_single):
    converted={};resident={code:[] for code in HASHES}
    inverse={v:k for k,v in HASHES.items()}
    for asset,data in payloads.items():
        original_language,values=read_single(data)
        entries={h:{sid:expected[code][sid] for sid in values} for code,h in HASHES.items()}
        result=serialize(entries)
        if parse(result)!=entries:raise ValueError('Multilingual roundtrip failed')
        converted[asset]=result
        resident[inverse[original_language]].append(parse(result))
    # Simulate the real first-match registry lookup after starting in each slot.
    # Every mode must resolve every ID correctly without loading another table.
    counts={}
    for startup,tables in resident.items():
        counts[startup]={}
        for target,language in HASHES.items():
            resolved={}
            for table in tables:
                for sid,text in table[language].items():resolved.setdefault(sid,text)
            if resolved!=expected[target]:raise ValueError(f'Resident lookup mismatch: {startup} -> {target}')
            counts[startup][target]=len(resolved)
    return converted,{'languages_per_table':3,'resources':len(converted),
                      'resident_registry_lookup_counts':counts,'in_game_verified':False}

def convert_private_and_verify(payloads,expected,read_single):
    converted={};tables=[]
    if set(PRIVATE_HASHES.values()) & {HASHES['gb'],HASHES['bp']}:
        raise ValueError('Private language collides with a vanilla slot')
    for asset,data in payloads.items():
        language,values=read_single(data)
        if language!=HASHES['us']:raise ValueError('Private modes may replace US assets only')
        entries={h:{sid:expected[code][sid] for sid in values} for code,h in PRIVATE_HASHES.items()}
        result=serialize(entries);decoded=parse(result,PRIVATE_HASHES)
        if decoded!=entries:raise ValueError('Private table roundtrip failed')
        converted[asset]=result;tables.append(decoded)
    counts={}
    for code,h in PRIVATE_HASHES.items():
        resolved={}
        for table in tables:
            for sid,text in table[h].items():resolved.setdefault(sid,text)
        if resolved!=expected[code]:raise ValueError('Private registry lookup mismatch: '+code)
        counts[PRIVATE_CODES[code]]=len(resolved)
    return converted,{'languages_per_table':3,'resources':len(converted),
        'codes':PRIVATE_CODES,'hashes':{PRIVATE_CODES[c]:hex(h) for c,h in PRIVATE_HASHES.items()},
        'resident_registry_lookup_counts':{'us':counts},'vanilla_non_us_strings_replaced':0,
        'in_game_verified':False}
