"""Validate the user's explicitly reviewed cross-string markup relocation.

Only one identity-pinned fragment/template pair is recognized. Placeholder
counts remain per-string; markup must be conserved across the pair. This is
not permission to drop arbitrary tags or accept all rows with equal totals.
"""
from collections import Counter
import re

ASSET='0x85eac40709cec253'
FRAGMENT=(ASSET,'2930240803')
TEMPLATE=(ASSET,'3004775832')
FRAGMENT_EN='</i> controlled planet'
TEMPLATE_EN='Successfully extract with <i=1>#COUNT #EQP_PRE#EQP#EQP_POST</i>#EXT_PRE#EXT#EXT_POST#DIFF_PRE#DIFF#DIFF_POST#MULTI.'
TOKENS=re.compile(r'#[A-Z][A-Z0-9_]*|<[^<>]+>')
TAGS=re.compile(r'<[^<>]+>')
PLACEHOLDERS=re.compile(r'#[A-Z][A-Z0-9_]*')

def _balanced(text):
    stack=[]
    for tag in TAGS.findall(text):
        if re.fullmatch(r'<i=\d+>',tag):stack.append('i')
        elif tag=='</i>':
            if not stack or stack.pop()!='i':return False
        else:return False
    return not stack

def reviewed_relocations(rows):
    bykey={}
    for number,row in enumerate(rows[1:],2):
        if len(row)>=8:bykey.setdefault(tuple(row[:2]),[]).append((number,row))
    if any(len(bykey.get(key,[]))!=1 for key in (FRAGMENT,TEMPLATE)):return set(),[]
    fn,f=bykey[FRAGMENT][0];tn,t=bykey[TEMPLATE][0]
    if f[2]!=FRAGMENT_EN or t[2]!=TEMPLATE_EN:return set(),[]
    if not f[3].strip() or not t[3].strip():return set(),[]
    # No migration is needed when the user restores the original tag ownership.
    if all(Counter(TOKENS.findall(r[2]))==Counter(TOKENS.findall(r[3])) for r in (f,t)):return set(),[]
    if any(Counter(PLACEHOLDERS.findall(r[2]))!=Counter(PLACEHOLDERS.findall(r[3])) for r in (f,t)):return set(),[]
    if TAGS.findall(f[3]):return set(),[]
    if Counter(TAGS.findall(t[3]))!=Counter({'<i=1>':1,'</i>':2}):return set(),[]
    if Counter(TAGS.findall(f[2]+t[2]))!=Counter(TAGS.findall(f[3]+t[3])):return set(),[]
    if not re.search(r'#EXT_PRE\s*#EXT_POST\s*#EXT\s*</i>',t[3]):return set(),[]
    # The user's reviewed construction moves the prefix text before the faction,
    # then closes its style after the faction. Verify this assembled route with
    # the actual translated opening fragment, not just aggregate tag counts.
    prefixes=[r for _,group in bykey.items() for _,r in group if r[0]==ASSET and r[2]=='on <i=1>']
    if len(prefixes)!=1:return set(),[]
    prefix=prefixes[0]
    if Counter(TOKENS.findall(prefix[2]))!=Counter(TOKENS.findall(prefix[3])):return set(),[]
    values={'#COUNT':'3','#EQP_PRE':'','#EQP':'ตัวอย่าง','#EQP_POST':'',
            '#EXT_PRE':prefix[3],'#EXT_POST':f[3],'#EXT':'ออโตมาตอน',
            '#DIFF_PRE':'','#DIFF':'','#DIFF_POST':'','#MULTI':''}
    assembled=PLACEHOLDERS.sub(lambda m:values[m.group()],t[3])
    if not _balanced(assembled):return set(),[]
    return {FRAGMENT,TEMPLATE},[{
        'rule':'user_reviewed_ext_post_closing_tag_relocation',
        'rows':[fn,tn],'debug_ids':[f[7],t[7]],
        'review_basis':'User explicitly confirmed intentional Thai word order and moving the closing tag between these strings.',
        'placeholder_counts_preserved_per_string':True,
        'markup_counts_preserved_across_pair':True,
        'assembled_ext_present_balanced':True,
        'assembly_example':assembled,
        'runtime_limit':'EXT-absent and alternative fragment-selection routes are not confirmed by this static check; no runtime rendering claim.'
    }]
