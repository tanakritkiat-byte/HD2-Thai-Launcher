"""Opt-in offline UI translation experiment from the live reviewed Sheet.

US dictionary only; literal XAML changes are shared across UI languages. This
does not implement runtime mode switching for Noesis dictionaries. All source
bytes and the separately user-tested font profile are pinned independently of
the unchanged v35 baseline lock.
"""
import collections
import copy
import csv
import hashlib
import html
import io
import json
from pathlib import Path
import re
import struct
import time
import urllib.request
import xml.etree.ElementTree as ET
from thai_linebreaks import prepare_text

HERE=Path(__file__).resolve().parent
HEADER=struct.Struct('<III20sQQ24s')
ENTRY=struct.Struct('<7Q6I')
TYPE=struct.Struct('<IIQIIII')
XAML_TYPE=0x46bc82aae9ae0565
KEY='{http://schemas.microsoft.com/winfx/2006/xaml}Key'
US_FILE='0xfed98e26c9cb758a.xaml'
UI_GID=1701027001
SHEET_ID='1uRHGSv9OWwT8HGY71HmlSMSNekRNSisXliXFUavDb7k'
TOKENS=re.compile(r'\{[^{}]+\}|\[(?:/?(?:style|bind)(?:=[^\]]*)?)\]|#[A-Z][A-Z0-9_]*|<[^<>]+>')
TAG=re.compile(r'<[\w.:]+\b(?:[^>"\']|"[^"]*"|\'[^\']*\')*>',re.S)
ATTRIBUTE=re.compile(r'(?P<pre>(?<![\w:.])(?P<name>(?:[\w]+:)?(?:Text|Content|Header|ToolTip|Watermark|PlaceholderText))\s*=\s*)(?P<q>["\'])(?P<value>.*?)(?P=q)',re.S)
STRING=re.compile(r'(?P<open><(?P<tag>[\w]+:String)\b[^>]*\bx:Key="(?P<key>[^"]+)"[^>]*>)(?P<value>.*?)(?P<close></(?P=tag)\s*>)',re.S)
# These Content values select resources/templates, not user-facing labels.
SELECTORS={'WarbondMedal_Generic','WarbondTokenLegendary','WarbondTokenPremium','Premium','PremiumBonus','Regular'}
NON_TEXT={'RadioButton','Magna eget est lorem. Faucibus'}


def digest(data):return hashlib.sha256(data).hexdigest()


def tokens(s):return collections.Counter(TOKENS.findall(s))


def load_fonts(project):
    import zipfile
    lock=json.loads((HERE/'ui_review_lock.json').read_text(encoding='utf-8'))
    from project_paths import locked_input
    path=locked_input(project,lock['font_package'])
    if digest(path.read_bytes())!=lock['font_package_sha256']:
        raise ValueError('UI experiment font profile checksum mismatch')
    with zipfile.ZipFile(path) as source:
        fonts={n:source.read(n) for n in source.namelist() if n.startswith('Fonts/')}
    if set(fonts)!=set(lock['font_members']):raise ValueError('UI font member mismatch')
    for name,data in fonts.items():
        if digest(data)!=lock['font_members'][name]:raise ValueError('UI font bytes changed: '+name)
    active=HERE/'active_font_profile.json'
    if active.exists():
        approved=json.loads(active.read_text(encoding='utf-8'))
        if not approved.get('user_approved_from'):raise ValueError('Font profile lacks user approval evidence')
        path=locked_input(project,approved['font_package'])
        if digest(path.read_bytes())!=approved['font_package_sha256']:raise ValueError('Approved font package checksum mismatch')
        with zipfile.ZipFile(path) as source:
            fonts={n:source.read(n) for n in source.namelist() if n.startswith('Fonts/')}
        if {n:digest(b) for n,b in fonts.items()}!=approved['font_members']:raise ValueError('Approved font members changed')
        lock={**lock,**approved}
    return fonts,lock


def make_patch(index, payloads):
    h=HEADER.unpack_from(index)
    if h[0]!=0xf0000011:raise ValueError('Source index magic')
    types=[list(TYPE.unpack_from(index,72+32*i)) for i in range(h[1])]
    t=next(t for t in types if t[2]==XAML_TYPE)
    original={}
    for i in range(h[2]):
        e=list(ENTRY.unpack_from(index,72+32*h[1]+80*i))
        if e[1]==XAML_TYPE:original[e[0]]=e
    out=bytearray(72+32+80*len(payloads));entries=[]
    for i,(asset,data) in enumerate(sorted(payloads.items())):
        e=list(original[asset])
        if e[8] or e[9]:raise ValueError('XAML unexpectedly has external channels')
        out.extend(b'\0'*(-len(out)%(e[10] or 16)))
        e[2]=len(out);e[3:7]=[0,0,0,0];e[7:10]=[len(data),0,0];e[12]=i
        entries.append(e);out.extend(data)
    out.extend(b'\0'*(-len(out)%16))
    HEADER.pack_into(out,0,0xf0000011,1,len(entries),bytes(20),len(out),0,bytes(24))
    t[3]=len(entries);TYPE.pack_into(out,72,*t)
    for i,e in enumerate(entries):ENTRY.pack_into(out,104+80*i,*e)
    # Independent table/offset readback, not a game rendering claim.
    seen={}
    for i in range(len(entries)):
        e=ENTRY.unpack_from(out,104+80*i)
        if e[2]<104+80*len(entries) or e[2]+e[7]>len(out):raise ValueError('UI patch bounds')
        seen[e[0]]=bytes(out[e[2]:e[2]+e[7]])
    if seen!=payloads:raise ValueError('UI patch readback mismatch')
    return bytes(out)


def build(project, folder, main_rows, encode, debug, clean_labels=False):
    if not debug and not clean_labels:raise ValueError('UI review test currently requires --debug')
    lock=json.loads((HERE/'ui_review_lock.json').read_text(encoding='utf-8'))
    source=project/lock['game_snapshot']
    registry=json.loads((HERE/'ui_debug_ids.json').read_text(encoding='utf-8'))['entries']
    url=f'https://docs.google.com/spreadsheets/d/{SHEET_ID}/export?format=csv&gid={UI_GID}&cachebust={time.time_ns()}'
    request=urllib.request.Request(url,headers={'Cache-Control':'no-cache','User-Agent':'HD2-Thai-UI-Review/1.0'})
    with urllib.request.urlopen(request,timeout=45) as response:body=response.read(40*1024*1024+1)
    if len(body)>40*1024*1024:raise ValueError('UI Sheet too large')
    (folder/'ui_sheet_original.csv').write_bytes(body)
    rows=list(csv.reader(io.StringIO(body.decode('utf-8-sig'),newline='')))
    if len(rows[0])<13 or rows[0][4]!='ช่องให้แก้/เติม (ยังไม่แพ็ค)' or rows[0][12]!='Debug ID (UI / ชุดทดสอบ)':
        raise ValueError('UI review headers changed')
    main={tuple(r[:2]):r for r in main_rows[1:] if len(r)>=8 and r[0]}
    main_ids={r[7] for r in main.values()}
    byfile=collections.defaultdict(list);seen=set();lookup=[];skipped=[];errors=[]
    for number,row in enumerate(rows[1:],2):
        if not any(row) or row[0]=='สรุป':continue
        if len(row)<13:errors.append({'row':number,'issue':'Missing UI Debug ID'});continue
        kind,key,en,_,thai=row[:5];code=row[12]
        if kind.startswith('Native:'):
            identity=tuple(key.split('/'))
            m=main.get(identity)
            if m is None or m[2]!=en or m[3]!=thai or m[7]!=code:
                errors.append({'row':number,'issue':'Native review differs from main Sheet; apply approved review to main first'})
            continue
        if kind=='XAML: พจนานุกรม':
            identity='dictionary/us/'+key;file=US_FILE
        elif kind=='XAML: ข้อความตรง':
            file,attribute=key.rsplit('/',1)
            identity='literal/'+file+'/'+attribute+'/'+digest(en.encode())
        else:errors.append({'row':number,'issue':'Unknown review row type'});continue
        if not re.fullmatch('[0-9A-Z]{3}',code) or code in seen or code in main_ids:
            errors.append({'row':number,'issue':'UI Debug ID missing or collides'})
        seen.add(code)
        if registry.get(identity,{}).get('debug_id')!=code:
            errors.append({'row':number,'issue':'Debug ID does not match persistent registry'})
        if not thai and en:errors.append({'row':number,'issue':'Empty reviewed translation'})
        if tokens(en)!=tokens(thai):errors.append({'row':number,'issue':'Placeholder or markup mismatch'})
        if '\0' in thai or '\ufffd' in thai or re.search('[\ue000-\uf8ff]',thai):
            errors.append({'row':number,'issue':'Invalid raw Thai text'})
        skip=(kind=='XAML: ข้อความตรง' and en in SELECTORS|NON_TEXT)
        item={'row':number,'kind':kind,'identity':identity,'key':key,'english':en,'thai':thai,'debug':code,
              'file':file,'skip':skip,'encoded':(prepare_text(thai)[0] if clean_labels else encode(prepare_text(thai)[0]))+(f' [{code}]' if debug and thai and not skip else '')}
        if skip:skipped.append({'row':number,'source':en,'reason':'resource selector or non-user placeholder; preserved'})
        byfile[file].append(item);lookup.append(item)
    if len(seen)!=len(registry):errors.append({'issue':'UI review rows missing from persistent registry'})
    (folder/'ui_validation.json').write_text(json.dumps({'errors':errors,'skipped':skipped},ensure_ascii=False,indent=2),encoding='utf-8')
    if errors:raise ValueError(f'{len(errors)} UI validation issues; see {folder / "ui_validation.json"}')
    inventory=json.loads((source/'inventory.json').read_text(encoding='utf-8'))
    locations={r['hash'].lower():r for r in inventory['records'] if r['kind']=='xaml'}
    payloads=collections.defaultdict(dict);changed=[];counts={}
    for filename,items in byfile.items():
        name=filename.removesuffix('.xaml');raw=(source/'xaml'/(name+'.bin')).read_bytes()
        if digest(raw)!=lock['source_files'][name]:raise ValueError('Source XAML changed: '+name)
        declared=struct.unpack_from('<I',raw)[0]
        if declared!=len(raw)-16:raise ValueError('XAML envelope length mismatch')
        original_xml=raw[16:];bom=original_xml.startswith(b'\xef\xbb\xbf')
        original=original_xml.decode('utf-8-sig')
        tree=ET.fromstring(original);before=list(tree.iter());old_dict={el.get(KEY):el.text or '' for el in before if el.tag.endswith('}String') and el.get(KEY)}
        replacements={};dictionary={}
        for item in items:
            if item['skip']:continue
            if item['kind']=='XAML: พจนานุกรม':
                if old_dict.get(item['key'])!=item['english']:raise ValueError('US source mismatch '+item['key'])
                dictionary[item['key']]=item
            else:
                _,attr=item['key'].rsplit('/',1)
                replacements[attr,item['english']]=item
            counts[item['identity']]=0
        def replace_string(match):
            item=dictionary.get(match['key'])
            if item is None:return match[0]
            counts[item['identity']]+=1
            return match['open']+html.escape(item['encoded'],quote=False)+match['close']
        modified=STRING.sub(replace_string,original)
        def replace_tag(match):
            def attribute(m):
                value=html.unescape(m['value'].replace('\r\n','\n').replace('\n',' ').replace('\t',' '))
                item=replacements.get((m['name'].rsplit(':',1)[-1],value))
                if item is None:return m[0]
                escaped=html.escape(item['encoded'],quote=True).replace('\r','&#13;').replace('\n','&#10;').replace('\t','&#9;')
                counts[item['identity']]+=1
                return m['pre']+m['q']+escaped+m['q']
            return ATTRIBUTE.sub(attribute,match[0])
        modified=TAG.sub(replace_tag,modified)
        parsed=ET.fromstring(modified);after=list(parsed.iter())
        if len(before)!=len(after):raise ValueError('XML element count changed')
        for old,new in zip(before,after):
            if old.tag!=new.tag or set(old.attrib)!=set(new.attrib):raise ValueError('XML structure changed')
            for attr,value in old.attrib.items():
                item=replacements.get((attr.rsplit('}',1)[-1],value))
                expected=item['encoded'] if item else value
                if new.attrib[attr]!=expected:raise ValueError('Unexpected XML attribute change')
            item=dictionary.get(old.get(KEY)) if old.tag.endswith('}String') else None
            expected=item['encoded'] if item else old.text
            if new.text!=expected or old.tail!=new.tail:raise ValueError('Unexpected XML text change')
        for item in items:
            if not item['skip'] and counts[item['identity']]<1:raise ValueError('UI replacement not found at row '+str(item['row']))
        if modified==original:continue
        encoded=(b'\xef\xbb\xbf' if bom else b'')+modified.encode('utf-8')
        out=bytearray(raw[:16]);struct.pack_into('<I',out,0,len(encoded));out.extend(encoded)
        archive=locations[name]['Archive'];payloads[archive][int(name,16)]=bytes(out)
        changed.append({'resource':name,'archive':archive,'source_sha256':digest(raw),'patched_sha256':digest(out),'rows':len(items)})
    extras={}
    for archive,resources in payloads.items():
        index=(source/'archive_indexes'/(archive+'.bin')).read_bytes()
        if digest(index)!=lock['archive_indexes'][archive]:raise ValueError('Source index changed')
        extras['UI/'+archive+'.patch_0']=make_patch(index,resources)
    report={'sheet_gid':UI_GID,'sheet_csv_sha256':digest(body),'debug_ids':len(seen),'translated_rows':sum(not i['skip'] for i in lookup),
        'source':'fresh public UI review tab, column E','dictionary_language':'US only','literal_changes_shared_across_languages':True,
        'private_mode_switching_for_xaml_verified':False,'in_game_verified':False,'changed_resources':changed,
        'replacement_counts':counts,'skipped':skipped,'lookup':[{k:v for k,v in i.items() if k!='encoded'} for i in lookup]}
    text=json.dumps(report,ensure_ascii=False,indent=2)
    (folder/'ui_build_report.json').write_text(text,encoding='utf-8')
    extras['diagnostics/ui-review-build-report.json']=text.encode('utf-8')
    return extras,report
