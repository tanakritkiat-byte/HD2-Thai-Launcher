"""Build-time ICU wrapping for every translated API entry."""
from thai_linebreaks import line_boundaries,prepare_text,ZWSP,PROTECTED_TERMS

def apply_api_breaks(api_id,text):
    return prepare_text(text)[0]
