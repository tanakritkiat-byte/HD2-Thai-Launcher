"""Approved public presentation only; never edits game resource payloads."""
import hashlib
import json
import re
from pathlib import Path
import uuid
import zipfile

CONFIG = Path(__file__).with_name('public_release.json')

def release_version(value):
    value=value.strip()
    if value.startswith(('v','V')):value=value[1:]
    if len(value)>48 or not re.fullmatch(r'\d+(?:\.\d+){0,3}(?:-[A-Za-z0-9]+(?:[.-][A-Za-z0-9]+)*)?',value):
        raise ValueError('เวอร์ชันเผยแพร่ไม่ถูกต้อง เช่น 1.0.0 หรือ 1.0.1-beta')
    return value


def public_filename(version):
    # Keep this distinct from vNNN internal build names and their version scan.
    return 'HD2_Thai_Translation_'+release_version(version)+'.zip'


def public_identity(config):
    version=release_version(config['public_version'])
    return str(uuid.uuid5(uuid.UUID(config['guid']),'public-release:'+version)),config['name']+' v'+version


def load_config():
    config = json.loads(CONFIG.read_text(encoding='utf-8'))
    if config.get('approved') is not True:
        raise ValueError('Public release text/artwork is awaiting Pa-Kai review; normal packaging is unchanged')
    uuid.UUID(config['guid'])
    for field in ('name', 'description', 'option_name', 'option_description'):
        if not isinstance(config.get(field), str) or not config[field].strip():
            raise ValueError('Missing public release field: ' + field)
    config['public_version']=release_version(config['public_version'])
    return config


def clean_package(source, destination, config):
    """Allowlist installation resources + existing license; verify byte identity."""
    source, destination = Path(source), Path(destination)
    if destination.exists():
        raise FileExistsError(destination)
    guid,name=public_identity(config)
    manifest = {
        'Version': 1, 'Guid': guid, 'Name': name,
        'Description': config['description'], 'IconPath': None,
        'Options': [{'Name': config['option_name'],
                     'Description': config['option_description'], 'Include': ['Mod']}],
    }
    icon = config.get('icon')
    if icon:
        path = CONFIG.parent / icon
        if path.suffix.lower() != '.png' or not path.is_file():
            raise ValueError('Approved Arsenal icon must be an existing PNG')
        manifest['IconPath'] = 'icon.png'
    nexus_id = config.get('nexus_mod_id')
    if nexus_id is not None:
        if type(nexus_id) is not int or nexus_id <= 0:
            raise ValueError('Invalid Nexus mod ID')
        manifest['NexusData'] = {'ModId': nexus_id, 'Version': config['public_version']}
    kept, removed = {}, []
    with zipfile.ZipFile(source) as original:
        if original.testzip():
            raise ValueError('Source ZIP failed integrity check')
        for name in original.namelist():
            if name.startswith(('Fonts/', 'UI/', 'data/')):
                if not ('.patch_' in name and name.endswith(('.patch_0', '.patch_3', '.patch_4', '.stream', '.gpu_resources'))):
                    raise ValueError('Unreviewed install member: ' + name)
                # Arsenal's option resolver in the installed version indexes
                # files directly inside Include folders, not nested subfolders.
                destination_name='Mod/'+Path(name).name
                if destination_name in kept:
                    raise ValueError('Flattened install filename collision: '+destination_name)
                kept[destination_name] = original.read(name)
            elif name.startswith('LICENSES/'):
                kept[name] = original.read(name)
            else:
                removed.append(name)
    for required in ('Mod/9ba626afa44a3aa3.patch_3', 'Mod/9ba626afa44a3aa3.patch_4', 'LICENSES/NotoThai-OFL.txt'):
        if required not in kept:
            raise ValueError('Public standalone package is missing: ' + required)
    install_members={n for n in kept if '.patch_' in n}
    included={n for n in install_members if str(Path(n).parent).replace('\\','/') in manifest['Options'][0]['Include']}
    if not install_members or included!=install_members:
        raise ValueError('Arsenal manifest does not directly include every patch member')
    kept['manifest.json'] = json.dumps(manifest, ensure_ascii=False, indent=2).encode('utf-8')
    if icon:
        kept['icon.png'] = path.read_bytes()
    with zipfile.ZipFile(destination, 'x', zipfile.ZIP_DEFLATED, compresslevel=6) as target:
        for name, data in kept.items():
            target.writestr(name, data)
    with zipfile.ZipFile(destination) as target:
        if target.testzip() or target.namelist() != list(kept):
            raise ValueError('Public ZIP integrity/member verification failed')
        for name, data in kept.items():
            if target.read(name) != data:
                raise ValueError('Public ZIP member differs: ' + name)
    return {'removed_from_zip': removed, 'manifest': manifest,
            'arsenal_direct_include_members':sorted(included),
            'members': {name: hashlib.sha256(data).hexdigest() for name, data in kept.items()},
            'game_payloads_byte_identical': True, 'arsenal_import_tested': False}
