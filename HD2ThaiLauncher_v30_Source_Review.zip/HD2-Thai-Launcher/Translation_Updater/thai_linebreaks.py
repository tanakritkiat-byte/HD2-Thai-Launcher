"""Build-time ICU Thai break opportunities; preserve wording, tags and timings."""
import ctypes
from functools import lru_cache
import os
import re
import unicodedata

ZWSP='\u200b'
PROTECTED_TERMS=('เดอะวอยด์','กลยุทธภัณฑ์')
CUE=re.compile(r'\{\d+(?:\.\d+)?->\d+(?:\.\d+)?\}')
OPAQUE=re.compile(r'<(?:[^>"\']|"[^"]*"|\'[^\']*\')*>|\{[^{}]*\}|\[(?:/?(?:style|bind)(?:=[^\]]*)?)\]|#[A-Za-z][A-Za-z0-9_]*')

@lru_cache(maxsize=1)
def _icu():
    dll=ctypes.CDLL(os.path.join(os.environ['SystemRoot'],'System32','icu.dll'))
    dll.ubrk_open.argtypes=[ctypes.c_int,ctypes.c_char_p,ctypes.POINTER(ctypes.c_uint16),ctypes.c_int32,ctypes.POINTER(ctypes.c_int)]
    dll.ubrk_open.restype=ctypes.c_void_p
    for name in ('ubrk_first','ubrk_next'):
        f=getattr(dll,name);f.argtypes=[ctypes.c_void_p];f.restype=ctypes.c_int32
    dll.ubrk_close.argtypes=[ctypes.c_void_p];dll.ubrk_close.restype=None
    return dll

@lru_cache(maxsize=16384)
def line_boundaries(text):
    if not re.search('[ก-๛]',text):return ()
    raw=text.encode('utf-16-le');units=len(raw)//2
    buffer=(ctypes.c_uint16*(units+1))();ctypes.memmove(buffer,raw,len(raw))
    dll=_icu();status=ctypes.c_int(0)
    it=dll.ubrk_open(2,b'th',buffer,units,ctypes.byref(status))
    if not it or status.value>0:
        if it:dll.ubrk_close(it)
        raise RuntimeError('Windows ICU line iterator failed: '+str(status.value))
    offsets={0:0};at=0
    for i,c in enumerate(text):at+=len(c.encode('utf-16-le'))//2;offsets[at]=i+1
    out=[]
    try:
        at=dll.ubrk_first(it)
        while at!=-1:
            if at in offsets:out.append(offsets[at])
            at=dll.ubrk_next(it)
    finally:dll.ubrk_close(it)
    return tuple(out)

def _opportunities(text):
    positions=[];start=0
    for token in list(OPAQUE.finditer(text))+[None]:
        end=token.start() if token else len(text)
        chunk=text[start:end];protected=[]
        for term in PROTECTED_TERMS:
            protected.extend((m.start(),m.end()) for m in re.finditer(re.escape(term),chunk))
        for p in line_boundaries(chunk):
            if not 0<p<len(chunk):continue
            a,b=chunk[p-1],chunk[p]
            if not ('\u0e01'<=a<='\u0e5b' and '\u0e01'<=b<='\u0e5b'):continue
            if unicodedata.category(b).startswith('M') or b=='ำ' or a in 'เแโใไ':continue
            if any(lo<p<hi for lo,hi in protected):continue
            positions.append(start+p)
        start=token.end() if token else len(text)
    return positions

def _part(text,budget):
    candidates=_opportunities(text)
    slots=len(candidates) if budget is None else max(0,(budget-len(text.encode('utf-8')))//3)
    limited=len(candidates)>slots
    if limited:
        # Spread limited 3-byte opportunities across a cue, preserving all text.
        candidates=[candidates[(i*len(candidates))//slots] for i in range(slots)] if slots else []
    chosen=set(candidates)
    return ''.join((ZWSP if i in chosen else '')+c for i,c in enumerate(text)),len(chosen),limited

def prepare_text(text,subtitle_budget=144):
    if not re.search('[ก-๛]',text):return text,{'inserted':0,'limited_cues':0,'timed_cues':0}
    cues=list(CUE.finditer(text));out=[];inserted=limited=0;spans=[]
    if not cues:spans=[(0,len(text),None)]
    else:
        if cues[0].start():spans.append((0,cues[0].start(),None))
        for i,c in enumerate(cues):spans.append((c.end(),cues[i+1].start() if i+1<len(cues) else len(text),subtitle_budget))
    last=0
    for a,b,budget in spans:
        out.append(text[last:a]);part,n,cap=_part(text[a:b],budget)
        out.append(part);last=b;inserted+=n;limited+=cap
    out.append(text[last:])
    return ''.join(out),{'inserted':inserted,'limited_cues':limited,'timed_cues':len(cues)}
