"""Artifact locations; locked hashes and filenames remain unchanged."""
from pathlib import Path

def locked_input(project, relative):
    original=Path(project)/relative
    if original.is_file():return original
    relocated=Path(project)/'Translation_Updater/Locked_Inputs'/relative
    return relocated

def translations(project):return Path(project)/'Releases/Translations'

def version_roots(project):
    project=Path(project)
    return [project,translations(project),project/'Builds',project/'Archive/Builds']
