"""Build US Thai, GB Thai+ID and BR original US from verified local resources."""
import json
import struct
import re

HASHES={'gb':0x6f4515cb,'bp':0x6ef58def}

def read_payload(data):
    magic,language_count,count,language=struct.unpack_from('<4I',data)
    assert magic==0x3e85f3ae and language_count==1
    keys=struct.unpack_from(f'<{count}I',data,16)
    offsets=struct.unpack_from(f'<{count}I',data,16+count*4)
    return language,{k:data[o:data.index(b'\0',o)].decode('utf8') for k,o in zip(keys,offsets)}

def build(builder,thai_patch,sheet,folder,hot_swap_tables=False,private_modes=False):
    h=builder.HEADER.unpack_from(thai_patch)
    start=builder.HEADER.size+h[1]*32
    entries=[builder.ENTRY.unpack_from(thai_patch,start+i*builder.ENTRY.size) for i in range(h[2])]
    payloads={e[0]:thai_patch[e[2]:e[2]+e[7]] for e in entries}
    thai={e[0]:read_payload(payloads[e[0]])[1] for e in entries}
    source={}
    catalogs={'gb':{},'bp':{}}
    for p in folder.glob('*.strings.json'):
        d=json.loads(p.read_text(encoding='utf8'))
        lang=(d.get('Language') or {}).get('KnownName')
        asset=int(p.name.split('.')[0],16)
        values={int(x['Key']):x['Value'] for x in d['Items']}
        if lang=='us':source[asset]=values
        elif lang in catalogs:catalogs[lang][asset]=values
    all_us={}
    for values in source.values():
        for k,v in values.items():
            if k in all_us and all_us[k]!=v:raise ValueError(f'Ambiguous US text ID {k}')
            all_us[k]=v
    all_thai={k:v for values in thai.values() for k,v in values.items()}
    debug_ids={k:row['debug'] for values in sheet.values() for k,row in values.items()}
    expected={'us':all_thai,'gb':{k:v+(f' [{debug_ids[k]}]' if k in debug_ids else '') for k,v in all_thai.items()},'bp':all_us}
    # The ID registry resolves text across tables. Put missing US-only groups into
    # an existing largest destination table rather than inventing resource names.
    mapping=[]
    if private_modes:catalogs={}
    for lang,tables in catalogs.items():
        if not tables:raise ValueError(f'Missing {lang} resources')
        generated={}; assigned=set()
        for asset,values in tables.items():
            overlaps=sorted([(len(set(values)&set(v)),us) for us,v in source.items()],reverse=True)
            if not overlaps[0][0] or overlaps[0][0]==overlaps[1][0]:raise ValueError('Ambiguous language resource mapping')
            us=overlaps[0][1]
            generated[asset]={k:expected[lang][k] for k in source[us]}
            assigned.update(generated[asset])
            mapping.append({'language':lang,'asset':hex(asset),'us_asset':hex(us)})
        missing=set(expected[lang])-assigned
        largest=max(generated,key=lambda a:len(generated[a]))
        generated[largest].update({k:expected[lang][k] for k in missing})
        mapping.append({'language':lang,'additional_us_keys':len(missing),'added_to':hex(largest)})
        for asset,values in generated.items():
            builder.LANGUAGE_HASH=HASHES[lang]
            payloads[asset]=builder.make_strings_payload(values)
    builder.LANGUAGE_HASH=0x03f97b57
    # Independently read serialized text back, including every debug suffix.
    found={lang:{} for lang in expected}
    language_names={0x03f97b57:'us',**{v:k for k,v in HASHES.items()}}
    for data in payloads.values():
        lang,values=read_payload(data);found[language_names[lang]].update(values)
    for lang in (['us'] if private_modes else expected):
        if found[lang]!=expected[lang]:raise ValueError('Serialized language mismatch: '+lang)
    for sid,text in expected['gb'].items():
        # Suffixes follow the last cue, identical to the normal debug method.
        matches=list(re.finditer(r'\{\d+(?:\.\d+)?->\d+(?:\.\d+)?\}',text))
        for i,cue in enumerate(matches):
            body=text[cue.end():matches[i+1].start() if i+1<len(matches) else len(text)]
            if sid in debug_ids and len(body.encode('utf8'))>150:raise ValueError(f'Debug subtitle exceeds 150 bytes: {sid}')
    if private_modes:
        from hot_swap_tables import convert_private_and_verify
        payloads,hot_swap_report=convert_private_and_verify(payloads,expected,read_payload)
    elif hot_swap_tables:
        from hot_swap_tables import convert_and_verify
        payloads,hot_swap_report=convert_and_verify(payloads,expected,read_payload)
    es=[];chunks=[];position=builder.HEADER.size+32+len(payloads)*builder.ENTRY.size
    for index,(asset,data) in enumerate(sorted(payloads.items())):
        position+=(-position)%16
        e=list(entries[0]);e[0]=asset;e[2]=position;e[3:7]=[0,0,0,0];e[7:10]=[len(data),0,0];e[10]=16;e[12]=index
        es.append(e);chunks.append((position,data));position+=len(data)
    out=bytearray(position+(-position)%16)
    header=list(h);header[1]=1;header[2]=len(es)
    out[:builder.HEADER.size]=builder.HEADER.pack(*header)
    type_record=bytearray(thai_patch[builder.HEADER.size:builder.HEADER.size+32]);struct.pack_into('<I',type_record,16,len(es))
    out[builder.HEADER.size:builder.HEADER.size+32]=type_record
    for index,e in enumerate(es):builder.ENTRY.pack_into(out,builder.HEADER.size+32+index*builder.ENTRY.size,*e)
    for offset,data in chunks:out[offset:offset+len(data)]=data
    mode_map=({'us':'Thai','hd2thai_debug':'Thai + Debug ID','hd2thai_english':'Original English US'}
              if private_modes else {'us':'Thai','gb':'Thai + Debug ID','bp':'Original English US (Portuguese Brazil slot)'})
    return bytes(out),{'hot_swap_tables':hot_swap_report if hot_swap_tables else False,
                       'private_modes':private_modes,'mode_map':mode_map,
                       'text_counts':{k:len(v) for k,v in expected.items()},'resources':len(es),'mapping':mapping,
                       'in_game_language_switch_verified':False}
