"""Include our own boot script; no third-party loader code is redistributed."""
import hashlib,json,struct,zipfile

def package_files(project):
    from project_paths import locked_input
    profile_path=project/'Translation_Updater/active_hotkey_profile.json'
    profile=json.loads(profile_path.read_text(encoding='utf8')) if profile_path.exists() else None
    path=locked_input(project,profile['package'] if profile else 'HD2_Thai_Language_Hotkeys_v6_PrivateModes.zip')
    if profile and hashlib.sha256(path.read_bytes()).hexdigest()!=profile['package_sha256']:
        raise ValueError('Active hotkey package checksum mismatch')
    with zipfile.ZipFile(path) as z:
        if z.testzip() is not None:raise ValueError('Invalid hotkey source ZIP')
        patch=z.read('core/9ba626afa44a3aa3.patch_0')
        source=z.read('source/mod.lua')
    source_path=project/(profile['source'] if profile else 'Language_Switch_v6/mod.lua')
    if source!=source_path.read_bytes():
        raise ValueError('Hotkey ZIP/source mismatch')
    if profile and hashlib.sha256(source).hexdigest()!=profile['source_sha256']:
        raise ValueError('Active hotkey source checksum mismatch')
    magic,types,count=struct.unpack_from('<III',patch)
    if (magic,types,count)!=(0xf0000011,1,1):raise ValueError('Invalid boot archive')
    e=struct.unpack_from('<7Q6I',patch,104)
    if (e[0],e[1])!=(0xf476df93691895fa,0xa14e8dfa2cd117e2):
        raise ValueError('Not our boot Lua resource')
    if patch[e[2]:e[2]+e[7]]!=struct.pack('<II',len(source),2)+source:
        raise ValueError('Boot payload mismatch')
    for code in ['us','hd2thai_debug','hd2thai_english']:
        if ("code='"+code+"'").encode() not in source:raise ValueError('Missing mode code')
    instructions='''ชุดรวมคำแปล ฟอนต์ และปุ่มสลับ สำหรับผู้ที่ไม่มีม็อดสคริปต์อื่น
ติดตั้ง ZIP นี้ตัวเดียว ไม่ต้องลง Chef หรือตัวปุ่ม v6 แยก
ปิดแพ็คแปลเดิม ตัวปุ่มเดิม และ Chef/ตัวโหลดอื่นก่อนทดสอบชุด standalone นี้
ตั้งภาษาข้อความในเกมเป็น English US
Page Up: ไทย → ไทย+Debug ID → อังกฤษต้นฉบับ
Page Down: ย้อนกลับตามลำดับ หยุดที่หัวและท้าย ไม่วนรอบ
หลังกดสลับยังต้องกด Esc เพื่อรีเฟรชข้อความครบ
ไม่แทนตารางคำแปลของภาษาอื่น ฟอนต์และกฎยกวรรณยุกต์ใช้ฐานเดิม
รายงานจุดแก้ด้วย Debug ID พร้อมภาพและบริบท
ชุด standalone นี้ยังต้องยืนยันการทำงานในเกมโดยไม่เปิด Chef
หากจะใช้ร่วมม็อดสคริปต์อื่น ให้ใช้ชุด PrivateModes + hotkeys + Chef แยกแทน
'''
    files={'data/9ba626afa44a3aa3.patch_4':patch,
           'วิธีใช้ชุดรวม.txt':instructions.encode('utf8')}
    return files,{'source_zip':path.name,'boot_sha256':hashlib.sha256(patch).hexdigest(),
                  'source_sha256':hashlib.sha256(source).hexdigest(),
                  'controls':profile.get('controls') if profile else 'F6/F7/F8',
                  'third_party_loader_included':False,'in_game_standalone_verified':False}
