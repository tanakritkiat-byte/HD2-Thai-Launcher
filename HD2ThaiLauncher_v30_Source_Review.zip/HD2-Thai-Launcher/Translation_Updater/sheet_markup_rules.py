"""Declarative Sheet rules. No code/eval or disabling base validation."""
from collections import Counter
import csv,hashlib,io,json,re,time,urllib.request
from pathlib import Path

METHOD='ไม่ตรวจแท็ก'
RULE_GID=1701027017
SHEET='1uRHGSv9OWwT8HGY71HmlSMSNekRNSisXliXFUavDb7k'
HEADERS=['Debug ID','ตรวจแท็ก','ตรวจตัวแปร','ตรวจเวลาในซับ','ตรวจไบต์ซับ','หมายเหตุ',
         'ตรวจไบต์คำอธิบาย','เพดานไบต์คำอธิบาย']
CHECKS=('tags','placeholders','subtitle_time','subtitle_bytes')
DEBUG=re.compile(r'[0-9A-Z]{3}')
TAGS=re.compile(r'<[^<>]+>')
PLACEHOLDERS=re.compile(r'#[A-Z][A-Z0-9_]*')

def parse_rules(raw):
    rows=list(csv.reader(io.StringIO(raw.decode('utf-8-sig'),newline='')))
    legacy=bool(rows and rows[0][:4]==['เปิดใช้','Debug ID','วิธีตรวจ','หมายเหตุ'])
    if not rows or (not legacy and (rows[0][:6]!=HEADERS[:6] or (any(rows[0][6:8]) and rows[0][6:8]!=HEADERS[6:8]))):raise ValueError('หัวตารางหน้าเงื่อนไขตรวจคำแปลเปลี่ยนไป')
    rules=[];seen=set()
    if len(rows)>1000:raise ValueError('หน้าเงื่อนไขมีจำนวนแถวเกินขอบเขต')
    for number,row in enumerate(rows[1:],2):
        row=row+['']*max(0,8-len(row))
        def fail(why):raise ValueError(f'เงื่อนไขตรวจคำแปล แถว {number}: {why}')
        if legacy:
            if row[0].strip().upper() in ('','FALSE'):continue
            if row[0].strip().upper()!='TRUE' or row[2]!=METHOD:fail('เงื่อนไขรุ่นเก่าไม่ถูกต้อง')
            debug=row[1].strip().upper();checks=dict.fromkeys(CHECKS,True);checks['tags']=False;reason=row[3]
        else:
            debug=row[0].strip().upper()
            if not debug:
                if row[5].strip() or row[7].strip() or row[6].strip().upper()=='TRUE':fail('มีเงื่อนไขแต่ไม่ได้ระบุ Debug ID')
                continue
            checks={}
            for key,value in zip(CHECKS,row[1:5]):
                value=value.strip().upper()
                if value not in ('TRUE','FALSE'):fail('ช่องตรวจทุกช่องต้องติ๊กหรือไม่ติ๊ก ห้ามเว้นว่าง')
                checks[key]=value=='TRUE'
            reason=row[5]
            enabled=row[6].strip().upper()
            if enabled not in ('','TRUE','FALSE'):fail('ตรวจไบต์คำอธิบายต้องเป็นกล่องติ๊ก')
            if enabled=='TRUE':
                if not re.fullmatch(r'[1-9][0-9]{0,4}',row[7].strip()) or int(row[7])>65535:
                    fail('เพดานไบต์คำอธิบายต้องเป็นจำนวนเต็ม 1–65535')
                checks['max_utf8_bytes']=int(row[7])
        if not DEBUG.fullmatch(debug) or debug in seen:fail('Debug ID ไม่ถูกต้องหรือซ้ำ')
        rules.append({'debug':debug,'name':debug,'reason':reason,'checks':checks,'config_row':number})
        seen.add(debug)
    return rules

def load_review_rules(build,cache_dir=None):
    build=Path(build);cache=Path(cache_dir)/'validation_checks_v29_cached.csv' if cache_dir else None
    url=f'https://docs.google.com/spreadsheets/d/{SHEET}/export?format=csv&gid={RULE_GID}&cachebust={time.time_ns()}'
    try:
        req=urllib.request.Request(url,headers={'Cache-Control':'no-cache','User-Agent':'HD2-Thai-Rule-Reader/1.0'})
        opener=urllib.request.build_opener(urllib.request.ProxyHandler({}))
        with opener.open(req,timeout=8) as response:raw=response.read(1000001)
        if len(raw)>1000000:raise ValueError('ข้อมูลเงื่อนไขใหญ่เกินขอบเขต')
    except (OSError,TimeoutError) as exc:
        if cache and cache.is_file():raw=cache.read_bytes();rules=parse_rules(raw);source='last_valid_cached_rules'
        else:rules=[{'debug':d,'name':d,'reason':'User-approved tag exception','checks':dict(tags=False,placeholders=True,subtitle_time=True,subtitle_bytes=True),'config_row':None} for d in ('C8Z','C90')];raw=b'';source='bundled_tag_exceptions'
        report={'source':source,'gid':RULE_GID,'download_failed':type(exc).__name__,'rules':len(rules) if rules is not None else 1}
    else:
        # Malformed fresh rules are reported, never replaced silently by old data.
        rules=parse_rules(raw);report={'source':'fresh_public_sheet','gid':RULE_GID,'rules':len(rules),'sha256':hashlib.sha256(raw).hexdigest()}
    if raw:(build/'markup_rules_original.csv').write_bytes(raw)
    (build/'markup_rules_source.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    return rules

def commit_review_rules(build,cache_dir):
    """Cache only after the caller has passed the complete main validation."""
    build=Path(build)
    report=json.loads((build/'markup_rules_source.json').read_text(encoding='utf-8'))
    if report['source']!='fresh_public_sheet':return
    cache=Path(cache_dir)/'validation_checks_v29_cached.csv';cache.parent.mkdir(parents=True,exist_ok=True)
    tmp=cache.with_suffix('.tmp');tmp.write_bytes((build/'markup_rules_original.csv').read_bytes());tmp.replace(cache)

def reviewed_relocations(rows,rules=None):
    bydebug={}
    for number,row in enumerate(rows[1:],2):
        if len(row)>=8:bydebug.setdefault(row[7],[]).append((number,row))
    policies={};reports=[]
    for rule in rules or []:
        matches=bydebug.get(rule['debug'],[])
        report={'rule':rule['debug'],'config_row':rule['config_row'],
                'valid':len(matches)==1,'checks':rule['checks'],'reason':rule['reason']}
        if len(matches)==1:
            number,row=matches[0];policies[tuple(row[:2])]=rule['checks']
            report.update(row=number,debug_id=row[7],skipped_checks=[k for k,v in rule['checks'].items() if not v])
        else:report['reason']='Debug ID ไม่พบหรือซ้ำ: '+rule['debug']
        reports.append(report)
    return policies,reports
