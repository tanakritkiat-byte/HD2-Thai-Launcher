"""Versioned HD2 packaging. Does not edit the Sheet or install game files."""
from __future__ import annotations

import argparse
from collections import Counter
import copy
import csv
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
from pathlib import Path
import re
import sys
import time
import urllib.request
import zipfile
from thai_linebreaks import prepare_text
from sheet_markup_rules import reviewed_relocations, load_review_rules, commit_review_rules

ROOT = Path(__file__).resolve().parent
PROJECT = ROOT.parent
PATCH = 'data/9ba626afa44a3aa3.patch_3'
PUBLIC_SHEET_ID = '1uRHGSv9OWwT8HGY71HmlSMSNekRNSisXliXFUavDb7k'
PUBLIC_MAIN_GID = 1202667276
HEADERS = ['Asset ID', 'String ID', 'English source', 'Thai translation',
           'Approved', 'Approved', 'Old Thai reference (raw; may contain PUA)',
           'Debug ID (base36)']
CUE = re.compile(r'\{(\d+(?:\.\d+)?)->(\d+(?:\.\d+)?)\}')
TOKEN = re.compile(r'#[A-Z][A-Z0-9_]*|<[^<>]+>')
UPPER = set('ัิีึื็ํ')
TONE = dict(zip('่้๊๋', '\ue004\ue001\ue002\ue003'))
AM = dict(zip('่้๊๋', '\ue006\ue007\ue008\ue009'))
TALL_MARKS = ''.join(chr(cp) for cp in (0xe31,0xe34,0xe35,0xe36,0xe37,0xe47,0xe48,0xe49,0xe4a,0xe4b,0xe4c,0xe4d,0xe4e,*range(0xe001,0xe00a)))
TALL_SHIFT = {c:chr(0xe100+i) for i,c in enumerate(TALL_MARKS)}
CHULA_SHIFT = {c:chr(0xe140+i) for i,c in enumerate(TALL_MARKS)}


def progress(percent, stage, detail=''):
    print('HD2_PROGRESS ' + json.dumps({'percent': percent, 'stage': stage,
                                      'detail': detail}, ensure_ascii=True), flush=True)


def digest(path):
    h = hashlib.sha256()
    with path.open('rb') as f:
        for block in iter(lambda: f.read(4 * 1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


def save(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2), encoding='utf-8')


def encode(text):
    out = []
    base = ''
    for i, char in enumerate(text):
        previous = text[i - 1] if i else ''
        following = text[i + 1:i + 2]
        if char in TONE and previous in UPPER:
            char = TONE[char]
        elif char in AM and following == 'ำ':
            char = AM[char]
        elif char == '์' and previous in UPPER:
            char = '\ue005'
        if base in ('ป','ฝ','ฟ') and char in TALL_SHIFT:
            char=TALL_SHIFT[char]
        elif base == 'ฬ' and char in CHULA_SHIFT:
            char=CHULA_SHIFT[char]
        out.append(char)
        raw=text[i]
        if '\u0e01'<=raw<='\u0e2e':base=raw
        elif raw not in TALL_MARKS and raw not in '\u0e38\u0e39\u0e3a':base=''
    return ''.join(out)


def read_csv(path):
    with path.open(encoding='utf-8-sig', newline='') as f:
        return list(csv.reader(f))


def get_input(args, build):
    target = build / 'sheet_original.csv'
    if args.csv:
        source = Path(args.csv).resolve()
        if not args.allow_local_snapshot:
            raise ValueError('Local CSV requires --allow-local-snapshot; it may not be current')
        target.write_bytes(source.read_bytes())
        return target, 'explicit local snapshot (not claimed live)'
    if args.export_url_file:
        url = Path(args.export_url_file).read_text(encoding='utf-8-sig').strip()
        if not url.startswith('https://'):
            raise ValueError('Export download must use HTTPS')
        kind = 'fresh connector export'
    else:
        url = (f'https://docs.google.com/spreadsheets/d/{PUBLIC_SHEET_ID}/export'
               f'?format=csv&gid={PUBLIC_MAIN_GID}&cachebust={time.time_ns()}')
        kind = 'public main-tab CSV downloaded for this build'
    # Do not reuse older snapshots on failure or log temporary signed URLs.
    try:
        request = urllib.request.Request(url, headers={
            'Cache-Control': 'no-cache', 'Pragma': 'no-cache',
            'User-Agent': 'HD2-Thai-Translation-Updater/1.0'})
        with urllib.request.urlopen(request, timeout=45) as response:
            body = response.read(40 * 1024 * 1024 + 1)
        if len(body) > 40 * 1024 * 1024:
            raise ValueError('Export exceeds 40 MB')
        if body.lstrip().lower().startswith((b'<!doctype html', b'<html')):
            raise ValueError('Google returned an HTML access page, not CSV')
        first_row = next(csv.reader(body.decode('utf-8-sig').splitlines()), [])
        if first_row[:8] != HEADERS:
            raise ValueError('Downloaded CSV does not have the main translation headers')
    except Exception:
        raise RuntimeError('Sheet download failed or returned invalid data. Check public view access to the main tab, or supply a fresh connector export. No older CSV was reused.') from None
    target.write_bytes(body)
    save(build / 'sheet_source.json', {
        'input_kind': kind,
        'spreadsheet_id': PUBLIC_SHEET_ID if not args.export_url_file else None,
        'gid': PUBLIC_MAIN_GID if not args.export_url_file else None,
        'downloaded_utc': datetime.now(timezone.utc).isoformat(),
        'csv_sha256': digest(target),
    })
    return target, kind


def apply_linebreak_review(rows, build):
    url = (f'https://docs.google.com/spreadsheets/d/{PUBLIC_SHEET_ID}/export'
           f'?format=csv&gid=1683373761&cachebust={time.time_ns()}')
    request = urllib.request.Request(url, headers={'Cache-Control': 'no-cache',
                                                  'User-Agent': 'HD2-Thai-Translation-Updater/1.0'})
    with urllib.request.urlopen(request, timeout=45) as response:
        body = response.read(40 * 1024 * 1024 + 1)
    if len(body) > 40 * 1024 * 1024:
        raise ValueError('Review export exceeds 40 MB')
    path = build / 'linebreak_review_original.csv'
    path.write_bytes(body)
    review = read_csv(path)
    if not review or review[0][:5] != ['Debug ID', 'แถวชีทหลัก', 'ต้นฉบับอังกฤษ',
                                      'คำล่าสุดตอนเตรียมชุดทดลอง', 'ยุบช่วง + ขึ้นบรรทัด (แก้ได้)']:
        raise ValueError('Unexpected linebreak review headers')
    by_debug = {r[7]: r for r in rows[1:] if len(r) >= 8}
    seen = set()
    audit = []
    for number, item in enumerate(review[1:], 2):
        if not any(item):
            continue
        if len(item) < 7 or item[0] in seen or item[0] not in by_debug:
            raise ValueError(f'Invalid or duplicate review identity at row {number}')
        seen.add(item[0])
        target = by_debug[item[0]]
        if target[1] != item[6] or target[2] != item[2] or target[3] != item[3]:
            raise ValueError(f'Linebreak review is stale or mismatched: {item[0]}; refresh it from the main Sheet')
        proposal = item[4]
        plain = lambda s: CUE.sub('', s).replace('\n', '').replace('\r', '')
        if not proposal or plain(proposal) != plain(target[3]):
            raise ValueError(f'Linebreak review changes wording: {item[0]}')
        audit.append({'debug': item[0], 'id': target[1], 'before': target[3], 'after': proposal})
        target[3] = proposal
    if not audit:
        raise ValueError('Empty linebreak experiment review')
    save(build / 'linebreak_experiment.json', {
        'review_gid': 1683373761, 'review_sha256': digest(path),
        'downloaded_utc': datetime.now(timezone.utc).isoformat(),
        'policy': 'EXPERIMENT: 144 UTF-8 bytes per explicit line; combined cue length unproven in game',
        'strings': len(audit), 'changes': audit})
    return rows


def validate(rows, baseline, build, linebreak_experiment=False, markup_rules=None):
    errors, warnings, normalized, seen, debug_ids = [], [], [], set(), set()
    if not rows or rows[0][:8] != HEADERS:
        raise ValueError('Unexpected headers; export the main translation tab, not a review tab')
    previous = {tuple(r[:2]): r for r in baseline[1:] if any(r)}
    row_policies, markup_review = reviewed_relocations(rows, markup_rules)
    for item in markup_review:
        if item.get('valid') is False:
            errors.append({'issue':'Sheet markup rule failed','rule':item['rule'],
                           'rule_row':item.get('config_row'),'detail':item['reason']})
    changes = []
    wrapping = []
    for number, row in enumerate(rows[1:], 2):
        if number % 250 == 0:
            progress(20 + int(15 * number / max(len(rows), 1)), 'validate',
                     f'{number - 1:,} / {len(rows) - 1:,}')
        if not any(row):
            continue
        if len(row) < 8:
            errors.append({'row': number, 'issue': 'incomplete row'})
            continue
        key = tuple(row[:2])
        def issue(message):
            errors.append({'row': number, 'asset': row[0], 'id': row[1], 'issue': message})
        if key in seen:
            issue('duplicate Asset ID / String ID')
        seen.add(key)
        try:
            if not 0 <= int(row[0], 16) < 2**64 or not 0 <= int(row[1]) < 2**32:
                raise ValueError()
        except ValueError:
            issue('invalid resource ID')
        if key not in previous:
            issue('ID absent from locked baseline; refresh the baseline deliberately')
        elif row[2] != previous[key][2]:
            issue('English source differs from locked baseline for this ID')
        if not re.fullmatch('[0-9A-Z]{3}', row[7]) or row[7] in debug_ids:
            issue('missing, invalid, or duplicate Debug ID')
        debug_ids.add(row[7])
        text = row[3]
        if '\x00' in text or '\ufffd' in text:
            issue('NUL or Unicode replacement character')
        if any(0xE000 <= ord(c) <= 0xF8FF or 0xF0000 <= ord(c) <= 0x10FFFD for c in text):
            issue('Sheet must contain readable Unicode, not pre-encoded PUA glyphs')
        checks = row_policies.get(key, {})
        effective = text if text.strip() else row[2]
        if checks.get('placeholders', True) and Counter(re.findall(r'#[A-Z][A-Z0-9_]*', effective)) != Counter(re.findall(r'#[A-Z][A-Z0-9_]*', row[2])):
            issue('placeholder differs from English; review explicitly')
        if checks.get('tags', True) and Counter(re.findall(r'<[^<>]+>', effective)) != Counter(re.findall(r'<[^<>]+>', row[2])):
            issue('markup differs from English; review explicitly')
        prepared,wrap_info = prepare_text(effective)
        encoded = encode(prepared)
        description_limit = checks.get('max_utf8_bytes')
        if description_limit is not None:
            actual_bytes = len(encoded.encode('utf-8'))
            if actual_bytes > description_limit:
                issue(f'description exceeds {description_limit} UTF-8 bytes after ICU/glyph: {actual_bytes} bytes; fix in Sheet')
        if encoded.replace('\u200b','') != encode(effective).replace('\u200b',''):
            issue('ICU changed contextual glyph encoding')
        if wrap_info['inserted'] or wrap_info['limited_cues']:
            wrapping.append({'row':number,'debug':row[7],**wrap_info})
        cues = list(CUE.finditer(encoded))
        if checks.get('subtitle_time', True) and re.search(r'\{[^{}]*(?:->|\d+\.\d+)[^{}]*\}', CUE.sub('', encoded)):
            issue('malformed subtitle timecode')
        if checks.get('subtitle_time', True) and bool(CUE.search(row[2])) != bool(cues):
            issue('timed subtitle markers missing or unexpectedly added')
        if cues:
            source_cues = list(CUE.finditer(row[2]))
            if checks.get('subtitle_time', True) and source_cues and (float(cues[0][1]) != float(source_cues[0][1]) or
                                 float(cues[-1][2]) != float(source_cues[-1][2])):
                issue('subtitle outer time range differs from English')
            if checks.get('subtitle_time', True) and any(float(right[1]) < float(left[1]) for left, right in zip(cues, cues[1:])):
                issue('subtitle start times run backwards')
            for i, cue in enumerate(cues):
                body = encoded[cue.end():cues[i+1].start() if i+1 < len(cues) else len(encoded)]
                original_zero_cue = (float(cue[1]) == float(cue[2]) == 0 and
                                     any(float(c[1]) == float(c[2]) == 0 for c in source_cues))
                if checks.get('subtitle_time', True) and float(cue[2]) <= float(cue[1]) and not original_zero_cue:
                    issue('non-positive subtitle duration')
                elif original_zero_cue:
                    warnings.append({'row': number, 'issue': 'zero-duration cue preserved from game source'})
                if checks.get('subtitle_time', True) and not body.strip():
                    issue('empty subtitle cue')
                measured = body.split('\n') if linebreak_experiment else [body]
                if checks.get('subtitle_bytes', True) and any(len(line.encode('utf-8')) > 144 for line in measured):
                    issue('subtitle cue exceeds 144 UTF-8 bytes; fix in Sheet, never auto-split')
                elif checks.get('subtitle_bytes', True) and linebreak_experiment and len(body.encode('utf-8')) > 144:
                    warnings.append({'row': number, 'issue': 'EXPERIMENT: combined cue exceeds 144 bytes; explicit lines each within budget'})
        if text and '?' in text and '?' not in row[2]:
            warnings.append({'row': number, 'issue': 'question mark absent from source; review context'})
        if key in previous and text != previous[key][3]:
            changes.append({'row': number, 'asset': row[0], 'id': row[1],
                            'before': previous[key][3], 'after': text})
        normalized.append(row[:3] + [encoded if text.strip() else text] + row[4:8])
    missing = set(previous) - seen
    if missing:
        errors.append({'issue': 'baseline IDs missing from export', 'count': len(missing),
                       'examples': sorted(missing)[:10]})
    save(build / 'validation.json', {'errors': errors, 'warnings': warnings,
                                      'rows': len(normalized), 'changed_since_baseline': len(changes),
                                      'validation_check_overrides': markup_review,
                                      'reviewed_markup_relocations': markup_review})
    save(build / 'translation_changes.json', changes)
    save(build / 'thai_linebreaks.json', {
        'engine':'Windows ICU UBRK_LINE th',
        'sheet_text_unchanged':True,'subtitle_byte_budget':144,
        'strings_with_breaks':sum(x['inserted']>0 for x in wrapping),
        'inserted':sum(x['inserted'] for x in wrapping),
        'limited_cues':sum(x['limited_cues'] for x in wrapping),
        'rows':wrapping})
    if errors:
        raise ValueError(f'{len(errors)} validation issues; see {build / "validation.json"}. No ZIP published.')
    encoded_path = build / 'sheet_encoded.csv'
    with encoded_path.open('w', encoding='utf-8-sig', newline='') as f:
        csv.writer(f, lineterminator='\n').writerows([HEADERS] + normalized)
    return encoded_path, len(normalized), len(changes)


def next_version():
    versions = [35]
    from project_paths import version_roots
    for directory in version_roots(PROJECT):
        if not directory.is_dir():continue
        for path in directory.iterdir():
            match = re.match(r'HD2_Thai_Translation_(?:ThaiPUAAtlasFix_)?v(\d+)', path.name)
            if match:versions.append(int(match[1]))
    state=ROOT/'version_state.json'
    if state.exists():versions.append(int(json.loads(state.read_text(encoding='utf-8'))['highest_reserved']))
    return max(versions) + 1


def parse_args(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    inputs = parser.add_mutually_exclusive_group()
    inputs.add_argument('--export-url-file', help='Text file containing a freshly issued connector download URL')
    inputs.add_argument('--csv', help='Explicit offline CSV input')
    parser.add_argument('--allow-local-snapshot', action='store_true')
    parser.add_argument('--debug', action='store_true',
                        help='Append the Sheet Debug ID as [ABC] to each translation string')
    parser.add_argument('--ui-review', action='store_true',
                        help='Opt-in UI/XAML Debug experiment, reviewed UI Sheet + tested compact font profile')
    parser.add_argument('--no-ui', action='store_true',help='Explicit legacy package without the reviewed XAML labels')
    parser.add_argument('--linebreak-experiment', action='store_true',
                        help='Use live linebreak review tab; validate each explicit subtitle line (experimental)')
    parser.add_argument('--three-languages', action='store_true',
                        help='US Thai / UK Thai+ID / Portuguese Brazil original US')
    parser.add_argument('--hot-swap-tables', action='store_true',
                        help='Experimental: keep all three languages in each registered text table')
    parser.add_argument('--private-modes', action='store_true',
                        help='US assets only; private debug/English codes instead of vanilla UK/BR slots')
    parser.add_argument('--standalone-hotkeys', action='store_true',
                        help='Include our own boot hotkeys in the PrivateModes package, without Chef')
    parser.add_argument('--public-release', action='store_true',
                        help='Approved clean Arsenal package; presentation requires review first')
    parser.add_argument('--release-version', help='Public version shown in ZIP filename and Nexus metadata when configured')
    parser.add_argument('--thai-only', action='store_true',
                        help='Legacy Thai-only package, without private debug/English modes')
    args = parser.parse_args(argv)
    if args.release_version and not args.public_release:
        raise ValueError('--release-version requires --public-release')
    if args.public_release:
        if args.debug or args.ui_review or args.no_ui or args.linebreak_experiment or args.thai_only or args.csv:
            raise ValueError('--public-release requires the normal fresh standalone package')
        args.standalone_hotkeys = True
    if args.ui_review and args.no_ui:
        raise ValueError('--ui-review cannot combine --no-ui')
    args.include_ui = not args.no_ui
    if args.ui_review and not args.debug:
        raise ValueError('--ui-review currently requires --debug; XAML private-mode switching is not verified')
    if args.thai_only and (args.debug or args.linebreak_experiment or args.three_languages
                          or args.hot_swap_tables or args.private_modes or args.standalone_hotkeys):
        raise ValueError('--thai-only cannot combine with another package mode')
    # Normal packaging now preserves all three private modes. Keep the hotkey
    # mod separate; --debug remains the explicitly requested old debug package.
    if not (args.thai_only or args.debug or args.linebreak_experiment
            or args.three_languages or args.hot_swap_tables or args.private_modes):
        args.three_languages=args.hot_swap_tables=args.private_modes=True
    if args.standalone_hotkeys and not args.private_modes:
        raise ValueError('--standalone-hotkeys requires --private-modes')
    if args.private_modes and not (args.three_languages and args.hot_swap_tables):
        raise ValueError('--private-modes requires --three-languages --hot-swap-tables')
    if args.hot_swap_tables and not args.three_languages:
        raise ValueError('--hot-swap-tables requires --three-languages')
    if args.three_languages and (args.debug or args.linebreak_experiment or args.csv):
        raise ValueError('Three-language package requires fresh main Sheet and cannot combine other modes or local CSV')
    if args.linebreak_experiment and (args.debug or args.csv or args.export_url_file):
        raise ValueError('Linebreak experiment requires fresh public main/review Sheets and normal text without debug')
    return args


def main():
    from project_paths import locked_input,translations
    args=parse_args()
    public_config = None
    if args.public_release:
        from public_release import load_config,release_version,public_filename
        public_config = load_config()
        if args.release_version:
            public_config['public_version']=release_version(args.release_version)
        public_output=translations(PROJECT)/public_filename(public_config['public_version'])
        if public_output.exists():
            raise FileExistsError(f'มี ZIP เวอร์ชันเผยแพร่นี้แล้ว: {public_output.name} กรุณาเปลี่ยนเวอร์ชัน หรือย้ายไฟล์เดิมออกก่อน โปรแกรมจะไม่เขียนทับ')
    progress(0, 'baseline')
    manifest = json.loads((ROOT / 'baseline_lock.json').read_text(encoding='utf-8'))
    for index, (relative, expected) in enumerate(manifest['files'].items(), 1):
        path = locked_input(PROJECT,relative)
        if not path.is_file() or digest(path) != expected:
            raise ValueError(f'Locked dependency changed or missing: {relative}')
        progress(int(10 * index / len(manifest['files'])), 'baseline',
                 f'{index} / {len(manifest["files"])}')
    version = next_version()
    (PROJECT/'Builds').mkdir(exist_ok=True)
    translations(PROJECT).mkdir(parents=True,exist_ok=True)
    build = PROJECT / 'Builds' / f'HD2_Thai_Translation_v{version}_build'
    build.mkdir(exist_ok=False)
    (ROOT/'version_state.json').write_text(json.dumps({'highest_reserved':version},indent=2),encoding='utf-8')
    suffix = 'UIReview_Debug' if args.ui_review else 'PrivateStandalone' if args.standalone_hotkeys else 'PrivateModes' if args.private_modes else 'HotSwapTables' if args.hot_swap_tables else 'ThreeLanguages' if args.three_languages else 'LinebreakExperiment' if args.linebreak_experiment else 'Debug' if args.debug else 'LatestSheet'
    output = public_output if args.public_release else translations(PROJECT) / f'HD2_Thai_Translation_v{version}_{suffix}.zip'
    temp = build / 'package.partial.zip'
    progress(10, 'download')
    original, input_kind = get_input(args, build)
    progress(20, 'validate')
    rows = read_csv(original)
    if args.linebreak_experiment:
        rows = apply_linebreak_review(rows, build)
    markup_rules = load_review_rules(build, ROOT)
    encoded, count, changes = validate(rows, read_csv(PROJECT / manifest['baseline_csv']), build,
                                       linebreak_experiment=args.linebreak_experiment, markup_rules=markup_rules)
    commit_review_rules(build, ROOT)
    progress(35, 'build', f'v{version}')
    spec = importlib.util.spec_from_file_location('locked_hd2_builder', PROJECT / manifest['builder'])
    builder = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(builder)
    builder.SHEET_CSV = encoded
    builder.GAME_STRINGS = PROJECT / manifest['game_strings']
    sheet = builder.read_sheet()
    debug_stats = {'tagged_strings': 0, 'subtitle_cues_over_normal_budget_after_debug': 0}
    if args.debug:
        debug_rows = [['Asset ID', 'String ID', 'Debug ID', 'English source', 'Thai translation']]
        for asset, items in sheet.items():
            for string_id, item in items.items():
                plain = item['thai'] if item['thai'].strip() else item['english']
                item['thai'] = f"{plain} [{item['debug']}]"
                debug_stats['tagged_strings'] += 1
                debug_rows.append([f'0x{asset:016x}', string_id, item['debug'],
                                   item['english'], item['thai']])
                cues = list(CUE.finditer(item['thai']))
                for i, cue in enumerate(cues):
                    body = item['thai'][cue.end():cues[i+1].start() if i+1 < len(cues) else len(item['thai'])]
                    size = len(body.encode('utf-8'))
                    if size > 150:
                        raise ValueError(f'Debug cue exceeds 150 bytes: {asset:#x}/{string_id}')
                    if size > 144:
                        debug_stats['subtitle_cues_over_normal_budget_after_debug'] += 1
        with (build / 'debug_lookup.csv').open('w', encoding='utf-8-sig', newline='') as f:
            csv.writer(f, lineterminator='\n').writerows(debug_rows)
    with zipfile.ZipFile(locked_input(PROJECT,manifest['font_package'])) as base:
        builder.TEMPLATE_PATCH = build / 'translation_template.patch'
        builder.TEMPLATE_PATCH.write_bytes(base.read(PATCH))
        # Debug suffixes have already been applied once above. Keep the legacy
        # builder's debug switch off to avoid adding a second suffix.
        patch, stats = builder.build_profile(sheet, debug=False)
        if args.three_languages:
            from three_languages import build as build_three_languages
            patch,language_report=build_three_languages(builder,patch,sheet,builder.GAME_STRINGS,
                                                       hot_swap_tables=args.hot_swap_tables,
                                                       private_modes=args.private_modes)
            save(build / 'three_languages.json',language_report)
            stats['assets']=language_report['resources']
        progress(45, 'pack')
        stats['bytes'] = len(patch)
        readme = (f'Helldivers 2 Thai Translation v{version}\n'
                  'Translation snapshot and build report are stored alongside this release.\n'
                  + ('Font resources preserved from the selected user-approved profile; v35 baseline lock independently verified.\n' if args.include_ui else 'Font resources preserved byte-for-byte from the locked v35 package.\n') +
                  'Raised Thai marks encoded contextually. Subtitle timings taken from Sheet unchanged.\n'
                  + ('DEBUG: [ABC] suffix appended once per Sheet string; timed subtitles show it on the last cue.\n'
                     'Debug suffix may add up to 6 bytes beyond the normal subtitle budget.\n' if args.debug else '') +
                  ('EXPERIMENT: subtitles use explicit newlines from the live review tab. Combined cue length above 144 bytes is not yet proven.\n' if args.linebreak_experiment else '') +
                  ('THREE LANGUAGES: English US = Thai; English UK = Thai + ID; Portuguese Brazil = original English US. Hotkey switching is not implemented by this translation package.\n' if args.three_languages and not args.private_modes else '') +
                  ('HOT SWAP TABLES EXPERIMENT: each table contains US, GB and BP; use hotkeys v5 F6/F7/F8. UI refresh is not yet verified.\n' if args.hot_swap_tables and not args.private_modes else '') +
                  ('PRIVATE MODES EXPERIMENT: US = Thai; hd2thai_debug = Thai + ID; hd2thai_english = original US. Only US strings assets are replaced. Esc is still needed for UI refresh.\n' if args.private_modes else '') +
                  ('STANDALONE: own boot script included, no Chef required. Disable other translation/hotkey/boot mods. Start in English US. Page Up: Thai -> Thai+ID -> English; Page Down: reverse; no wrap.\n' if args.standalone_hotkeys else '') +
                  ('UI REVIEW EXPERIMENT: reviewed UI column E, Debug IDs in column M. US dictionary and shared literal XAML translated. This is a static DEBUG test, not the F6/F7/F8 three-mode package.\n' if args.ui_review else '') +
                  ('UI LABELS INCLUDED: disable the previous separate UI labels addon. Main text tables retain three-mode switching support; XAML labels remain Thai and do not follow those modes.\n' if args.include_ui and not args.ui_review else '') +
                  'This release has not yet been checked in game.\n')
        extras={}
        profile_fonts=None
        ui_report=None
        if args.include_ui:
            from ui_review import load_fonts, build as build_ui_review
            profile_fonts,font_profile=load_fonts(PROJECT)
            extras,ui_report=build_ui_review(PROJECT,build,rows,encode,args.debug if args.ui_review else False,
                                            clean_labels=not args.ui_review)
            save(build/'font_profile.json',font_profile)
            if font_profile.get('licenses'):
                with zipfile.ZipFile(locked_input(PROJECT,font_profile['font_package'])) as approved:
                    for name in font_profile['licenses']:extras[name]=approved.read(name)
        if args.standalone_hotkeys:
            from standalone_hotkeys import package_files
            hotkey_extras,hotkey_report=package_files(PROJECT)
            if set(extras)&set(hotkey_extras):raise ValueError('UI and hotkey file collision')
            extras.update(hotkey_extras)
            save(build / 'standalone_hotkeys.json',hotkey_report)
        with zipfile.ZipFile(temp, 'x', zipfile.ZIP_DEFLATED, compresslevel=6) as target:
            total_size = sum(e.file_size for e in base.infolist()) or 1
            done_size = 0
            expected_members={}
            for entry in base.infolist():
                if profile_fonts is not None and entry.filename.startswith('Fonts/') and entry.filename not in profile_fonts:
                    done_size+=entry.file_size
                    continue
                data = patch if entry.filename == PATCH else readme.encode('utf-8') if entry.filename == 'README_TH.txt' else base.read(entry.filename)
                if profile_fonts is not None and entry.filename in profile_fonts:
                    data=profile_fonts[entry.filename]
                # zipfile mutates ZipInfo.header_offset while writing. Keep the
                # source's offsets intact for the subsequent byte comparison.
                target.writestr(copy.copy(entry), data)
                expected_members[entry.filename]=data
                done_size += entry.file_size
                progress(45 + int(30 * done_size / total_size), 'pack', entry.filename)
            for name,data in extras.items():
                if name in expected_members:raise ValueError('Extra member collides with baseline: '+name)
                target.writestr(name,data)
                expected_members[name]=data
            if profile_fonts is not None and not set(profile_fonts)<=set(expected_members):
                raise ValueError('A compact font member was not packaged')
        progress(75, 'verify')
        with zipfile.ZipFile(temp) as packed:
            if packed.testzip() is not None or packed.namelist() != list(expected_members):
                raise ValueError('Package integrity or member list mismatch')
            for index, (name,expected) in enumerate(expected_members.items(), 1):
                if packed.read(name) != expected:
                    raise ValueError(f'Packaged member mismatch: {name}')
                progress(75 + int(20 * index / len(expected_members)), 'verify', name)
            for name,data in extras.items():
                if packed.read(name)!=data:raise ValueError('Packaged hotkey mismatch: '+name)
    public_report = None
    if public_config is not None:
        from public_release import clean_package
        public_temp = build / 'public_package.partial.zip'
        public_report = clean_package(temp, public_temp, public_config)
        save(build / 'public_release_report.json', public_report)
        temp = public_temp
    if output.exists():
        raise FileExistsError(output)
    # Path.rename on Windows refuses an existing target, including concurrent builds.
    temp.rename(output)
    progress(95, 'report')
    report = {**stats, 'version': version, 'sheet_rows': count, 'changed_since_v35': changes,
              'input_kind': input_kind, 'export_sha256': digest(original),
              'font_package': manifest['font_package'], 'zip': str(output),
              'ui_review':ui_report is not None,
              'ui_font_profile':font_profile['font_package'] if args.include_ui else None,
              'ui_translated_rows':ui_report['translated_rows'] if ui_report else 0,
              'zip_sha256': digest(output), 'built_utc': datetime.now(timezone.utc).isoformat(),
              'subtitle_policy': ('EXPERIMENT: preserve wording; use reviewed timecodes/newlines; 144 bytes per explicit line'
                                  if args.linebreak_experiment else 'preserve Sheet wording and timecodes; reject cues over 144 bytes'),
              'mode': 'private_standalone' if args.standalone_hotkeys else 'private_modes' if args.private_modes else 'three_languages' if args.three_languages else 'linebreak_experiment' if args.linebreak_experiment else 'debug' if args.debug else 'normal',
              'debug': debug_stats if args.debug else None,
              'in_game_verified': False}
    if public_report is not None:
        report['public_release'] = public_report
        report['public_version'] = public_config['public_version']
    save(build / 'build_report.json', report)
    progress(100, 'done', str(output))
    print(json.dumps(report, ensure_ascii=True, indent=2))


if __name__ == '__main__':
    try:
        main()
    except Exception as error:
        print(f'BUILD STOPPED: {error}', file=sys.stderr)
        sys.exit(1)
